import React from 'react';
import { Calendar, ArrowRight, ArrowLeft, SkipForward, MapPin } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Input } from '../ui/Input';
import { FamilyProfile } from '../../types';

interface OnboardingAvailabilityLocationProps {
  data: Partial<FamilyProfile>;
  onUpdate: (updates: Partial<FamilyProfile>) => void;
  onNext: () => void;
  onPrev: () => void;
  onSkip: () => void;
  userLocation?: string;
}

export function OnboardingAvailabilityLocation({
  data,
  onUpdate,
  onNext,
  onPrev,
  onSkip,
  userLocation
}: OnboardingAvailabilityLocationProps) {
  const updateAvailability = (updates: Partial<FamilyProfile['fosteringAvailability']>) => {
    onUpdate({
      fosteringAvailability: {
        ...data.fosteringAvailability,
        ...updates
      }
    });
  };

  const durations = [
    {
      value: 'short',
      label: 'Court terme',
      description: 'Moins d\'1 mois',
      emoji: '⚡'
    },
    {
      value: 'medium',
      label: 'Moyen terme',
      description: '1 à 6 mois',
      emoji: '🌙'
    },
    {
      value: 'long',
      label: 'Long terme',
      description: '6 mois et plus',
      emoji: '🌟'
    },
    {
      value: 'permanent',
      label: 'Adoption',
      description: 'Engagement définitif',
      emoji: '❤️'
    }
  ];

  const frequencies = [
    {
      value: 'occasional',
      label: 'Ponctuel',
      description: 'De temps en temps',
      emoji: '🎯'
    },
    {
      value: 'regular',
      label: 'Régulier',
      description: 'Plusieurs fois par an',
      emoji: '🔄'
    },
    {
      value: 'emergency',
      label: 'Urgences',
      description: 'Disponible rapidement',
      emoji: '🚨'
    }
  ];

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-kiweetoTeal-100 rounded-full flex items-center justify-center mx-auto">
          <Calendar className="h-8 w-8 text-kiweetoTeal-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            Vos disponibilités
          </h1>
          <p className="text-gray-600">
            Aidez-nous à vous proposer des missions qui correspondent à votre planning.
          </p>
        </div>
      </div>

      {/* Duration Preference */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Durée d'accueil préférée</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {durations.map((duration) => (
            <label
              key={duration.value}
              className={`flex items-center p-4 border-2 rounded-lg cursor-pointer transition-all ${
                data.fosteringAvailability?.duration === duration.value
                  ? 'border-kiweetoTeal-500 bg-kiweetoTeal-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <input
                type="radio"
                name="duration"
                value={duration.value}
                checked={data.fosteringAvailability?.duration === duration.value}
                onChange={(e) => updateAvailability({ duration: e.target.value as any })}
                className="sr-only"
              />
              <div className="flex items-center space-x-3 flex-1">
                <span className="text-2xl">{duration.emoji}</span>
                <div>
                  <div className="font-medium text-gray-900">{duration.label}</div>
                  <div className="text-sm text-gray-500">{duration.description}</div>
                </div>
              </div>
            </label>
          ))}
        </div>
      </Card>

      {/* Frequency */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Fréquence d'accueil</h3>
        <div className="space-y-3">
          {frequencies.map((frequency) => (
            <label
              key={frequency.value}
              className={`flex items-center p-4 border-2 rounded-lg cursor-pointer transition-all ${
                data.fosteringAvailability?.frequency === frequency.value
                  ? 'border-kiweetoTeal-500 bg-kiweetoTeal-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <input
                type="radio"
                name="frequency"
                value={frequency.value}
                checked={data.fosteringAvailability?.frequency === frequency.value}
                onChange={(e) => updateAvailability({ frequency: e.target.value as any })}
                className="sr-only"
              />
              <div className="flex items-center space-x-3 flex-1">
                <span className="text-2xl">{frequency.emoji}</span>
                <div>
                  <div className="font-medium text-gray-900">{frequency.label}</div>
                  <div className="text-sm text-gray-500">{frequency.description}</div>
                </div>
              </div>
            </label>
          ))}
        </div>
      </Card>

      {/* Capacity */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Capacité d'accueil</h3>
        <div className="space-y-4">
          <Input
            label="Nombre maximum d'animaux en même temps"
            type="number"
            value={data.fosteringAvailability?.maxAnimalsAtOnce || 1}
            onChange={(e) => updateAvailability({ maxAnimalsAtOnce: parseInt(e.target.value) || 1 })}
            min="1"
            max="10"
          />
          <p className="text-sm text-gray-500">
            Commencez petit ! Vous pourrez toujours augmenter cette capacité plus tard.
          </p>
        </div>
      </Card>

      {/* Location Confirmation */}
      <Card>
        <div className="flex items-center space-x-2 mb-4">
          <MapPin className="h-5 w-5 text-kiweetoTeal-600" />
          <h3 className="text-lg font-semibold text-gray-900">Zone géographique</h3>
        </div>
        <div className="space-y-4">
          <div className="p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600 mb-2">Votre localisation actuelle :</p>
            <p className="font-medium text-gray-900">{userLocation || 'Non renseignée'}</p>
          </div>
          <p className="text-sm text-gray-500">
            Les associations de votre région pourront vous contacter pour des missions d'accueil.
            Vous pourrez modifier cette information dans votre profil.
          </p>
        </div>
      </Card>

      {/* Availability Dates (Optional) */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Dates de disponibilité (optionnel)</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Disponible à partir du
            </label>
            <input
              type="date"
              value={data.fosteringAvailability?.startDate ? data.fosteringAvailability.startDate.toISOString().split('T')[0] : ''}
              onChange={(e) => updateAvailability({ startDate: e.target.value ? new Date(e.target.value) : undefined })}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-kiweetoTeal-500 focus:ring-kiweetoTeal-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Jusqu'au (optionnel)
            </label>
            <input
              type="date"
              value={data.fosteringAvailability?.endDate ? data.fosteringAvailability.endDate.toISOString().split('T')[0] : ''}
              onChange={(e) => updateAvailability({ endDate: e.target.value ? new Date(e.target.value) : undefined })}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-kiweetoTeal-500 focus:ring-kiweetoTeal-500"
            />
          </div>
        </div>
        <p className="text-sm text-gray-500 mt-2">
          Laissez vide si vous n'avez pas de contraintes de dates particulières.
        </p>
      </Card>

      {/* Encouragement */}
      {data.fosteringAvailability?.duration && data.fosteringAvailability?.frequency && (
        <Card className="bg-kiweetoTeal-50 border-kiweetoTeal-200">
          <div className="text-center">
            <p className="text-kiweetoTeal-800 font-medium">
              📅 Parfait ! Votre flexibilité permettra d'aider de nombreux animaux !
            </p>
          </div>
        </Card>
      )}

      {/* Navigation */}
      <div className="flex justify-between items-center pt-6">
        <Button
          variant="outline"
          icon={ArrowLeft}
          onClick={onPrev}
        >
          Précédent
        </Button>

        <Button
          variant="ghost"
          icon={SkipForward}
          onClick={onSkip}
          className="text-gray-500"
        >
          Passer cette étape
        </Button>

        <Button
          variant="kiweetoTeal"
          icon={ArrowRight}
          iconPosition="right"
          onClick={onNext}
        >
          Suivant
        </Button>
      </div>
    </div>
  );
}