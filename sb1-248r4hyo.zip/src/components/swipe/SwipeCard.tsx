import React, { useState } from 'react';
import { Heart, X, MapPin, Calendar, Users } from 'lucide-react';
import { Animal } from '../../types';
import { Badge } from '../ui/Badge';

interface SwipeCardProps {
  animal: Animal;
  onSwipe: (animalId: string, direction: 'like' | 'pass') => void;
}

export function SwipeCard({ animal, onSwipe }: SwipeCardProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [startPos, setStartPos] = useState({ x: 0, y: 0 });

  const getAgeText = (age: number) => {
    return age > 1 ? `${age} ans` : `${age} an`;
  };
  
  const getSexText = (sex: string) => {
    const sexMap = {
      male: 'Mâle',
      female: 'Femelle'
    };
    return sexMap[sex as keyof typeof sexMap] || sex;
  };

  const getSizeText = (size: string) => {
    const sizeMap = { petit: 'Petit', moyen: 'Moyen', grand: 'Grand' };
    return sizeMap[size as keyof typeof sizeMap] || size;
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setStartPos({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    
    const deltaX = e.clientX - startPos.x;
    const deltaY = e.clientY - startPos.y;
    setDragOffset({ x: deltaX, y: deltaY });
  };

  const handleMouseUp = () => {
    if (!isDragging) return;
    
    const threshold = 150;
    if (Math.abs(dragOffset.x) > threshold) {
      const direction = dragOffset.x > 0 ? 'like' : 'pass';
      onSwipe(animal.id, direction);
    }
    
    setIsDragging(false);
    setDragOffset({ x: 0, y: 0 });
  };

  const rotation = isDragging ? dragOffset.x * 0.1 : 0;
  const opacity = isDragging ? Math.max(0.7, 1 - Math.abs(dragOffset.x) / 300) : 1;

  return (
    <div
      className="absolute inset-0 cursor-grab active:cursor-grabbing select-none"
      style={{
        transform: `translate(${dragOffset.x}px, ${dragOffset.y}px) rotate(${rotation}deg)`,
        opacity,
        transition: isDragging ? 'none' : 'all 0.3s ease-out'
      }}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      <div className="bg-white rounded-2xl shadow-xl overflow-hidden h-full border-2 border-gray-100">
        {/* Image principale */}
        <div className="relative h-3/5 overflow-hidden">
          <img
            src={animal.photos[0]}
            alt={animal.name}
            className="w-full h-full object-cover"
            draggable={false}
          />
          
          {/* Overlay pour les actions de swipe */}
          {isDragging && (
            <div className="absolute inset-0 flex items-center justify-center">
              {dragOffset.x > 50 && (
                <div className="bg-secondary-500 text-white px-6 py-3 rounded-full font-bold text-lg opacity-80">
                  <Heart className="h-6 w-6 inline mr-2" />
                  J'AIME
                </div>
              )}
              {dragOffset.x < -50 && (
                <div className="bg-gray-500 text-white px-6 py-3 rounded-full font-bold text-lg opacity-80">
                  <X className="h-6 w-6 inline mr-2" />
                  PASSER
                </div>
              )}
            </div>
          )}

          <div className="absolute top-4 left-4">
            <Badge variant="primary" size="md">
              {animal.type === 'chien' ? 'Chien' : animal.type === 'chat' ? 'Chat' : 'Autre'}
            </Badge>
          </div>
        </div>

        {/* Informations */}
        <div className="p-6 space-y-4 h-2/5 overflow-y-auto">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">{animal.name}</h2>
            <p className="text-lg text-gray-600">
              {animal.breed} • {getSexText(animal.sex)} • {getAgeText(animal.age)} • {getSizeText(animal.size)}
            </p>
          </div>

          <p className="text-gray-700">{animal.description}</p>

          {/* Badges santé */}
          <div className="flex flex-wrap gap-2">
            {animal.health.vaccinated && (
              <Badge variant="success">Vacciné</Badge>
            )}
            {animal.health.sterilized && (
              <Badge variant="success">Stérilisé</Badge>
            )}
          </div>

          {/* Compatibilité */}
          <div className="space-y-2">
            <h4 className="font-medium text-gray-900">Compatibilité :</h4>
            <div className="flex flex-wrap gap-3 text-sm">
              {animal.compatibility.withDogs && (
                <div className="flex items-center space-x-1 text-secondary-600">
                  <Users className="h-4 w-4" />
                  <span>Chiens</span>
                </div>
              )}
              {animal.compatibility.withCats && (
                <div className="flex items-center space-x-1 text-secondary-600">
                  <Users className="h-4 w-4" />
                  <span>Chats</span>
                </div>
              )}
              {animal.compatibility.withChildren && (
                <div className="flex items-center space-x-1 text-secondary-600">
                  <Users className="h-4 w-4" />
                  <span>Enfants</span>
                </div>
              )}
            </div>
          </div>

          {/* Localisation et disponibilité */}
          <div className="flex items-center justify-between text-sm text-gray-500 pt-2 border-t border-gray-100">
            <div className="flex items-center space-x-1">
              <MapPin className="h-4 w-4" />
              <span>{animal.location}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Calendar className="h-4 w-4" />
              <span>Dispo. {animal.availableFrom.toLocaleDateString('fr-FR')}</span>
            </div>
          </div>

          <div className="text-sm text-gray-500">
            Par {animal.associationName}
          </div>
        </div>
      </div>
    </div>
  );
}