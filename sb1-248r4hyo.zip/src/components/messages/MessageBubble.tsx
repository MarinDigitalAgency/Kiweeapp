import React from 'react';
import { Check, CheckCheck } from 'lucide-react';
import { Message } from '../../types';
import { useAuth } from '../../contexts/AuthContext';

interface MessageBubbleProps {
  message: Message;
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const { user } = useAuth();
  const isOwnMessage = message.senderId === user?.id;

  return (
    <div className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'} mb-4`}>
      <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
        isOwnMessage 
          ? 'bg-primary-600 text-white' 
          : 'bg-gray-100 text-gray-900'
      }`}>
        {!isOwnMessage && (
          <div className="text-xs font-medium mb-1 text-gray-600">
            {message.senderName}
          </div>
        )}
        
        <p className="text-sm">{message.content}</p>
        
        <div className={`flex items-center justify-end mt-1 space-x-1 ${
          isOwnMessage ? 'text-primary-200' : 'text-gray-500'
        }`}>
          <span className="text-xs">
            {message.timestamp.toLocaleTimeString('fr-FR', { 
              hour: '2-digit', 
              minute: '2-digit' 
            })}
          </span>
          {isOwnMessage && (
            message.read ? (
              <CheckCheck className="h-3 w-3" />
            ) : (
              <Check className="h-3 w-3" />
            )
          )}
        </div>
      </div>
    </div>
  );
}