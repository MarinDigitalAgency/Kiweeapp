import React, { useState } from 'react';
import { Edit, Trash2, Eye, MoreVertical, Calendar, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Animal } from '../../types';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface AnimalManagementCardProps {
  animal: Animal;
  onDelete: (animalId: string) => void;
}

export function AnimalManagementCard({ animal, onDelete }: AnimalManagementCardProps) {
  const [showMenu, setShowMenu] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const getAgeText = (age: number) => {
    return age > 1 ? `${age} ans` : `${age} an`;
  };
  
  const getSexText = (sex: string) => {
    const sexMap = {
      male: 'Mâle',
      female: 'Femelle'
    };
    return sexMap[sex as keyof typeof sexMap] || sex;
  };

  const getSizeText = (size: string) => {
    const sizeMap = {
      petit: 'Petit',
      moyen: 'Moyen',
      grand: 'Grand'
    };
    return sizeMap[size as keyof typeof sizeMap] || size;
  };

  const getTypeText = (type: string) => {
    const typeMap = {
      chien: 'Chien',
      chat: 'Chat',
      autre: 'Autre'
    };
    return typeMap[type as keyof typeof typeMap] || type;
  };

  const handleDelete = () => {
    onDelete(animal.id);
    setShowDeleteConfirm(false);
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:shadow-md transition-shadow duration-200">
      {/* Image */}
      <div className="relative h-48 overflow-hidden">
        <img
          src={animal.photos[0]}
          alt={animal.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-3 left-3">
          <Badge variant="primary">
            {getTypeText(animal.type)}
          </Badge>
        </div>
        <div className="absolute top-3 right-3">
          <Badge
            variant={animal.status === 'available' ? 'success' : 'warning'}
          >
            {animal.status === 'available' ? 'Disponible' : 'En accueil'}
          </Badge>
        </div>
      </div>

      {/* Contenu */}
      <div className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h3 className="font-semibold text-lg text-gray-900">{animal.name}</h3>
            <p className="text-sm text-gray-600">
              {animal.breed} • {getSexText(animal.sex)} • {getAgeText(animal.age)} • {getSizeText(animal.size)}
            </p>
          </div>
          
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              icon={MoreVertical}
              onClick={() => setShowMenu(!showMenu)}
              className="text-gray-400 hover:text-gray-600"
            />
            
            {showMenu && (
              <div className="absolute right-0 top-8 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-1 z-10">
                <Link
                  to={`/animals/${animal.id}`}
                  className="flex items-center space-x-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
                  onClick={() => setShowMenu(false)}
                >
                  <Eye className="h-4 w-4" />
                  <span>Voir la fiche</span>
                </Link>
                <Link
                  to={`/animals/${animal.id}/edit`}
                  className="flex items-center space-x-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
                  onClick={() => setShowMenu(false)}
                >
                  <Edit className="h-4 w-4" />
                  <span>Modifier</span>
                </Link>
                <button
                  onClick={() => {
                    setShowDeleteConfirm(true);
                    setShowMenu(false);
                  }}
                  className="flex items-center space-x-2 px-4 py-2 text-sm text-error-600 hover:bg-error-50 w-full text-left"
                >
                  <Trash2 className="h-4 w-4" />
                  <span>Supprimer</span>
                </button>
              </div>
            )}
          </div>
        </div>

        <p className="text-sm text-gray-700 line-clamp-2 mb-3">
          {animal.description}
        </p>

        {/* Badges santé */}
        <div className="flex flex-wrap gap-2 mb-3">
          {animal.health.vaccinated && (
            <Badge variant="success" size="sm">Vacciné</Badge>
          )}
          {animal.health.sterilized && (
            <Badge variant="success" size="sm">Stérilisé</Badge>
          )}
        </div>

        {/* Informations de localisation et date */}
        <div className="flex items-center justify-between text-xs text-gray-500">
          <div className="flex items-center space-x-1">
            <MapPin className="h-3 w-3" />
            <span>{animal.location}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Calendar className="h-3 w-3" />
            <span>Créé le {animal.createdAt.toLocaleDateString('fr-FR')}</span>
          </div>
        </div>
      </div>

      {/* Modal de confirmation de suppression */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md mx-4">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Supprimer {animal.name} ?
            </h3>
            <p className="text-gray-600 mb-6">
              Cette action est irréversible. La fiche de l'animal sera définitivement supprimée.
            </p>
            <div className="flex space-x-3">
              <Button
                variant="outline"
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1"
              >
                Annuler
              </Button>
              <Button
                variant="danger"
                onClick={handleDelete}
                className="flex-1"
              >
                Supprimer
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}