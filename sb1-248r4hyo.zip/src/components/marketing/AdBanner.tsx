import React from 'react';
import { PartnerOffer } from '../../types';

interface AdBannerProps {
  partner: PartnerOffer;
}

export function AdBanner({ partner }: AdBannerProps) {
  const handleClick = () => {
    window.open(partner.offerUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div 
      onClick={handleClick}
      className="relative w-full h-24 md:h-32 bg-banner-orange-gradient rounded-lg overflow-hidden cursor-pointer shadow-md hover:shadow-lg transition-shadow duration-200"
      style={partner.backgroundColor ? { background: partner.backgroundColor } : {}}
    >
      {/* Product Image */}
      <div className="absolute left-0 bottom-0 h-full">
        <img 
          src={partner.productImageUrl} 
          alt="" 
          className="h-full object-contain max-w-[150px] md:max-w-[200px]"
        />
      </div>
      
      {/* Main Text */}
      <div className="flex items-center justify-center h-full">
        <h3 className="text-white text-xl md:text-3xl font-bold text-center px-4 md:px-0">
          {partner.title}
        </h3>
      </div>
      
      {/* Publicité Label */}
      <div className="absolute right-0 top-0 h-full flex items-center">
        <div className="transform rotate-90 origin-center translate-x-8 text-white/70 text-xs uppercase tracking-wider">
          publicité
        </div>
      </div>
    </div>
  );
}