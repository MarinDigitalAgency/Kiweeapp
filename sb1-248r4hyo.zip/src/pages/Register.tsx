import React, { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Mail, Lock, User, MapPin, Phone } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Card } from '../components/ui/Card';
import { UserType } from '../types';

export function Register() {
  const [searchParams] = useSearchParams();
  const initialType = (searchParams.get('type') as UserType) || 'family';
  
  const [userType, setUserType] = useState<UserType>(initialType);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    location: ''
  });
  const [error, setError] = useState('');
  const { register, loading } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (formData.password !== formData.confirmPassword) {
      setError('Les mots de passe ne correspondent pas');
      return;
    }

    if (formData.password.length < 6) {
      setError('Le mot de passe doit contenir au moins 6 caractères');
      return;
    }

    try {
      await register({
        name: formData.name,
        email: formData.email,
        type: userType,
        phone: formData.phone,
        location: formData.location
      }, formData.password);
      
      // Redirect based on user type
      if (userType === 'family') {
        navigate('/onboarding');
      } else if (userType === 'association') {
        navigate('/association-onboarding');
      } else {
        navigate('/dashboard');
      }
    } catch (err) {
      setError('Une erreur est survenue lors de l\'inscription');
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900">
            Créer votre compte
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            Déjà un compte ?{' '}
            <Link to="/login" className="font-medium text-primary-600 hover:text-primary-500">
              Connectez-vous
            </Link>
          </p>
        </div>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <Card>
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="bg-error-50 border border-error-200 text-error-700 px-4 py-3 rounded-md">
                {error}
              </div>
            )}

            {/* Type d'utilisateur */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Je suis...
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setUserType('family')}
                  className={`p-4 rounded-lg border-2 text-center transition-all ${
                    userType === 'family'
                      ? 'border-primary-500 bg-primary-50 text-primary-700'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-medium">Famille d'accueil</div>
                  <div className="text-xs text-gray-500 mt-1">
                    Je veux accueillir un animal
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => setUserType('association')}
                  className={`p-4 rounded-lg border-2 text-center transition-all ${
                    userType === 'association'
                      ? 'border-primary-500 bg-primary-50 text-primary-700'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-medium">Association</div>
                  <div className="text-xs text-gray-500 mt-1">
                    Je cherche des familles d'accueil
                  </div>
                </button>
              </div>
            </div>

            <Input
              label={userType === 'association' ? 'Nom de l\'association' : 'Nom complet'}
              type="text"
              value={formData.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              icon={User}
              required
            />

            <Input
              label="Adresse email"
              type="email"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              icon={Mail}
              required
            />

            <Input
              label="Téléphone"
              type="tel"
              value={formData.phone}
              onChange={(e) => handleInputChange('phone', e.target.value)}
              icon={Phone}
            />

            <Input
              label="Localisation"
              type="text"
              value={formData.location}
              onChange={(e) => handleInputChange('location', e.target.value)}
              icon={MapPin}
              placeholder="Ville, région..."
              required
            />

            <Input
              label="Mot de passe"
              type="password"
              value={formData.password}
              onChange={(e) => handleInputChange('password', e.target.value)}
              icon={Lock}
              required
            />

            <Input
              label="Confirmer le mot de passe"
              type="password"
              value={formData.confirmPassword}
              onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
              icon={Lock}
              required
            />

            <div className="flex items-center">
              <input
                id="terms"
                type="checkbox"
                required
                className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
              />
              <label htmlFor="terms" className="ml-2 block text-sm text-gray-900">
                J'accepte les{' '}
                <Link to="/terms" className="text-primary-600 hover:text-primary-500">
                  conditions d'utilisation
                </Link>{' '}
                et la{' '}
                <Link to="/privacy" className="text-primary-600 hover:text-primary-500">
                  politique de confidentialité
                </Link>
              </label>
            </div>

            <Button
              type="submit"
              loading={loading}
              className="w-full"
              size="lg"
              variant="kiweetoTeal"
            >
              Créer mon compte
            </Button>
          </form>
        </Card>
      </div>
    </div>
  );
}