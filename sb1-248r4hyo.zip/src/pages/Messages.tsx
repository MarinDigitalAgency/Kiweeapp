import React, { useState, useEffect } from 'react';
import { ArrowLeft } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { ConversationHeader } from '../components/messages/ConversationHeader';
import { ConversationList } from '../components/messages/ConversationList';
import { MessageBubble } from '../components/messages/MessageBubble';
import { MessageInput } from '../components/messages/MessageInput';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { 
  getUserConversations, 
  getConversationMessages, 
  createOrGetConversation, 
  saveMessageWithNotification,
  mockAnimals,
  getPredefinedMessagesForUser
} from '../data/mockData';
import { Message } from '../types';

export function Messages() {
  const { user } = useAuth();
  const [searchParams] = useSearchParams();
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);
  const [conversations, setConversations] = useState<any[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);

  // Get URL parameters for auto-creating conversations
  const animalId = searchParams.get('animalId');
  const familyId = searchParams.get('familyId');
  const associationId = searchParams.get('associationId');

  useEffect(() => {
    if (!user) return;

    // Load conversations for the current user
    const userConversations = getUserConversations(user.id, user.type);
    setConversations(userConversations);

    // Handle conversation creation from URL parameters
    if (animalId && ((user.type === 'family' && associationId) || (user.type === 'association' && familyId))) {
      let conversation;
      
      if (user.type === 'family' && associationId) {
        // Family contacting association about an animal
        conversation = createOrGetConversation(animalId, user.id, associationId);
      } else if (user.type === 'association' && familyId) {
        // Association contacting family about an animal
        conversation = createOrGetConversation(animalId, familyId, user.id);
      }

      if (conversation) {
        // Refresh conversations list
        const updatedConversations = getUserConversations(user.id, user.type);
        setConversations(updatedConversations);
        
        // Auto-select the conversation
        setSelectedConversationId(conversation.id);
      }
    }
  }, [user, animalId, familyId, associationId]);

  useEffect(() => {
    // Load messages for selected conversation
    if (selectedConversationId) {
      const conversationMessages = getConversationMessages(selectedConversationId);
      setMessages(conversationMessages);
    }
  }, [selectedConversationId]);

  const selectedConversation = conversations.find(conv => conv.id === selectedConversationId);
  const selectedAnimal = selectedConversation 
    ? mockAnimals.find(animal => animal.id === selectedConversation.animalId)
    : null;

  const handleSendMessage = (content: string) => {
    if (!selectedConversationId || !user) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      conversationId: selectedConversationId,
      senderId: user.id,
      senderName: user.name,
      content,
      timestamp: new Date(),
      read: false
    };

    saveMessageWithNotification(newMessage);
    setMessages(prev => [...prev, newMessage]);

    // Update conversations list to reflect new last message
    const updatedConversations = getUserConversations(user.id, user.type);
    setConversations(updatedConversations);
  };

  const handleBackToList = () => {
    setSelectedConversationId(null);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto h-screen flex">
        {/* Liste des conversations - Desktop */}
        <div className={`w-80 ${selectedConversationId ? 'hidden lg:block' : 'block'}`}>
          <ConversationList
            conversations={conversations}
            selectedConversationId={selectedConversationId || undefined}
            onSelectConversation={setSelectedConversationId}
          />
        </div>

        {/* Zone de conversation */}
        <div className={`flex-1 flex flex-col ${selectedConversationId ? 'block' : 'hidden lg:block'}`}>
          {selectedConversation && selectedAnimal ? (
            <>
              {/* Header mobile avec bouton retour */}
              <div className="lg:hidden">
                <div className="bg-white border-b border-gray-200 p-4 flex items-center space-x-3">
                  <Button
                    variant="ghost"
                    size="sm"
                    icon={ArrowLeft}
                    onClick={handleBackToList}
                  >
                    <span className="sr-only">Retour</span>
                  </Button>
                  <span className="font-medium text-gray-900">Messages</span>
                </div>
              </div>

              {/* En-tête de conversation */}
              <ConversationHeader
                animal={selectedAnimal}
                associationName={selectedConversation.participants.associationName}
              />

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map((message) => (
                  <MessageBubble key={message.id} message={message} />
                ))}
                
                {messages.length === 0 && (
                  <div className="text-center py-8">
                    <p className="text-gray-500">Aucun message dans cette conversation.</p>
                    <p className="text-sm text-gray-400 mt-1">
                      Commencez la conversation en envoyant un message !
                    </p>
                  </div>
                )}
              </div>

              {/* Input de message */}
              <MessageInput 
                onSendMessage={handleSendMessage}
                predefinedMessages={user ? getPredefinedMessagesForUser(user.type) : []}
                currentUserType={user?.type}
              />
            </>
          ) : (
            /* État vide - aucune conversation sélectionnée */
            <div className="flex-1 flex items-center justify-center p-8">
              <Card className="text-center max-w-md">
                <div className="py-8">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="h-8 w-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-3.582 8-8 8a8.955 8.955 0 01-4.126-.98L3 20l1.98-5.874A8.955 8.955 0 013 12c0-4.418 3.582-8 8-8s8 3.582 8 8z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    Sélectionnez une conversation
                  </h3>
                  <p className="text-gray-600">
                    Choisissez une conversation dans la liste pour commencer à échanger.
                  </p>
                </div>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}