import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { FamilyProfileForm } from '../components/profile/FamilyProfileForm';
import { AssociationProfileForm } from '../components/profile/AssociationProfileForm';
import { ProfileHeader } from '../components/profile/ProfileHeader';
import { ProfileNavigation } from '../components/profile/ProfileNavigation';
import { DocumentsSection } from '../components/profile/DocumentsSection';
import { BadgesSection } from '../components/profile/BadgesSection';
import { Card } from '../components/ui/Card';

type ProfileTab = 'general' | 'documents' | 'badges' | 'settings';

export function Profile() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<ProfileTab>('general');

  if (!user) {
    return null;
  }

  const renderTabContent = () => {
    switch (activeTab) {
      case 'general':
        return user.type === 'family' ? (
          <FamilyProfileForm />
        ) : (
          <AssociationProfileForm />
        );
      case 'documents':
        return <DocumentsSection />;
      case 'badges':
        return <BadgesSection />;
      case 'settings':
        return (
          <Card>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Paramètres du compte</h3>
            <p className="text-gray-600">Section des paramètres en cours de développement...</p>
          </Card>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <ProfileHeader />

        <div className="mt-8 grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Navigation */}
          <div className="lg:col-span-1">
            <ProfileNavigation
              activeTab={activeTab}
              onTabChange={setActiveTab}
              userType={user.type}
            />
          </div>

          {/* Content */}
          <div className="lg:col-span-3">
            {renderTabContent()}
          </div>
        </div>
      </div>
    </div>
  );
}