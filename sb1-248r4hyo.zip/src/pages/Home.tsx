import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { SuccessStories } from '../components/success/SuccessStories';
import { PartnerOffers } from '../components/marketing/PartnerOffers';
import { PartnerOffer } from '../types';
import { mockAnimals } from '../data/mockData';

export function Home() {
  const [selectedUserType, setSelectedUserType] = useState<'association' | 'family' | null>(null);

  // Partner offers data
  const partnerOffers: PartnerOffer[] = [
    {
      id: "1",
      title: "Les croquettes premium de Médor à prix cassé",
      productImageUrl: "https://images.pexels.com/photos/8434791/pexels-photo-8434791.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      offerUrl: "https://example.com/medor-offer"
    },
    {
      id: "2",
      title: "Assurance animaux : 3 mois offerts",
      productImageUrl: "https://images.pexels.com/photos/6568501/pexels-photo-6568501.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      offerUrl: "https://example.com/assurance-offer",
      backgroundColor: "linear-gradient(to right, #3B82F6, #2563EB)"
    },
    {
      id: "3",
      title: "Livraison gratuite avec le code KIWEETO",
      productImageUrl: "https://images.pexels.com/photos/5731866/pexels-photo-5731866.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      offerUrl: "https://example.com/petshop-offer",
      backgroundColor: "linear-gradient(to right, #10B981, #059669)"
    }
  ];

  // Get adopted animals for the decorative circles
  const adoptedAnimals = mockAnimals
    .filter(animal => animal.status === 'adopted' || animal.status === 'in_care')
    .slice(0, 3);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-kiweetoLightBlue-50 py-20 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="space-y-6">
                <h1 className="text-4xl md:text-4xl font-bold leading-tight text-kiweetoTeal-800">
                  La plateforme<br />
                  qui connecte<br />
                  les associations<br />
                  avec des familles d'accueil<br />
                  (temporaires)
                </h1>
                <p className="text-xl text-gray-600 max-w-lg">
                  Garder bénévolement, aimer inconditionnellement - La plateforme des associations, créée par une association.
                </p>
              </div>

              {/* Decorative circles with adopted animals */}
              <div className="flex space-x-4">
                {adoptedAnimals.map((animal, index) => (
                  <div
                    key={animal.id}
                    className="w-16 h-16 rounded-full overflow-hidden border-4 border-white shadow-lg"
                    style={{
                      transform: `translateX(${index * -8}px)`,
                      zIndex: 3 - index
                    }}
                  >
                    <img
                      src={animal.photos[0]}
                      alt={`${animal.name} - Animal adopté`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ))}
              </div>
              
              <Link to="/search" className="mt-6 block">
                <Button 
                  variant="kiweetoTealOutline"
                  size="lg" 
                  className="px-8 w-full max-w-md"
                >
                  Ils cherchent une famille temporaire
                </Button>
              </Link>
            </div>

            {/* Right Content - Cards */}
            <div className="flex flex-col items-center space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-md">
                {/* Association Card */}
                <div onClick={() => setSelectedUserType('association')}>
                  <Card className={`relative transition-all duration-200 cursor-pointer p-6 text-center ${
                    selectedUserType === 'association'
                      ? 'bg-kiweetoTeal-100 border-2 border-kiweetoTeal-400 shadow-lg ring-2 ring-kiweetoTeal-300 hover:scale-[1.02]'
                      : 'bg-kiweetoTeal-50 hover:scale-[1.02]'
                  }`}>
                    <div className="flex flex-col items-center space-y-3">
                      <div className="w-24 h-24 flex items-center justify-center">
                        <img
                          src="/association.png"
                          alt="Association illustration"
                          className="w-full h-full object-contain"
                        />
                      </div>
                      <div className="text-center">
                        <div className="font-semibold text-gray-900 mb-1">Association</div>
                        <div className="text-sm text-gray-600">Je cherche une famille d'accueil</div>
                      </div>
                    </div>
                  </Card>
                </div>

                {/* Particulier Card */}
                <div onClick={() => setSelectedUserType('family')}>
                  <Card className={`relative transition-all duration-200 cursor-pointer p-6 text-center ${
                    selectedUserType === 'family'
                      ? 'bg-kiweetoTeal-100 border-2 border-kiweetoTeal-400 shadow-lg ring-2 ring-kiweetoTeal-300 hover:scale-[1.02]'
                      : 'bg-kiweetoTeal-50 hover:scale-[1.02]'
                  }`}>
                    <div className="flex flex-col items-center space-y-3">
                      <div className="w-24 h-24 flex items-center justify-center">
                        <img
                          src="/particulier.png"
                          alt="Particulier illustration"
                          className="w-full h-full object-contain"
                        />
                      </div>
                      <div className="text-center">
                        <div className="font-semibold text-gray-900 mb-1">Particulier</div>
                        <div className="text-sm text-gray-600">Je souhaite accueillir un animal</div>
                      </div>
                    </div>
                  </Card>
                </div>
              </div>

              {/* Dynamic CTA button */}
              {selectedUserType && (
                <Link 
                  to={selectedUserType === 'association' ? '/register?type=association' : '/register?type=family'}
                  className="w-full max-w-md"
                >
                  <Button 
                    variant="kiweetoTeal"
                    size="lg" 
                    className="px-8 w-full"
                  >
                    {selectedUserType === 'association' ? 'Confier mes animaux' : 'Accueillir un animal'}
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Success Stories */}
      <SuccessStories />

      {/* Partner Offers */}
      <PartnerOffers partners={partnerOffers} />

      {/* CTA Section */}
      <section className="py-20 bg-kiweetoTeal-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-8">
            <h2 className="text-3xl font-bold text-white">
              Prêt à faire la différence ?
            </h2>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              Rejoignez notre communauté et participez à sauver des vies. 
              Chaque geste compte, chaque animal mérite une seconde chance.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/register">
                <Button 
                  variant="kiweetoTeal" 
                  size="lg" 
                  icon={ArrowRight}
                  iconPosition="right"
                  className="px-8"
                >
                  Commencer maintenant
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}