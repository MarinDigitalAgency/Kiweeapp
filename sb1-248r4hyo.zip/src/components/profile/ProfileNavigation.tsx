import React from 'react';
import { User, FileText, Award, Settings } from 'lucide-react';
import { UserType } from '../../types';

interface ProfileNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  userType: UserType;
}

export function ProfileNavigation({ activeTab, onTabChange, userType }: ProfileNavigationProps) {
  const tabs = [
    {
      id: 'general',
      label: 'Informations générales',
      icon: User,
      description: userType === 'family' 
        ? 'Logement, animaux acceptés, expérience'
        : 'Informations légales, certifications'
    },
    {
      id: 'documents',
      label: 'Documents',
      icon: FileText,
      description: 'Pièces justificatives et vérifications'
    },
    {
      id: 'badges',
      label: 'Badges & Certifications',
      icon: Award,
      description: 'Badges de confiance et certifications'
    },
    {
      id: 'settings',
      label: 'Paramètres',
      icon: Settings,
      description: 'Confidentialité et notifications'
    }
  ];

  return (
    <nav className="space-y-2">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        
        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`w-full text-left p-4 rounded-lg transition-all duration-200 ${
              isActive
                ? 'bg-primary-50 border-2 border-primary-200 text-primary-700'
                : 'bg-white border-2 border-gray-100 text-gray-700 hover:bg-gray-50 hover:border-gray-200'
            }`}
          >
            <div className="flex items-start space-x-3">
              <Icon className={`h-5 w-5 mt-0.5 ${isActive ? 'text-primary-600' : 'text-gray-400'}`} />
              <div>
                <div className={`font-medium ${isActive ? 'text-primary-900' : 'text-gray-900'}`}>
                  {tab.label}
                </div>
                <div className={`text-sm mt-1 ${isActive ? 'text-primary-600' : 'text-gray-500'}`}>
                  {tab.description}
                </div>
              </div>
            </div>
          </button>
        );
      })}
    </nav>
  );
}