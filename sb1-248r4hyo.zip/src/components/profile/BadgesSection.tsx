import React from 'react';
import { Shield, Star, Award, Mail, Phone, CheckCircle, Clock } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

export function BadgesSection() {
  const { user } = useAuth();

  if (!user) return null;

  const badges = user.profile?.badges || {
    isProfileVerified: false,
    isEmailVerified: true,
    isPhoneVerified: false,
    isTopFosterFamily: false,
    isExperiencedFA: false,
    isCertifiedAssociation: false,
    isRnaVerified: false,
    hasCompletedProfile: false
  };

  const getBadgeInfo = () => {
    const commonBadges = [
      {
        key: 'isEmailVerified',
        icon: Mail,
        title: 'Email vérifié',
        description: 'Votre adresse email a été vérifiée',
        earned: badges.isEmailVerified,
        color: 'success'
      },
      {
        key: 'isPhoneVerified',
        icon: Phone,
        title: 'Téléphone vérifié',
        description: 'Votre numéro de téléphone a été vérifié',
        earned: badges.isPhoneVerified,
        color: 'success',
        action: !badges.isPhoneVerified ? 'Vérifier mon téléphone' : undefined
      },
      {
        key: 'isProfileVerified',
        icon: Shield,
        title: 'Profil vérifié',
        description: 'Votre identité a été vérifiée par nos équipes',
        earned: badges.isProfileVerified,
        color: 'primary'
      },
      {
        key: 'hasCompletedProfile',
        icon: CheckCircle,
        title: 'Profil complet',
        description: 'Vous avez rempli toutes les sections de votre profil',
        earned: badges.hasCompletedProfile,
        color: 'secondary',
        action: !badges.hasCompletedProfile ? 'Compléter mon profil' : undefined
      }
    ];

    const familyBadges = [
      {
        key: 'isTopFosterFamily',
        icon: Star,
        title: 'Top Famille d\'accueil',
        description: 'Vous êtes parmi les familles d\'accueil les mieux notées',
        earned: badges.isTopFosterFamily,
        color: 'warning',
        criteria: 'Note moyenne ≥ 4.5/5 sur au moins 10 accueils'
      },
      {
        key: 'isExperiencedFA',
        icon: Award,
        title: 'Famille d\'accueil expérimentée',
        description: 'Vous avez de l\'expérience dans l\'accueil d\'animaux',
        earned: badges.isExperiencedFA,
        color: 'secondary',
        criteria: 'Plus de 5 accueils réalisés avec succès'
      }
    ];

    const associationBadges = [
      {
        key: 'isRnaVerified',
        icon: Shield,
        title: 'RNA vérifié',
        description: 'Votre numéro RNA a été vérifié automatiquement',
        earned: badges.isRnaVerified,
        color: 'primary'
      },
      {
        key: 'isCertifiedAssociation',
        icon: Award,
        title: 'Association certifiée',
        description: 'Vous possédez les certifications ACACED requises',
        earned: badges.isCertifiedAssociation,
        color: 'secondary',
        criteria: 'Certification ACACED valide'
      }
    ];

    if (user.type === 'family') {
      return [...commonBadges, ...familyBadges];
    } else {
      return [...commonBadges, ...associationBadges];
    }
  };

  const BadgeCard = ({ badge }: { badge: any }) => {
    const Icon = badge.icon;
    
    return (
      <Card className={`p-4 ${badge.earned ? 'border-2 border-success-200 bg-success-50' : 'border-2 border-gray-200'}`}>
        <div className="flex items-start space-x-3">
          <div className={`p-2 rounded-full ${
            badge.earned 
              ? 'bg-success-100 text-success-600' 
              : 'bg-gray-100 text-gray-400'
          }`}>
            <Icon className="h-5 w-5" />
          </div>
          
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-1">
              <h4 className="font-medium text-gray-900">{badge.title}</h4>
              {badge.earned ? (
                <Badge variant="success" size="sm">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Obtenu
                </Badge>
              ) : (
                <Badge variant="neutral" size="sm">
                  <Clock className="h-3 w-3 mr-1" />
                  Non obtenu
                </Badge>
              )}
            </div>
            
            <p className="text-sm text-gray-600 mb-2">{badge.description}</p>
            
            {badge.criteria && (
              <p className="text-xs text-gray-500 mb-3">
                <strong>Critère :</strong> {badge.criteria}
              </p>
            )}
            
            {badge.action && (
              <Button size="sm" variant="outline">
                {badge.action}
              </Button>
            )}
          </div>
        </div>
      </Card>
    );
  };

  const earnedBadges = getBadgeInfo().filter(badge => badge.earned);
  const availableBadges = getBadgeInfo().filter(badge => !badge.earned);

  return (
    <div className="space-y-6">
      {/* Badges obtenus */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Mes badges ({earnedBadges.length})
        </h3>
        
        {earnedBadges.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {earnedBadges.map((badge) => (
              <BadgeCard key={badge.key} badge={badge} />
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <Award className="h-12 w-12 text-gray-300 mx-auto mb-4" />
            <h4 className="text-lg font-medium text-gray-900 mb-2">Aucun badge obtenu</h4>
            <p className="text-gray-600">
              Complétez votre profil et vérifiez vos informations pour obtenir vos premiers badges.
            </p>
          </div>
        )}
      </Card>

      {/* Badges disponibles */}
      {availableBadges.length > 0 && (
        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Badges disponibles ({availableBadges.length})
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {availableBadges.map((badge) => (
              <BadgeCard key={badge.key} badge={badge} />
            ))}
          </div>
        </Card>
      )}

      {/* Informations sur les badges */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">À propos des badges</h3>
        <div className="space-y-3 text-sm text-gray-600">
          <p>• Les badges augmentent votre crédibilité et votre visibilité sur la plateforme</p>
          <p>• Certains badges sont automatiques (vérification email, RNA), d'autres nécessitent une validation manuelle</p>
          <p>• Les badges de performance (Top FA, Expérimenté) sont mis à jour automatiquement</p>
          <p>• Vous pouvez afficher vos badges sur votre profil public</p>
        </div>
      </Card>
    </div>
  );
}