import React, { useState } from 'react';
import { Plus, Search } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Animal } from '../../types';
import { AnimalListItem } from './AnimalListItem';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Input } from '../ui/Input';

interface AnimalManagementListProps {
  animals: Animal[];
  onStatusChange: (animalId: string, newStatus: Animal['status']) => void;
}

export function AnimalManagementList({ animals, onStatusChange }: AnimalManagementListProps) {
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<Animal['status']>('available');
  const [searchTerm, setSearchTerm] = useState('');
  const [notification, setNotification] = useState<string | null>(null);

  // Filter animals based on selected status and search term
  const filteredAnimals = animals.filter(animal => {
    const matchesStatus = animal.status === selectedStatusFilter;
    const matchesSearch = animal.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         animal.breed?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const handleStatusChange = (animalId: string, newStatus: Animal['status']) => {
    onStatusChange(animalId, newStatus);
    
    // Show success notification
    const animal = animals.find(a => a.id === animalId);
    if (animal) {
      const statusLabels = {
        available: 'Recherche famille',
        in_care: 'Démarche d\'adoption en cours',
        adopted: 'A trouvé une famille'
      };
      setNotification(`✅ Statut de ${animal.name} mis à jour : ${statusLabels[newStatus]}`);
      setTimeout(() => setNotification(null), 3000);
    }
  };

  const getStatusCounts = () => {
    return {
      available: animals.filter(a => a.status === 'available').length,
      in_care: animals.filter(a => a.status === 'in_care').length,
      adopted: animals.filter(a => a.status === 'adopted').length
    };
  };

  const statusCounts = getStatusCounts();
  const totalAnimals = animals.length;

  const statusFilters = [
    {
      id: 'available' as const,
      label: '🟡 Recherche une famille',
      count: statusCounts.available,
      color: 'border-warning-300 bg-warning-50 text-warning-700'
    },
    {
      id: 'in_care' as const,
      label: '🟠 Démarche d\'adoption en cours',
      count: statusCounts.in_care,
      color: 'border-kiweetoOrange-300 bg-kiweetoOrange-50 text-kiweetoOrange-700'
    },
    {
      id: 'adopted' as const,
      label: '🟢 A trouvé une famille',
      count: statusCounts.adopted,
      color: 'border-success-300 bg-success-50 text-success-700'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Mes animaux disponibles à l'adoption</h2>
          <p className="text-gray-600 mt-1">{totalAnimals} au total</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
          <Input
            placeholder="Rechercher par nom..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            icon={Search}
            className="w-full sm:w-64"
          />
          <Button as={Link} to="/animals/new" icon={Plus} variant="kiweetoTeal">
            Ajouter un animal
          </Button>
        </div>
      </div>

      {/* Success notification */}
      {notification && (
        <div className="fixed top-4 right-4 bg-success-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-slide-up">
          {notification}
        </div>
      )}

      {/* Status Filter Bar */}
      <div className="flex flex-wrap gap-3">
        {statusFilters.map((filter) => (
          <button
            key={filter.id}
            onClick={() => setSelectedStatusFilter(filter.id)}
            className={`px-4 py-3 rounded-lg border-2 font-medium text-sm transition-all duration-200 hover:shadow-md ${
              selectedStatusFilter === filter.id
                ? filter.color + ' shadow-sm'
                : 'border-gray-200 bg-white text-gray-600 hover:border-gray-300'
            }`}
          >
            {filter.label} ({filter.count})
          </button>
        ))}
      </div>

      {/* Animals List */}
      {filteredAnimals.length > 0 ? (
        <div className="space-y-4">
          {filteredAnimals.map((animal) => (
            <AnimalListItem
              key={animal.id}
              animal={animal}
              onChangeStatus={handleStatusChange}
            />
          ))}
        </div>
      ) : (
        /* Empty State */
        <Card className="text-center py-16">
          <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <span className="text-4xl">
              {selectedStatusFilter === 'available' ? '🟡' : 
               selectedStatusFilter === 'in_care' ? '🟠' : '🟢'}
            </span>
          </div>
          <h3 className="text-xl font-bold text-gray-900 mb-4">
            {searchTerm 
              ? 'Aucun animal trouvé'
              : `Aucun animal dans cette étape`
            }
          </h3>
          <p className="text-gray-600 mb-8 max-w-md mx-auto">
            {searchTerm 
              ? 'Aucun animal ne correspond à votre recherche. Essayez avec un autre terme.'
              : selectedStatusFilter === 'available' 
                ? 'Tous vos animaux ont trouvé une famille ou sont en cours d\'adoption !'
                : selectedStatusFilter === 'in_care'
                ? 'Aucune démarche d\'adoption en cours pour le moment.'
                : 'Aucun animal n\'a encore trouvé sa famille définitive.'
            }
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {!searchTerm && totalAnimals === 0 && (
              <Button as={Link} to="/animals/new" icon={Plus} variant="kiweetoTeal" size="lg">
                Ajouter votre premier animal
              </Button>
            )}
            {searchTerm && (
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => setSearchTerm('')}
              >
                Effacer la recherche
              </Button>
            )}
          </div>
        </Card>
      )}
    </div>
  );
}