import React from 'react';
import { MapPin, Heart, MessageCircle, Calendar, Users, Star } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { Animal } from '../../types';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface AnimalCardProps {
  animal: Animal;
  onFavorite?: (id: string) => void;
  onMessage?: (id: string) => void;
  isFavorited?: boolean;
  showActions?: boolean;
}

export function AnimalCard({ 
  animal, 
  onFavorite, 
  onMessage, 
  isFavorited = false, 
  showActions = true 
}: AnimalCardProps) {
  const navigate = useNavigate();

  const getAgeText = (age: number) => {
    return age > 1 ? `${age} ans` : `${age} an`;
  };

  const getSexText = (sex: string) => {
    const sexMap = {
      male: 'Mâle',
      female: 'Femelle'
    };
    return sexMap[sex as keyof typeof sexMap] || sex;
  };

  const getSizeText = (size: string) => {
    const sizeMap = {
      petit: 'Petit',
      moyen: 'Moyen',
      grand: 'Grand'
    };
    return sizeMap[size as keyof typeof sizeMap] || size;
  };

  const getTypeText = (type: string) => {
    const typeMap = {
      chien: 'Chien',
      chat: 'Chat',
      autre: 'Autre'
    };
    return typeMap[type as keyof typeof typeMap] || type;
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`h-3 w-3 ${
          index < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
        }`}
      />
    ));
  };

  const handleContactClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    // Navigate to messages page with animal and association info
    navigate(`/messages?animalId=${animal.id}&associationId=${animal.associationId}`);
  };

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onFavorite?.(animal.id);
  };

  return (
    <Link to={`/animal/${animal.id}`} className="block">
      <Card padding="none" hover className="overflow-hidden">
        {/* Image */}
        <div className="relative h-48 overflow-hidden">
          <img
            src={animal.photos[0]}
            alt={animal.name}
            className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
          />
          <div className="absolute top-3 left-3">
            <Badge variant="primary">
              {getTypeText(animal.type)}
            </Badge>
          </div>
          {showActions && (
            <button
              onClick={handleFavoriteClick}
              className={`absolute top-3 right-3 p-2 rounded-full transition-all duration-200 ${
                isFavorited 
                  ? 'bg-error-500 text-white' 
                  : 'bg-white/80 text-gray-600 hover:bg-white hover:text-error-500'
              }`}
            >
              <Heart className={`h-4 w-4 ${isFavorited ? 'fill-current' : ''}`} />
            </button>
          )}
        </div>

        {/* Content */}
        <div className="p-4 space-y-3">
          <div>
            <h3 className="font-semibold text-lg text-gray-900">{animal.name}</h3>
            <p className="text-sm text-gray-600">
              {animal.breed} • {getSexText(animal.sex)} • {getAgeText(animal.age)} • {getSizeText(animal.size)}
            </p>
          </div>

          <p className="text-sm text-gray-700 line-clamp-2">
            {animal.description}
          </p>

          {/* Health indicators */}
          <div className="flex flex-wrap gap-2">
            {animal.health.vaccinated && (
              <Badge variant="success" size="sm">Vacciné</Badge>
            )}
            {animal.health.sterilized && (
              <Badge variant="success" size="sm">Stérilisé</Badge>
            )}
          </div>

          {/* Compatibility */}
          <div className="flex items-center space-x-4 text-xs text-gray-500">
            {animal.compatibility.withDogs && (
              <div className="flex items-center space-x-1">
                <Users className="h-3 w-3" />
                <span>Chiens OK</span>
              </div>
            )}
            {animal.compatibility.withCats && (
              <div className="flex items-center space-x-1">
                <Users className="h-3 w-3" />
                <span>Chats OK</span>
              </div>
            )}
            {animal.compatibility.withChildren && (
              <div className="flex items-center space-x-1">
                <Users className="h-3 w-3" />
                <span>Enfants OK</span>
              </div>
            )}
          </div>

          {/* Location and date */}
          <div className="flex items-center justify-between text-sm text-gray-500">
            <div className="flex items-center space-x-1">
              <MapPin className="h-4 w-4" />
              <span>{animal.location}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Calendar className="h-4 w-4" />
              <span>Dispo. {animal.availableFrom.toLocaleDateString('fr-FR')}</span>
            </div>
          </div>

          {/* Association info with rating */}
          <div className="flex items-center justify-between text-sm">
            <div className="text-gray-500">
              Par {animal.associationName}
            </div>
            {animal.associationRating && (
              <div className="flex items-center space-x-1">
                <div className="flex items-center">
                  {renderStars(animal.associationRating)}
                </div>
                <span className="text-xs text-gray-500">
                  ({animal.associationRating}/5)
                </span>
              </div>
            )}
          </div>

          {showActions && (
            <div className="pt-2 border-t border-gray-100">
              <Button
                size="sm"
                icon={MessageCircle}
                onClick={handleContactClick}
                className="w-full"
              >
                Contacter
              </Button>
            </div>
          )}
        </div>
      </Card>
    </Link>
  );
}