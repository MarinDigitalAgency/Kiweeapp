import React, { useState, useEffect } from 'react';
import { Bell, Check, CheckCheck, Trash2, Settings, Filter, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { 
  getUserNotifications, 
  markNotificationAsRead, 
  markAllNotificationsAsRead,
  getStoredNotifications
} from '../data/mockData';
import { Notification, NotificationType } from '../types';

export function Notifications() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [filter, setFilter] = useState<'all' | 'unread' | NotificationType>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    loadNotifications();
  }, [user, navigate]);

  const loadNotifications = () => {
    if (!user) return;
    
    setLoading(true);
    const userNotifications = getUserNotifications(user.id);
    setNotifications(userNotifications);
    setLoading(false);
  };

  const handleNotificationClick = (notification: Notification) => {
    // Mark as read if not already read
    if (!notification.read) {
      markNotificationAsRead(notification.id);
      setNotifications(prev => 
        prev.map(n => 
          n.id === notification.id 
            ? { ...n, read: true, readAt: new Date() }
            : n
        )
      );
    }

    // Navigate to relevant page if URL is provided
    if (notification.data?.url) {
      navigate(notification.data.url);
    }
  };

  const handleMarkAllAsRead = () => {
    if (!user) return;
    
    markAllNotificationsAsRead(user.id);
    setNotifications(prev => 
      prev.map(n => ({ ...n, read: true, readAt: new Date() }))
    );
  };

  const handleDeleteNotification = (notificationId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    
    // Remove from local state
    setNotifications(prev => prev.filter(n => n.id !== notificationId));
    
    // Remove from storage
    const allNotifications = getStoredNotifications();
    const filteredNotifications = allNotifications.filter(n => n.id !== notificationId);
    localStorage.setItem('kiweeto_notifications', JSON.stringify(filteredNotifications));
  };

  const getNotificationIcon = (type: NotificationType) => {
    switch (type) {
      case 'new_message':
        return '💬';
      case 'adoption_request_status':
        return '📋';
      case 'animal_liked':
        return '❤️';
      case 'new_animal_available':
        return '🐾';
      case 'profile_verification':
        return '✅';
      case 'reminder':
        return '⏰';
      case 'system_announcement':
        return '📢';
      default:
        return '🔔';
    }
  };

  const getNotificationBadgeVariant = (category: Notification['category']) => {
    switch (category) {
      case 'success':
        return 'success';
      case 'warning':
        return 'warning';
      case 'error':
        return 'error';
      default:
        return 'neutral';
    }
  };

  const filteredNotifications = notifications.filter(notification => {
    if (filter === 'all') return true;
    if (filter === 'unread') return !notification.read;
    return notification.type === filter;
  });

  const unreadCount = notifications.filter(n => !n.read).length;

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) {
      return `${days}j`;
    } else if (hours > 0) {
      return `${hours}h`;
    } else if (minutes > 0) {
      return `${minutes}min`;
    } else {
      return 'maintenant';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                icon={ArrowLeft}
                onClick={() => navigate('/dashboard')}
                className="text-gray-600"
              >
                Retour
              </Button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900 flex items-center space-x-2">
                  <Bell className="h-6 w-6 text-primary-600" />
                  <span>Notifications</span>
                </h1>
                <p className="text-gray-600 mt-1">
                  {unreadCount > 0 ? (
                    `${unreadCount} notification${unreadCount > 1 ? 's' : ''} non lue${unreadCount > 1 ? 's' : ''}`
                  ) : (
                    'Toutes vos notifications sont lues'
                  )}
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              {unreadCount > 0 && (
                <Button
                  variant="outline"
                  icon={CheckCheck}
                  onClick={handleMarkAllAsRead}
                  size="sm"
                >
                  Tout marquer comme lu
                </Button>
              )}
              <Button
                variant="ghost"
                icon={Settings}
                size="sm"
                className="text-gray-500"
              >
                Paramètres
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Filters */}
        <Card className="mb-6">
          <div className="flex items-center space-x-2 overflow-x-auto">
            <Filter className="h-4 w-4 text-gray-500 flex-shrink-0" />
            <div className="flex space-x-2">
              <button
                onClick={() => setFilter('all')}
                className={`px-3 py-1 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${
                  filter === 'all'
                    ? 'bg-primary-100 text-primary-700'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                Toutes ({notifications.length})
              </button>
              <button
                onClick={() => setFilter('unread')}
                className={`px-3 py-1 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${
                  filter === 'unread'
                    ? 'bg-primary-100 text-primary-700'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                Non lues ({unreadCount})
              </button>
              <button
                onClick={() => setFilter('new_message')}
                className={`px-3 py-1 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${
                  filter === 'new_message'
                    ? 'bg-primary-100 text-primary-700'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                Messages
              </button>
              <button
                onClick={() => setFilter('adoption_request_status')}
                className={`px-3 py-1 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${
                  filter === 'adoption_request_status'
                    ? 'bg-primary-100 text-primary-700'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                Demandes
              </button>
              <button
                onClick={() => setFilter('animal_liked')}
                className={`px-3 py-1 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${
                  filter === 'animal_liked'
                    ? 'bg-primary-100 text-primary-700'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                Favoris
              </button>
            </div>
          </div>
        </Card>

        {/* Notifications List */}
        <div className="space-y-3">
          {filteredNotifications.length > 0 ? (
            filteredNotifications.map((notification) => (
              <Card
                key={notification.id}
                className={`cursor-pointer transition-all duration-200 hover:shadow-md ${
                  !notification.read 
                    ? 'border-l-4 border-l-primary-500 bg-primary-50/30' 
                    : 'hover:bg-gray-50'
                }`}
                onClick={() => handleNotificationClick(notification)}
              >
                <div className="flex items-start space-x-4">
                  {/* Icon */}
                  <div className="flex-shrink-0">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      !notification.read ? 'bg-primary-100' : 'bg-gray-100'
                    }`}>
                      <span className="text-lg">
                        {getNotificationIcon(notification.type)}
                      </span>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h3 className={`font-medium ${
                            !notification.read ? 'text-gray-900' : 'text-gray-700'
                          }`}>
                            {notification.title}
                          </h3>
                          {!notification.read && (
                            <div className="w-2 h-2 bg-primary-500 rounded-full"></div>
                          )}
                          {notification.category && (
                            <Badge 
                              variant={getNotificationBadgeVariant(notification.category)}
                              size="sm"
                            >
                              {notification.category}
                            </Badge>
                          )}
                        </div>
                        <p className={`text-sm ${
                          !notification.read ? 'text-gray-700' : 'text-gray-600'
                        }`}>
                          {notification.message}
                        </p>
                        
                        {/* Additional info */}
                        {notification.data?.animalName && (
                          <div className="flex items-center space-x-2 mt-2 text-xs text-gray-500">
                            <span>🐾</span>
                            <span>{notification.data.animalName}</span>
                            {notification.data.associationName && (
                              <>
                                <span>•</span>
                                <span>{notification.data.associationName}</span>
                              </>
                            )}
                          </div>
                        )}
                      </div>

                      {/* Actions */}
                      <div className="flex items-center space-x-2 ml-4">
                        <span className="text-xs text-gray-500 whitespace-nowrap">
                          {formatTime(notification.createdAt)}
                        </span>
                        <button
                          onClick={(e) => handleDeleteNotification(notification.id, e)}
                          className="p-1 text-gray-400 hover:text-error-600 transition-colors"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            ))
          ) : (
            <Card className="text-center py-12">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Bell className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                {filter === 'unread' ? 'Aucune notification non lue' : 'Aucune notification'}
              </h3>
              <p className="text-gray-600">
                {filter === 'unread' 
                  ? 'Toutes vos notifications ont été lues !'
                  : 'Vous recevrez ici toutes vos notifications importantes.'
                }
              </p>
            </Card>
          )}
        </div>

        {/* Help Section */}
        <Card className="mt-8 bg-blue-50 border-blue-200">
          <div className="flex items-start space-x-3">
            <div className="bg-blue-100 p-2 rounded-full">
              <Bell className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <h3 className="font-semibold text-blue-900 mb-2">
                À propos des notifications
              </h3>
              <div className="text-blue-800 text-sm space-y-1">
                <p>• Vous recevez des notifications pour les nouveaux messages, les mises à jour de demandes d'accueil, et les nouveaux animaux correspondant à vos critères</p>
                <p>• Cliquez sur une notification pour accéder directement à la page concernée</p>
                <p>• Vous pouvez gérer vos préférences de notification dans les paramètres</p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}