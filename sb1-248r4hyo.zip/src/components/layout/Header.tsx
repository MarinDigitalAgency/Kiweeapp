import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { User, MessageCircle, Bell, LogOut, Menu } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '../ui/Button';
import { getUnreadMessageCount, getUnreadNotificationCount } from '../../data/mockData';

export function Header() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  // Get unread message count for the current user
  const unreadCount = user ? getUnreadMessageCount(user.id, user.type) : 0;
  
  // Get unread notification count for the current user
  const unreadNotificationCount = user ? getUnreadNotificationCount(user.id) : 0;

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  // Determine search link based on user type
  const getSearchLink = () => {
    if (!user) return '/search';
    return user.type === 'association' ? '/search-families' : '/search';
  };

  const getSearchLabel = () => {
    if (!user) return 'Rechercher';
    return user.type === 'association' ? 'Rechercher des familles' : 'Rechercher des animaux';
  };

  return (
    <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <img 
              src="/kiweeto-logo.png" 
              alt="Kiweeto" 
              className="h-10 w-auto"
            />
          </Link>

          {/* Navigation */}
          {user ? (
            <div className="flex items-center space-x-4">
              <Link
                to="/dashboard"
                className="text-gray-700 hover:text-kiweetoTeal-600 px-3 py-2 rounded-md text-sm font-medium transition-colors"
              >
                Tableau de bord
              </Link>
              
              <Link
                to={getSearchLink()}
                className="text-gray-700 hover:text-kiweetoTeal-600 px-3 py-2 rounded-md text-sm font-medium transition-colors"
                title={getSearchLabel()}
              >
                Rechercher
              </Link>

              {user.type === 'family' && (
                <Link
                  to="/swipe"
                  className="text-gray-700 hover:text-kiweetoTeal-600 px-3 py-2 rounded-md text-sm font-medium transition-colors"
                >
                  Découvrir
                </Link>
              )}

              <Link
                to="/messages"
                className="relative text-gray-700 hover:text-kiweetoTeal-600 p-2 rounded-md transition-colors"
              >
                <MessageCircle className="h-5 w-5" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-error-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </Link>

              <Link
                to="/notifications" 
                className="relative text-gray-700 hover:text-kiweetoTeal-600 p-2 rounded-md transition-colors"
              >
                <Bell className="h-5 w-5" />
                {unreadNotificationCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-error-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {unreadNotificationCount > 9 ? '9+' : unreadNotificationCount}
                  </span>
                )}
              </Link>

              <div className="flex items-center space-x-3">
                <Link
                  to="/profile"
                  className="flex items-center space-x-2 text-gray-700 hover:text-kiweetoTeal-600 px-3 py-2 rounded-md text-sm font-medium transition-colors"
                >
                  <User className="h-4 w-4" />
                  <span className="hidden sm:block">{user.name}</span>
                </Link>
                
                <Button
                  variant="ghost"
                  size="sm"
                  icon={LogOut}
                  onClick={handleLogout}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <span className="sr-only">Déconnexion</span>
                </Button>
              </div>
            </div>
          ) : (
            <div className="flex items-center space-x-4">
              <Link
                to="/login"
                className="text-gray-700 hover:text-kiweetoTeal-600 px-3 py-2 rounded-md text-sm font-medium transition-colors"
              >
                Connexion
              </Link>
              <Link to="/register">
                <Button size="sm" variant="kiweetoTeal">
                  S'inscrire
                </Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}