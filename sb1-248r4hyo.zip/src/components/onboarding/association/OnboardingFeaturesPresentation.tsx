import React, { useState } from 'react';
import { BookOpen, ArrowRight, ArrowLeft, Users, MessageCircle, BarChart3, FileText, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '../../ui/Button';
import { Card } from '../../ui/Card';

interface OnboardingFeaturesPresentationProps {
  onNext: () => void;
  onPrev: () => void;
}

export function OnboardingFeaturesPresentation({ onNext, onPrev }: OnboardingFeaturesPresentationProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const featureSlides = [
    {
      title: 'Gestion des animaux',
      icon: Users,
      content: (
        <div className="space-y-4">
          <div className="bg-gray-100 rounded-lg p-4">
            <img 
              src="https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&cs=tinysrgb&w=400" 
              alt="Gestion des animaux"
              className="w-full h-32 object-cover rounded-lg mb-3"
            />
            <p className="text-sm text-gray-600">
              Créez et gérez facilement les fiches de vos animaux avec toutes les informations 
              nécessaires : santé, comportement, besoins spécifiques.
            </p>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Fiches détaillées avec photos et descriptions</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Suivi des statuts : disponible, en accueil, adopté</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Informations médicales sécurisées</span>
            </div>
          </div>
        </div>
      )
    },
    {
      title: 'Recherche de familles',
      icon: Users,
      content: (
        <div className="space-y-4">
          <div className="bg-gray-100 rounded-lg p-4">
            <div className="flex items-center justify-center h-32 bg-gradient-to-br from-blue-100 to-purple-100 rounded-lg mb-3">
              <Users className="h-12 w-12 text-blue-500" />
            </div>
            <p className="text-sm text-gray-600">
              Trouvez des familles d'accueil qualifiées grâce à notre système de filtres avancés 
              et de matching automatique.
            </p>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Filtres par localisation, expérience, capacités</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Profils vérifiés et badges de confiance</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Notifications d'intérêt automatiques</span>
            </div>
          </div>
        </div>
      )
    },
    {
      title: 'Messagerie intégrée',
      icon: MessageCircle,
      content: (
        <div className="space-y-4">
          <div className="bg-gray-100 rounded-lg p-4">
            <div className="space-y-2 mb-3">
              <div className="bg-kiweetoTeal-500 text-white p-2 rounded-lg text-sm max-w-xs">
                Bonjour ! Luna est-elle toujours disponible ? 🐕
              </div>
              <div className="bg-white border p-2 rounded-lg text-sm max-w-xs ml-auto">
                Oui ! Souhaitez-vous organiser une rencontre ?
              </div>
            </div>
            <p className="text-sm text-gray-600">
              Communiquez directement avec les familles d'accueil via notre messagerie sécurisée.
            </p>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Conversations organisées par animal</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Notifications en temps réel</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Historique complet des échanges</span>
            </div>
          </div>
        </div>
      )
    },
    {
      title: 'Suivi et statistiques',
      icon: BarChart3,
      content: (
        <div className="space-y-4">
          <div className="bg-gray-100 rounded-lg p-4">
            <div className="grid grid-cols-3 gap-2 mb-3">
              <div className="bg-kiweetoTeal-100 p-2 rounded text-center">
                <div className="font-bold text-kiweetoTeal-600">12</div>
                <div className="text-xs text-kiweetoTeal-600">Disponibles</div>
              </div>
              <div className="bg-yellow-100 p-2 rounded text-center">
                <div className="font-bold text-yellow-600">8</div>
                <div className="text-xs text-yellow-600">En accueil</div>
              </div>
              <div className="bg-green-100 p-2 rounded text-center">
                <div className="font-bold text-green-600">25</div>
                <div className="text-xs text-green-600">Adoptés</div>
              </div>
            </div>
            <p className="text-sm text-gray-600">
              Suivez vos performances et l'évolution de vos placements avec des tableaux de bord détaillés.
            </p>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Statistiques de placement en temps réel</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Rapports d'activité mensuels</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Suivi des familles d'accueil actives</span>
            </div>
          </div>
        </div>
      )
    }
  ];

  const nextSlide = () => {
    if (currentSlide < featureSlides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const currentSlideData = featureSlides[currentSlide];
  const Icon = currentSlideData.icon;

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-kiweetoTeal-100 rounded-full flex items-center justify-center mx-auto">
          <BookOpen className="h-8 w-8 text-kiweetoTeal-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            Découvrez les fonctionnalités Kiweeto
          </h1>
          <p className="text-gray-600">
            Votre boîte à outils complète pour gérer efficacement vos animaux et familles d'accueil.
          </p>
        </div>
      </div>

      {/* Feature Slides */}
      <Card className="relative">
        {/* Slide Content */}
        <div className="p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-12 h-12 bg-kiweetoTeal-100 rounded-full flex items-center justify-center">
              <Icon className="h-6 w-6 text-kiweetoTeal-600" />
            </div>
            <h2 className="text-xl font-semibold text-gray-900">
              {currentSlideData.title}
            </h2>
          </div>
          
          {currentSlideData.content}
        </div>

        {/* Slide Navigation */}
        <div className="flex items-center justify-between p-4 border-t border-gray-100">
          <Button
            variant="ghost"
            icon={ChevronLeft}
            onClick={prevSlide}
            disabled={currentSlide === 0}
            className="text-gray-500"
          >
            Précédent
          </Button>

          {/* Slide Indicators */}
          <div className="flex space-x-2">
            {featureSlides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentSlide ? 'bg-kiweetoTeal-600' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>

          <Button
            variant="ghost"
            icon={ChevronRight}
            iconPosition="right"
            onClick={nextSlide}
            disabled={currentSlide === featureSlides.length - 1}
            className="text-gray-500"
          >
            Suivant
          </Button>
        </div>
      </Card>

      {/* Quick Tips */}
      <Card className="bg-kiweetoTeal-50 border-kiweetoTeal-200">
        <h3 className="text-lg font-semibold text-kiweetoTeal-800 mb-4">
          💡 Conseils pour optimiser vos placements
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-kiweetoTeal-700">
          <div className="space-y-2">
            <div className="flex items-start space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full mt-2 flex-shrink-0"></span>
              <span>Complétez les fiches animaux avec des photos de qualité</span>
            </div>
            <div className="flex items-start space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full mt-2 flex-shrink-0"></span>
              <span>Répondez rapidement aux messages des familles</span>
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex items-start space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full mt-2 flex-shrink-0"></span>
              <span>Utilisez les filtres pour cibler les bonnes familles</span>
            </div>
            <div className="flex items-start space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full mt-2 flex-shrink-0"></span>
              <span>Maintenez vos informations à jour</span>
            </div>
          </div>
        </div>
      </Card>

      {/* Navigation */}
      <div className="flex justify-between items-center pt-6">
        <Button
          variant="outline"
          icon={ArrowLeft}
          onClick={onPrev}
        >
          Précédent
        </Button>

        <Button
          variant="kiweetoTeal"
          icon={ArrowRight}
          iconPosition="right"
          onClick={onNext}
        >
          Continuer
        </Button>
      </div>
    </div>
  );
}