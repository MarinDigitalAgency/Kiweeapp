import React from 'react';
import { ExternalLink } from 'lucide-react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

export interface PartnerOffer {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  offerUrl: string;
}

interface PartnerOfferCardProps {
  partner: PartnerOffer;
  className?: string;
}

export function PartnerOfferCard({ partner, className = '' }: PartnerOfferCardProps) {
  const handleOfferClick = () => {
    window.open(partner.offerUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <Card className={`overflow-hidden ${className}`}>
      <div className="flex flex-col md:flex-row">
        {/* Partner Image */}
        <div className="w-full md:w-1/3 h-48 md:h-auto">
          <img 
            src={partner.imageUrl} 
            alt={`${partner.name}`} 
            className="w-full h-full object-cover"
          />
        </div>
        
        {/* Content */}
        <div className="flex-1 p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <Badge variant="warning" size="sm" className="flex items-center space-x-1">
                <span>💛</span>
                <span>Partenaire Kiweeto</span>
              </Badge>
            </div>
            
            <h3 className="text-xl font-bold text-gray-900 mb-2">{partner.name}</h3>
            <p className="text-gray-700 mb-4">"{partner.description}"</p>
          </div>
          
          <Button 
            variant="kiweetoGradient"
            icon={ExternalLink}
            onClick={handleOfferClick}
            className="self-start"
          >
            Voir l'offre
          </Button>
        </div>
      </div>
    </Card>
  );
}