import React, { useState, useEffect } from 'react';
import { Save, Home, Heart, Car, Stethoscope } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Card } from '../ui/Card';
import { FamilyProfile } from '../../types';

export function FamilyProfileForm() {
  const { user, updateUserProfile } = useAuth();
  const [profile, setProfile] = useState<Partial<FamilyProfile>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    if (user?.profile?.familyProfile) {
      setProfile(user.profile.familyProfile);
    } else {
      // Set default values if no profile exists
      setProfile({
        housingType: 'house_with_garden',
        hasGarden: true,
        hasDedicatedRoom: false,
        acceptedAnimalTypes: {
          dogs: true,
          cats: true,
          nac: false,
          reptiles: false,
          labAnimals: false,
          farmAnimals: false
        },
        acceptedAges: {
          baby: true,
          junior: true,
          adult: true,
          senior: false
        },
        acceptedSizes: {
          small: true,
          medium: true,
          large: false
        },
        acceptedSexes: {
          male: true,
          female: true
        },
        canProvideMedicalCare: false,
        compatibility: {
          withHumans: 1,
          withChildren: 0,
          withCats: 0,
          withDogs: 0,
          withOtherAnimals: 0
        },
        hasVehicle: true,
        experienceLevel: 'beginner',
        animalExperienceHistory: 'beginner',
        previousFosterCount: 0,
        specializations: []
      });
    }
  }, [user]);

  const handleSave = async () => {
    setIsLoading(true);
    setSuccessMessage('');
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Update the user profile
      updateUserProfile({
        familyProfile: profile as FamilyProfile
      });
      
      setSuccessMessage('Profil mis à jour avec succès !');
      
      // Clear success message after 3 seconds
      setTimeout(() => setSuccessMessage(''), 3000);
    } catch (error) {
      console.error('Error updating profile:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const updateProfile = (updates: Partial<FamilyProfile>) => {
    setProfile(prev => ({ ...prev, ...updates }));
  };

  const updateNestedField = (field: keyof FamilyProfile, subField: string, value: any) => {
    setProfile(prev => ({
      ...prev,
      [field]: {
        ...prev[field],
        [subField]: value
      }
    }));
  };

  return (
    <div className="space-y-6">
      {successMessage && (
        <div className="bg-success-50 border border-success-200 text-success-700 px-4 py-3 rounded-md">
          {successMessage}
        </div>
      )}

      {/* Logement */}
      <Card>
        <div className="flex items-center space-x-2 mb-6">
          <Home className="h-5 w-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Logement</h3>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Type de logement
            </label>
            <select
              value={profile.housingType || ''}
              onChange={(e) => updateProfile({ housingType: e.target.value as any })}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
            >
              <option value="maison">Maison</option>
              <option value="appartement">Appartement</option>
              <option value="studio">Studio</option>
              <option value="chambre">Chambre</option>
              <option value="other">Autre</option>
            </select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={profile.hasGarden || false}
                onChange={(e) => updateProfile({ hasGarden: e.target.checked })}
                className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
              />
              <span className="ml-2 text-sm text-gray-700">Jardin disponible</span>
            </label>

            <label className="flex items-center">
              <input
                type="checkbox"
                checked={profile.hasDedicatedRoom || false}
                onChange={(e) => updateProfile({ hasDedicatedRoom: e.target.checked })}
                className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
              />
              <span className="ml-2 text-sm text-gray-700">Pièce dédiée à l'animal</span>
            </label>
          </div>
        </div>
      </Card>

      {/* Types d'animaux acceptés */}
      <Card>
        <div className="flex items-center space-x-2 mb-6">
          <Heart className="h-5 w-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Animaux acceptés</h3>
        </div>

        <div className="space-y-6">
          <div>
            <h4 className="font-medium text-gray-900 mb-3">Types d'animaux</h4>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {Object.entries(profile.acceptedAnimalTypes || {}).map(([key, value]) => (
                <label key={key} className="flex items-center">
                  <input
                    type="checkbox"
                    checked={value || false}
                    onChange={(e) => updateNestedField('acceptedAnimalTypes', key, e.target.checked)}
                    className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">
                    {key === 'dogs' && 'Chiens'}
                    {key === 'cats' && 'Chats'}
                    {key === 'nac' && 'NAC'}
                    {key === 'reptiles' && 'Reptiles'}
                    {key === 'labAnimals' && 'Animaux de laboratoire'}
                    {key === 'farmAnimals' && 'Animaux de ferme'}
                  </span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-medium text-gray-900 mb-3">Âges acceptés</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {Object.entries(profile.acceptedAges || {}).map(([key, value]) => (
                <label key={key} className="flex items-center">
                  <input
                    type="checkbox"
                    checked={value || false}
                    onChange={(e) => updateNestedField('acceptedAges', key, e.target.checked)}
                    className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">
                    {key === 'baby' && '< 1 an'}
                    {key === 'junior' && '1-2 ans'}
                    {key === 'adult' && '3-7 ans'}
                    {key === 'senior' && '8+ ans'}
                  </span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-medium text-gray-900 mb-3">Tailles acceptées</h4>
            <div className="grid grid-cols-3 gap-3">
              {Object.entries(profile.acceptedSizes || {}).map(([key, value]) => (
                <label key={key} className="flex items-center">
                  <input
                    type="checkbox"
                    checked={value || false}
                    onChange={(e) => updateNestedField('acceptedSizes', key, e.target.checked)}
                    className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">
                    {key === 'small' && 'Petit'}
                    {key === 'medium' && 'Moyen'}
                    {key === 'large' && 'Grand'}
                  </span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-medium text-gray-900 mb-3">Sexes acceptés</h4>
            <div className="grid grid-cols-2 gap-3">
              {Object.entries(profile.acceptedSexes || {}).map(([key, value]) => (
                <label key={key} className="flex items-center">
                  <input
                    type="checkbox"
                    checked={value || false}
                    onChange={(e) => updateNestedField('acceptedSexes', key, e.target.checked)}
                    className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">
                    {key === 'male' && 'Mâle'}
                    {key === 'female' && 'Femelle'}
                  </span>
                </label>
              ))}
            </div>
          </div>
        </div>
      </Card>

      {/* Soins et compatibilité */}
      <Card>
        <div className="flex items-center space-x-2 mb-6">
          <Stethoscope className="h-5 w-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Soins et compatibilité</h3>
        </div>
        <div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nombre d'enfants
            </label>
            <input
              type="number"
              value={profile.compatibility?.withChildren || 0}
              onChange={(e) => updateNestedField('compatibility', 'withChildren', parseInt(e.target.value) || 0)}
              min="0"
              max="10"
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nombre de chats
            </label>
            <input
              type="number"
              value={profile.compatibility?.withCats || 0}
              onChange={(e) => updateNestedField('compatibility', 'withCats', parseInt(e.target.value) || 0)}
              min="0"
              max="10"
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nombre de chiens
            </label>
            <input
              type="number"
              value={profile.compatibility?.withDogs || 0}
              onChange={(e) => updateNestedField('compatibility', 'withDogs', parseInt(e.target.value) || 0)}
              min="0"
              max="10"
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nombre d'autres animaux
            </label>
            <input
              type="number"
              value={profile.compatibility?.withOtherAnimals || 0}
              onChange={(e) => updateNestedField('compatibility', 'withOtherAnimals', parseInt(e.target.value) || 0)}
              min="0"
              max="10"
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
            />
            <p className="text-xs text-gray-500 mt-1">
              NAC, oiseaux, reptiles, etc.
            </p>
          </div>
        </div>
      </Card>

      {/* Mobilité et expérience */}
      <Card>
        <div className="flex items-center space-x-2 mb-6">
          <Car className="h-5 w-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Mobilité et expérience</h3>
        </div>

        <div>
          <label className="flex items-center">
            <input
              type="checkbox"
              checked={profile.hasVehicle || false}
              onChange={(e) => updateProfile({ hasVehicle: e.target.checked })}
              className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
            />
            <span className="ml-2 text-sm text-gray-700">Je suis véhiculé(e)</span>
          </label>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Niveau d'expérience
            </label>
            <select
              value={profile.experienceLevel || ''}
              onChange={(e) => updateProfile({ experienceLevel: e.target.value as any })}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
            >
              <option value="beginner">Débutant</option>
              <option value="intermediate">Intermédiaire</option>
              <option value="experienced">Expérimenté</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Passif avec les animaux
            </label>
            <select
              value={profile.animalExperienceHistory || ''}
              onChange={(e) => updateProfile({ animalExperienceHistory: e.target.value as any })}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
            >
              <option value="beginner">Débutant - Jamais eu d'animaux</option>
              <option value="intermediate">Intermédiaire - Expérience personnelle</option>
              <option value="expert">Expert - Déjà été famille d'accueil</option>
              <option value="professional">Pro - Travaille avec les animaux</option>
            </select>
          </div>

          <div>
            <Input
              label="Nombre d'accueils précédents"
              value={profile.previousFosterCount || 0}
              onChange={(e) => updateProfile({ previousFosterCount: parseInt(e.target.value) || 0 })}
              min="0"
            />
          </div>
        </div>
      </Card>

      {/* Actions */}
      <div className="flex justify-end space-x-4">
        <Button
          onClick={handleSave}
          loading={isLoading}
          icon={Save}
        >
          Enregistrer
        </Button>
      </div>
    </div>
  );
}