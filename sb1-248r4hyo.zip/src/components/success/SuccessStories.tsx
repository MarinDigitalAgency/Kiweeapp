import React, { useMemo } from 'react';
import { Heart, ArrowRight, MapPin, Calendar } from 'lucide-react';
import { Link } from 'react-router-dom';
import { mockAnimals } from '../../data/mockData';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

export function SuccessStories() {
  // Get animals that have found families (in_care or adopted)
  const successAnimals = useMemo(() => {
    return mockAnimals
      .filter(animal => animal.status === 'in_care' || animal.status === 'adopted')
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, 6); // Show only the 6 most recent success stories
  }, []);

  const getAgeText = (age: number) => {
    return age > 1 ? `${age} ans` : `${age} an`;
  };

  const getSizeText = (size: string) => {
    const sizeMap = { petit: 'Petit', moyen: 'Moyen', grand: 'Grand' };
    return sizeMap[size as keyof typeof sizeMap] || size;
  };

  const getTypeText = (type: string) => {
    const typeMap = { chien: 'Chien', chat: 'Chat', autre: 'Autre' };
    return typeMap[type as keyof typeof typeMap] || type;
  };

  const getStatusBadge = (status: string) => {
    if (status === 'adopted') {
      return (
        <Badge variant="primary" className="flex items-center space-x-1">
          <Heart className="h-3 w-3 fill-current" />
          <span>Adopté</span>
        </Badge>
      );
    } else {
      return (
        <Badge variant="warning" className="flex items-center space-x-1">
          <span className="w-2 h-2 bg-warning-600 rounded-full"></span>
          <span>En famille d'accueil</span>
        </Badge>
      );
    }
  };

  if (successAnimals.length === 0) {
    return null;
  }

  return (
    <section className="py-20 bg-gradient-to-br from-secondary-50 to-primary-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="bg-secondary-100 p-3 rounded-full">
              <Heart className="h-8 w-8 text-secondary-600 fill-current" />
            </div>
            <h2 className="text-4xl font-bold text-gray-900">
              Ils ont trouvé une famille !
            </h2>
          </div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Découvrez les animaux qui ont été accueillis ou adoptés grâce à Kiweeto. Car on peut tous faire la différence dans la vie d’un animal ! ✨
          </p>
        </div>

        {/* Success Stories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {successAnimals.map((animal) => (
            <Card key={animal.id} padding="none" hover className="overflow-hidden group">
              {/* Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={animal.photos[0]}
                  alt={animal.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                
                {/* Overlay gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
                
                {/* Status badge */}
                <div className="absolute top-4 left-4">
                  {getStatusBadge(animal.status)}
                </div>

                {/* Type badge */}
                <div className="absolute top-4 right-4">
                  <Badge variant="primary" size="sm">
                    {getTypeText(animal.type)}
                  </Badge>
                </div>

                {/* Success icon */}
                <div className="absolute bottom-4 right-4">
                  <div className="bg-white/90 backdrop-blur-sm rounded-full p-2">
                    <Heart className="h-5 w-5 text-secondary-600 fill-current" />
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-6 space-y-4">
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-1">{animal.name}</h3>
                  <p className="text-gray-600">
                    {animal.breed} • {getAgeText(animal.age)} • {getSizeText(animal.size)}
                  </p>
                </div>

                <p className="text-gray-700 text-sm line-clamp-2">
                  {animal.description}
                </p>

                {/* Location and association */}
                <div className="space-y-2 text-sm text-gray-500">
                  <div className="flex items-center space-x-1">
                    <MapPin className="h-4 w-4" />
                    <span>{animal.location}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Par {animal.associationName}</span>
                    <div className="flex items-center space-x-1">
                      <Calendar className="h-3 w-3" />
                      <span>{animal.createdAt.getFullYear()}</span>
                    </div>
                  </div>
                </div>

                {/* Success message */}
                <div className="pt-3 border-t border-gray-100">
                  <p className="text-sm text-secondary-700 font-medium flex items-center space-x-1">
                    <Heart className="h-4 w-4 fill-current" />
                    <span>
                      {animal.status === 'adopted' 
                        ? 'A trouvé sa famille pour la vie !' 
                        : 'Profite d\'une famille d\'accueil aimante !'}
                    </span>
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <div className="bg-white rounded-2xl shadow-xl p-8 max-w-2xl mx-auto">
            <div className="mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-primary-500 to-secondary-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="h-8 w-8 text-white fill-current" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">
                Moi aussi, je veux aider un animal ! 🐾
              </h3>
              <p className="text-gray-600">
                Rejoignez notre communauté de familles d'accueil et offrez une seconde chance à un animal dans le besoin.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                as={Link}
                to="/register?type=family"
                variant="kiweetoGradient"
                size="lg" 
                icon={ArrowRight} 
                iconPosition="right" 
                className="px-8"
              >
                Devenir famille d'accueil
              </Button>
              <Button
                as={Link}
                to="/search"
                variant="outline"
                size="lg"
                className="px-8"
              >
                Découvrir les animaux
              </Button>
            </div>
          </div>
        </div>

        {/* Statistics */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <div className="bg-white/60 backdrop-blur-sm rounded-xl p-6">
            <div className="text-3xl font-bold text-secondary-600 mb-2">
              {successAnimals.filter(a => a.status === 'adopted').length}
            </div>
            <div className="text-gray-700">Adoptions réussies</div>
          </div>
          <div className="bg-white/60 backdrop-blur-sm rounded-xl p-6">
            <div className="text-3xl font-bold text-warning-600 mb-2">
              {successAnimals.filter(a => a.status === 'in_care').length}
            </div>
            <div className="text-gray-700">En famille d'accueil</div>
          </div>
          <div className="bg-white/60 backdrop-blur-sm rounded-xl p-6">
            <div className="text-3xl font-bold text-primary-600 mb-2">
              {successAnimals.length}
            </div>
            <div className="text-gray-700">Vies transformées</div>
          </div>
        </div>
      </div>
    </section>
  );
}