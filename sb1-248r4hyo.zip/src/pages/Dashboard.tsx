import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { AssociationDashboard } from '../components/dashboard/AssociationDashboard';
import { FamilyDashboard } from '../components/dashboard/FamilyDashboard';

export function Dashboard() {
  const { user } = useAuth();

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {user.type === 'association' ? (
        <AssociationDashboard />
      ) : (
        <FamilyDashboard />
      )}
    </div>
  );
}