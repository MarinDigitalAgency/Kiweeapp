import React, { useState, useMemo, useCallback, useEffect } from 'react';
import Map, { 
  Marker, 
  Popup, 
  NavigationControl, 
  FullscreenControl, 
  GeolocateControl,
  Source,
  Layer
} from 'react-map-gl';
import { useNavigate } from 'react-router-dom';
import { Animal } from '../../types';
import { AnimalCard } from '../animals/AnimalCard';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Eye, MessageCircle, MapPin, Calendar, Users, Heart } from 'lucide-react';
import Supercluster from 'supercluster';
import { generateCircleCoordinates } from '../../utils/geolocation';

// Vous devrez remplacer cette clé par votre propre clé Mapbox
const MAPBOX_TOKEN = 'pk.eyJ1IjoibWFyaW5kaWdpdGFsYWdlbmN5IiwiYSI6ImNtY2YzZXFyNDA1NnMyanF0dHUzbXMyMjYifQ.27FVg4Bt-3SiZ7wtggEsew'; // Remplacez par votre clé

interface MapViewProps {
  animals: Animal[];
  onAnimalSelect?: (animal: Animal) => void;
  selectedAnimal?: Animal | null;
  onSearchInArea?: (bounds: { north: number; south: number; east: number; west: number }) => void;
  centerLatitude?: number;
  centerLongitude?: number;
  searchRadius?: number;
}

interface ClusterFeature {
  type: 'Feature';
  properties: {
    cluster: boolean;
    cluster_id?: number;
    point_count?: number;
    animal?: Animal;
  };
  geometry: {
    type: 'Point';
    coordinates: [number, number];
  };
}

export function MapView({ 
  animals, 
  onAnimalSelect, 
  selectedAnimal, 
  onSearchInArea,
  centerLatitude,
  centerLongitude,
  searchRadius
}: MapViewProps) {
  const navigate = useNavigate();
  console.log('🗺️ MapView rendering with:', {
    animalsCount: animals.length,
    animals: animals.map(a => ({ name: a.name, lat: a.latitude, lon: a.longitude })),
    centerLatitude,
    centerLongitude,
    searchRadius,
    mapboxToken: MAPBOX_TOKEN ? 'Present' : 'Missing'
  });

  const [viewState, setViewState] = useState({
    longitude: centerLongitude || 4.8357, // Lyon par défaut
    latitude: centerLatitude || 45.7640,
    zoom: searchRadius ? Math.max(8, 14 - Math.log2(searchRadius / 5)) : 10
  });
  const [showPopup, setShowPopup] = useState<Animal | null>(null);
  const [hoveredAnimal, setHoveredAnimal] = useState<Animal | null>(null);

  console.log('🎯 Current view state:', viewState);

  // Mettre à jour la vue quand les coordonnées de recherche changent
  useEffect(() => {
    if (centerLatitude && centerLongitude) {
      console.log('📍 Updating map center to:', { centerLatitude, centerLongitude });
      setViewState(prev => ({
        ...prev,
        longitude: centerLongitude,
        latitude: centerLatitude,
        zoom: searchRadius ? Math.max(8, 14 - Math.log2(searchRadius / 5)) : prev.zoom
      }));
    }
  }, [centerLatitude, centerLongitude, searchRadius]);

  // Configuration du clustering
  const supercluster = useMemo(() => {
    console.log('🔧 Creating supercluster with animals:', animals.length);
    
    const cluster = new Supercluster({
      radius: 75,
      maxZoom: 20,
      minZoom: 0,
      minPoints: 2
    });

    const points: ClusterFeature[] = animals.map(animal => {
      console.log(`📍 Adding animal ${animal.name} to cluster at [${animal.longitude}, ${animal.latitude}]`);
      return {
        type: 'Feature',
        properties: {
          cluster: false,
          animal
        },
        geometry: {
          type: 'Point',
          coordinates: [animal.longitude, animal.latitude]
        }
      };
    });

    console.log('📊 Total points for clustering:', points.length);
    cluster.load(points);
    return cluster;
  }, [animals]);

  // Obtenir les clusters pour le niveau de zoom actuel
  const clusters = useMemo(() => {
    const bounds = [
      viewState.longitude - 1,
      viewState.latitude - 1,
      viewState.longitude + 1,
      viewState.latitude + 1
    ] as [number, number, number, number];

    const clustersResult = supercluster.getClusters(bounds, Math.floor(viewState.zoom));
    console.log('🎯 Clusters for current view:', {
      bounds,
      zoom: Math.floor(viewState.zoom),
      clustersCount: clustersResult.length,
      clusters: clustersResult.map(c => ({
        isCluster: c.properties.cluster,
        pointCount: c.properties.point_count,
        animalName: c.properties.animal?.name,
        coordinates: c.geometry.coordinates
      }))
    });

    return clustersResult;
  }, [supercluster, viewState]);

  // Générer les coordonnées du cercle de recherche
  const searchCircleData = useMemo(() => {
    if (!centerLatitude || !centerLongitude || !searchRadius) {
      console.log('⭕ No search circle - missing params:', { centerLatitude, centerLongitude, searchRadius });
      return null;
    }

    console.log('⭕ Generating search circle:', { centerLatitude, centerLongitude, searchRadius });
    const coordinates = generateCircleCoordinates(centerLatitude, centerLongitude, searchRadius);
    
    return {
      type: 'Feature',
      geometry: {
        type: 'Polygon',
        coordinates: [coordinates]
      }
    };
  }, [centerLatitude, centerLongitude, searchRadius]);

  const handleMarkerClick = useCallback((animal: Animal) => {
    console.log('🖱️ Marker clicked for animal:', animal.name);
    setShowPopup(animal);
    onAnimalSelect?.(animal);
  }, [onAnimalSelect]);

  const handleClusterClick = useCallback((clusterId: number) => {
    console.log('🖱️ Cluster clicked:', clusterId);
    const expansionZoom = supercluster.getClusterExpansionZoom(clusterId);
    const clusterCenter = supercluster.getClusterChildren(clusterId)[0];
    
    if (clusterCenter && clusterCenter.geometry.coordinates) {
      console.log('🎯 Expanding cluster to zoom:', expansionZoom, 'at:', clusterCenter.geometry.coordinates);
      setViewState(prev => ({
        ...prev,
        longitude: clusterCenter.geometry.coordinates[0],
        latitude: clusterCenter.geometry.coordinates[1],
        zoom: Math.min(expansionZoom, 20)
      }));
    }
  }, [supercluster]);

  const handleSearchInArea = useCallback(() => {
    // Calculer les limites de la zone visible
    const bounds = {
      north: viewState.latitude + 0.1,
      south: viewState.latitude - 0.1,
      east: viewState.longitude + 0.1,
      west: viewState.longitude - 0.1
    };
    console.log('🔍 Search in area:', bounds);
    onSearchInArea?.(bounds);
  }, [viewState, onSearchInArea]);

  const getAnimalIcon = (animal: Animal) => {
    const typeEmoji = {
      chien: '🐕',
      chat: '🐱',
      autre: '🐾'
    };
    return typeEmoji[animal.type] || '🐾';
  };

  const getAgeText = (age: number) => {
    return age > 1 ? `${age} ans` : `${age} an`;
  };
  
  const getSexText = (sex: string) => {
    const sexMap = {
      male: 'Mâle',
      female: 'Femelle'
    };
    return sexMap[sex as keyof typeof sexMap] || sex;
  };

  const getSizeText = (size: string) => {
    const sizeMap = {
      petit: 'Petit',
      moyen: 'Moyen',
      grand: 'Grand'
    };
    return sizeMap[size as keyof typeof sizeMap] || size;
  };

  const getTypeText = (type: string) => {
    const typeMap = {
      chien: 'Chien',
      chat: 'Chat',
      autre: 'Autre'
    };
    return typeMap[type as keyof typeof typeMap] || type;
  };

  // Check for Mapbox token
  if (!MAPBOX_TOKEN) {
    console.error('❌ Mapbox token is missing!');
    return (
      <div className="w-full h-full flex items-center justify-center bg-gray-100">
        <div className="text-center p-8">
          <h3 className="text-lg font-medium text-gray-900 mb-2">Carte non disponible</h3>
          <p className="text-gray-600">Le token Mapbox n'est pas configuré.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full">
      <Map
        {...viewState}
        onMove={evt => {
          console.log('🗺️ Map moved to:', evt.viewState);
          setViewState(evt.viewState);
        }}
        mapboxAccessToken={MAPBOX_TOKEN}
        style={{ width: '100%', height: '100%' }}
        mapStyle="mapbox://styles/mapbox/light-v11"
        attributionControl={false}
        onLoad={() => console.log('✅ Map loaded successfully')}
        onError={(error) => console.error('❌ Map error:', error)}
      >
        {/* Contrôles de navigation */}
        <NavigationControl position="top-right" />
        <FullscreenControl position="top-right" />
        <GeolocateControl
          position="top-right"
          trackUserLocation={true}
          showUserHeading={true}
        />

        {/* Cercle de recherche */}
        {searchCircleData && (
          <Source id="search-radius" type="geojson" data={searchCircleData}>
            <Layer
              id="search-radius-fill"
              type="fill"
              paint={{
                'fill-color': '#3B82F6',
                'fill-opacity': 0.1
              }}
            />
            <Layer
              id="search-radius-line"
              type="line"
              paint={{
                'line-color': '#3B82F6',
                'line-width': 2,
                'line-opacity': 0.8
              }}
            />
          </Source>
        )}

        {/* Marqueur du centre de recherche */}
        {centerLatitude && centerLongitude && (
          <Marker
            longitude={centerLongitude}
            latitude={centerLatitude}
          >
            <div className="w-4 h-4 bg-primary-600 rounded-full border-2 border-white shadow-lg"></div>
          </Marker>
        )}

        {/* Marqueurs et clusters */}
        {clusters.map((cluster, index) => {
          const [longitude, latitude] = cluster.geometry.coordinates;
          const { cluster: isCluster, point_count: pointCount, animal } = cluster.properties;

          console.log(`🎯 Rendering cluster/marker ${index}:`, {
            isCluster,
            pointCount,
            animalName: animal?.name,
            coordinates: [longitude, latitude]
          });

          if (isCluster) {
            return (
              <Marker
                key={`cluster-${cluster.properties.cluster_id}`}
                longitude={longitude}
                latitude={latitude}
                onClick={() => handleClusterClick(cluster.properties.cluster_id!)}
              >
                <div className="bg-primary-600 text-white rounded-full w-12 h-12 flex items-center justify-center font-bold text-sm cursor-pointer hover:bg-primary-700 transition-colors shadow-lg">
                  {pointCount}
                </div>
              </Marker>
            );
          }

          if (!animal) {
            console.warn('⚠️ No animal data for non-cluster marker');
            return null;
          }

          return (
            <Marker
              key={animal.id}
              longitude={longitude}
              latitude={latitude}
              onClick={() => handleMarkerClick(animal)}
            >
              <div 
                className="relative cursor-pointer group"
                onMouseEnter={() => setHoveredAnimal(animal)}
                onMouseLeave={() => setHoveredAnimal(null)}
              >
                <div className="w-12 h-12 rounded-full overflow-hidden border-3 border-white shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-110">
                  <img
                    src={animal.photos[0]}
                    alt={animal.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="absolute -top-1 -right-1 w-6 h-6 bg-primary-600 rounded-full flex items-center justify-center text-white text-xs">
                  {getAnimalIcon(animal)}
                </div>
                
                {/* Miniature de fiche animal au survol */}
                {hoveredAnimal?.id === animal.id && (
                  <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-3 w-80 bg-white rounded-xl shadow-2xl border border-gray-200 overflow-hidden z-50 opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none">
                    {/* Image de l'animal */}
                    <div className="relative h-32 overflow-hidden">
                      <img
                        src={animal.photos[0]}
                        alt={animal.name}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute top-2 left-2">
                        <Badge variant="primary" size="sm">
                          {getTypeText(animal.type)}
                        </Badge>
                      </div>
                      <div className="absolute top-2 right-2">
                        <div className="bg-white/90 backdrop-blur-sm rounded-full p-1">
                          <Heart className="h-4 w-4 text-gray-600" />
                        </div>
                      </div>
                    </div>

                    {/* Contenu de la fiche */}
                    <div className="p-4 space-y-3">
                      <div>
                        <h3 className="font-bold text-lg text-gray-900">{animal.name}</h3>
                        <p className="text-sm text-gray-600">
                          {animal.breed} • {getSexText(animal.sex)} • {getAgeText(animal.age)} • {getSizeText(animal.size)}
                        </p>
                      </div>

                      <p className="text-sm text-gray-700 line-clamp-2">
                        {animal.description}
                      </p>

                      {/* Badges santé */}
                      <div className="flex flex-wrap gap-1">
                        {animal.health.vaccinated && (
                          <Badge variant="success" size="sm">Vacciné</Badge>
                        )}
                        {animal.health.sterilized && (
                          <Badge variant="success" size="sm">Stérilisé</Badge>
                        )}
                      </div>

                      {/* Compatibilité */}
                      <div className="flex items-center space-x-3 text-xs text-gray-500">
                        {animal.compatibility.withDogs && (
                          <div className="flex items-center space-x-1">
                            <Users className="h-3 w-3" />
                            <span>Chiens</span>
                          </div>
                        )}
                        {animal.compatibility.withCats && (
                          <div className="flex items-center space-x-1">
                            <Users className="h-3 w-3" />
                            <span>Chats</span>
                          </div>
                        )}
                        {animal.compatibility.withChildren && (
                          <div className="flex items-center space-x-1">
                            <Users className="h-3 w-3" />
                            <span>Enfants</span>
                          </div>
                        )}
                      </div>

                      {/* Localisation et distance */}
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <div className="flex items-center space-x-1">
                          <MapPin className="h-3 w-3" />
                          <span>{animal.location}</span>
                        </div>
                        {(animal as any).calculatedDistance && (
                          <span className="text-primary-600 font-medium">
                            📍 {(animal as any).calculatedDistance} km
                          </span>
                        )}
                      </div>

                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <div className="flex items-center space-x-1">
                          <Calendar className="h-3 w-3" />
                          <span>Dispo. {animal.availableFrom.toLocaleDateString('fr-FR')}</span>
                        </div>
                      </div>

                      <div className="text-xs text-gray-500 border-t border-gray-100 pt-2">
                        Par {animal.associationName}
                      </div>

                      {/* Actions */}
                      <div className="flex space-x-2 pt-2">
                        <button 
                          className="flex-1 bg-primary-600 text-white text-xs py-2 px-3 rounded-lg hover:bg-primary-700 transition-colors flex items-center justify-center space-x-1"
                          onClick={() => navigate(`/animal/${animal.id}`)}
                        >
                          <Eye className="h-3 w-3" />
                          <span>Voir plus</span>
                        </button>
                        <button 
                          className="flex-1 bg-gray-100 text-gray-700 text-xs py-2 px-3 rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center space-x-1"
                          onClick={() => navigate(`/messages?animalId=${animal.id}&associationId=${animal.associationId}`)}
                        >
                          <MessageCircle className="h-3 w-3" />
                          <span>Contact</span>
                        </button>
                      </div>
                    </div>

                    {/* Flèche pointant vers le marqueur */}
                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-8 border-r-8 border-t-8 border-l-transparent border-r-transparent border-t-white"></div>
                  </div>
                )}
              </div>
            </Marker>
          );
        })}

        {/* Popup pour l'animal sélectionné */}
        {showPopup && (
          <Popup
            longitude={showPopup.longitude}
            latitude={showPopup.latitude}
            onClose={() => setShowPopup(null)}
            closeButton={true}
            closeOnClick={false}
            maxWidth="320px"
          >
            <div className="p-2">
              <div className="flex items-center space-x-3 mb-3">
                <img
                  src={showPopup.photos[0]}
                  alt={showPopup.name}
                  className="w-16 h-16 rounded-lg object-cover"
                />
                <div>
                  <h3 className="font-semibold text-gray-900">{showPopup.name}</h3>
                  <p className="text-sm text-gray-600">
                    {showPopup.breed} • {showPopup.age} {showPopup.age > 1 ? 'ans' : 'an'}
                  </p>
                  <p className="text-xs text-gray-500">{showPopup.location}</p>
                  {(showPopup as any).calculatedDistance && (
                    <p className="text-xs text-primary-600">
                      {showPopup.breed} • {getSexText(showPopup.sex)} • {showPopup.age} {showPopup.age > 1 ? 'ans' : 'an'}
                    </p>
                  )}
                </div>
              </div>
              
              <p className="text-sm text-gray-700 mb-3 line-clamp-2">
                {showPopup.description}
              </p>
              
              <div className="flex space-x-2">
                <Button
                  size="sm"
                  icon={Eye}
                  onClick={() => navigate(`/animal/${showPopup.id}`)}
                  className="flex-1"
                >
                  Voir plus
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  icon={MessageCircle}
                  onClick={() => navigate(`/messages?animalId=${showPopup.id}&associationId=${showPopup.associationId}`)}
                >
                  Contact
                </Button>
              </div>
            </div>
          </Popup>
        )}
      </Map>

      {/* Bouton "Rechercher dans cette zone" */}
      <div className="absolute top-4 left-4 z-10">
        <Button
          onClick={handleSearchInArea}
          variant="outline"
          className="bg-white shadow-lg hover:shadow-xl"
        >
          Rechercher dans cette zone
        </Button>
      </div>

      {/* Indicateur du nombre d'animaux et de la zone de recherche */}
      <div className="absolute bottom-4 left-4 z-10">
        <div className="bg-white px-4 py-2 rounded-lg shadow-lg">
          <span className="text-sm font-medium text-gray-700">
            {animals.length} animal{animals.length > 1 ? 'x' : ''} trouvé{animals.length > 1 ? 's' : ''}
          </span>
          {searchRadius && centerLatitude && centerLongitude && (
            <div className="text-xs text-gray-500 mt-1">
              Dans un rayon de {searchRadius} km
            </div>
          )}
        </div>
      </div>
    </div>
  );
}