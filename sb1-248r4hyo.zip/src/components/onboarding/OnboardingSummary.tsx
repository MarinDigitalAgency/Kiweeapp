import React from 'react';
import { CheckCircle, Edit, ArrowLeft, Sparkles } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { FamilyProfile } from '../../types';

interface OnboardingSummaryProps {
  data: Partial<FamilyProfile>;
  onComplete: () => void;
  onPrev: () => void;
  onGoToStep: (step: number) => void;
}

export function OnboardingSummary({
  data,
  onComplete,
  onPrev,
  onGoToStep
}: OnboardingSummaryProps) {
  const getAnimalTypesText = () => {
    const types = [];
    if (data.acceptedAnimalTypes?.dogs) types.push('Chiens');
    if (data.acceptedAnimalTypes?.cats) types.push('Chats');
    if (data.acceptedAnimalTypes?.nac) types.push('NAC');
    if (data.acceptedAnimalTypes?.reptiles) types.push('Reptiles');
    if (data.acceptedAnimalTypes?.labAnimals) types.push('Animaux de labo');
    if (data.acceptedAnimalTypes?.farmAnimals) types.push('Animaux de ferme');
    return types.length > 0 ? types.join(', ') : 'Non spécifié';
  };

  const getAgesText = () => {
    const ages = [];
    if (data.acceptedAges?.baby) ages.push('Bébés');
    if (data.acceptedAges?.junior) ages.push('Jeunes');
    if (data.acceptedAges?.adult) ages.push('Adultes');
    if (data.acceptedAges?.senior) ages.push('Seniors');
    return ages.length > 0 ? ages.join(', ') : 'Non spécifié';
  };

  const getSizesText = () => {
    const sizes = [];
    if (data.acceptedSizes?.small) sizes.push('Petit');
    if (data.acceptedSizes?.medium) sizes.push('Moyen');
    if (data.acceptedSizes?.large) sizes.push('Grand');
    return sizes.length > 0 ? sizes.join(', ') : 'Non spécifié';
  };

  const getHousingTypeText = () => {
    const typeMap = {
      house_with_garden: 'Maison avec jardin',
      house_without_garden: 'Maison sans jardin',
      apartment_with_outdoor: 'Appartement avec extérieur',
      apartment_without_outdoor: 'Appartement sans extérieur',
      other: 'Autre'
    };
    return data.housingType ? typeMap[data.housingType] : 'Non spécifié';
  };

  const getExperienceLevelText = () => {
    const levelMap = {
      beginner: 'Débutant',
      intermediate: 'Intermédiaire',
      experienced: 'Expérimenté'
    };
    return data.experienceLevel ? levelMap[data.experienceLevel] : 'Non spécifié';
  };

  const getAnimalExperienceHistoryText = () => {
    const levelMap = {
      beginner: 'Débutant - Jamais eu d\'animaux',
      intermediate: 'Intermédiaire - Expérience personnelle',
      expert: 'Expert - Famille d\'accueil expérimentée',
      professional: 'Pro - Travaille avec les animaux'
    };
    return data.animalExperienceHistory ? levelMap[data.animalExperienceHistory] : 'Non spécifié';
  };

  const getCompatibilityText = () => {
    const items = [];
    
    if (data.compatibility?.withHumans) {
      items.push(`${data.compatibility.withHumans} adulte${data.compatibility.withHumans > 1 ? 's' : ''}`);
    }
    
    if (data.compatibility?.withChildren) {
      items.push(`${data.compatibility.withChildren} enfant${data.compatibility.withChildren > 1 ? 's' : ''}`);
    }
    
    if (data.compatibility?.withCats) {
      items.push(`${data.compatibility.withCats} chat${data.compatibility.withCats > 1 ? 's' : ''}`);
    }
    
    if (data.compatibility?.withDogs) {
      items.push(`${data.compatibility.withDogs} chien${data.compatibility.withDogs > 1 ? 's' : ''}`);
    }
    
    if (data.compatibility?.withOtherAnimals) {
      items.push(`${data.compatibility.withOtherAnimals} autre${data.compatibility.withOtherAnimals > 1 ? 's' : ''} animal/aux`);
    }
    
    return items.length > 0 ? items.join(', ') : 'Aucun';
  };

  const getDurationText = () => {
    const durationMap = {
      short: 'Court terme (< 1 mois)',
      medium: 'Moyen terme (1-6 mois)',
      long: 'Long terme (6+ mois)',
      permanent: 'Adoption'
    };
    return data.fosteringAvailability?.duration ? durationMap[data.fosteringAvailability.duration] : 'Non spécifié';
  };

  const getFrequencyText = () => {
    const frequencyMap = {
      occasional: 'Ponctuel',
      regular: 'Régulier',
      emergency: 'Urgences'
    };
    return data.fosteringAvailability?.frequency ? frequencyMap[data.fosteringAvailability.frequency] : 'Non spécifié';
  };

  const summaryData = [
    {
      step: 2,
      title: 'Préférences animaux',
      icon: '🐾',
      items: [
        { label: 'Types d\'animaux', value: getAnimalTypesText() },
        { label: 'Âges acceptés', value: getAgesText() },
        { label: 'Tailles acceptées', value: getSizesText() }
      ]
    },
    {
      step: 3,
      title: 'Logement',
      icon: '🏠',
      items: [
        { label: 'Type de logement', value: getHousingTypeText() },
        { label: 'Jardin', value: data.hasGarden ? 'Oui' : 'Non' },
        { label: 'Pièce dédiée', value: data.hasDedicatedRoom ? 'Oui' : 'Non' },
        { label: 'Composition du foyer', value: getCompatibilityText() }
      ]
    },
    {
      step: 4,
      title: 'Expérience',
      icon: '🌟',
      items: [
        { label: 'Passif avec les animaux', value: getAnimalExperienceHistoryText() },
        { label: 'Niveau d\'expérience', value: getExperienceLevelText() },
        { label: 'Accueils précédents', value: `${data.previousFosterCount || 0}` },
        { label: 'Soins médicaux', value: data.canProvideMedicalCare ? 'Oui' : 'Non' },
        { label: 'Véhiculé', value: data.hasVehicle ? 'Oui' : 'Non' }
      ]
    },
    {
      step: 5,
      title: 'Disponibilités',
      icon: '📅',
      items: [
        { label: 'Durée préférée', value: getDurationText() },
        { label: 'Fréquence', value: getFrequencyText() },
        { label: 'Capacité max', value: `${data.fosteringAvailability?.maxAnimalsAtOnce || 1} animal(x)` }
      ]
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-gradient-to-br from-kiweetoTeal-500 to-kiweetoLightBlue-500 rounded-full flex items-center justify-center mx-auto">
          <Sparkles className="h-8 w-8 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            Récapitulatif de votre profil
          </h1>
          <p className="text-gray-600">
            Vérifiez vos informations avant de finaliser votre inscription.
          </p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {summaryData.map((section) => (
          <Card key={section.step} className="relative">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <span className="text-2xl">{section.icon}</span>
                <h3 className="text-lg font-semibold text-gray-900">{section.title}</h3>
              </div>
              <Button
                variant="ghost"
                size="sm"
                icon={Edit}
                onClick={() => onGoToStep(section.step)}
                className="text-gray-500 hover:text-gray-700"
              >
                Modifier
              </Button>
            </div>
            
            <div className="space-y-3">
              {section.items.map((item, index) => (
                <div key={index} className="flex justify-between items-start">
                  <span className="text-sm text-gray-600 font-medium">{item.label} :</span>
                  <span className="text-sm text-gray-900 text-right max-w-xs">{item.value}</span>
                </div>
              ))}
            </div>
          </Card>
        ))}
      </div>

      {/* Specializations */}
      {data.specializations && data.specializations.length > 0 && (
        <Card>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">🎯 Spécialisations</h3>
            <Button
              variant="ghost"
              size="sm"
              icon={Edit}
              onClick={() => onGoToStep(4)}
              className="text-gray-500 hover:text-gray-700"
            >
              Modifier
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {data.specializations.map((spec, index) => (
              <Badge key={index} variant="secondary">
                {spec}
              </Badge>
            ))}
          </div>
        </Card>
      )}

      {/* Charter Status */}
      <Card className="bg-kiweetoTeal-50 border-kiweetoTeal-200">
        <div className="flex items-center space-x-3">
          <CheckCircle className="h-6 w-6 text-kiweetoTeal-600" />
          <div>
            <h3 className="font-semibold text-kiweetoTeal-800">Charte acceptée</h3>
            <p className="text-sm text-kiweetoTeal-700">
              Vous avez accepté la charte de la famille d'accueil Kiweeto
            </p>
          </div>
        </div>
      </Card>

      {/* Next Steps */}
      <Card className="bg-gradient-to-r from-kiweetoTeal-50 to-kiweetoLightBlue-50 border-kiweetoTeal-200">
        <div className="text-center space-y-4">
          <h3 className="text-xl font-semibold text-kiweetoTeal-800">
            🎉 Félicitations ! Vous êtes prêt(e) !
          </h3>
          <p className="text-kiweetoTeal-700">
            Votre profil est maintenant configuré. Vous allez pouvoir commencer à rechercher 
            des animaux à accueillir et entrer en contact avec les associations.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-kiweetoTeal-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <span className="text-xl">🔍</span>
              </div>
              <h4 className="font-medium text-kiweetoTeal-800">Rechercher</h4>
              <p className="text-sm text-kiweetoTeal-600">Trouvez des animaux près de chez vous</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-kiweetoTeal-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <span className="text-xl">💬</span>
              </div>
              <h4 className="font-medium text-kiweetoTeal-800">Échanger</h4>
              <p className="text-sm text-kiweetoTeal-600">Contactez les associations</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-kiweetoTeal-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <span className="text-xl">❤️</span>
              </div>
              <h4 className="font-medium text-kiweetoTeal-800">Accueillir</h4>
              <p className="text-sm text-kiweetoTeal-600">Offrez un foyer temporaire</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Navigation */}
      <div className="flex justify-between items-center pt-6">
        <Button
          variant="outline"
          icon={ArrowLeft}
          onClick={onPrev}
        >
          Précédent
        </Button>

        <Button
          variant="kiweetoTeal"
          icon={CheckCircle}
          iconPosition="right"
          onClick={onComplete}
          size="lg"
          className="px-8"
        >
          Terminer et accéder au tableau de bord
        </Button>
      </div>
    </div>
  );
}