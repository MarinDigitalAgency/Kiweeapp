import React from 'react';
import { Home, ArrowRight, ArrowLeft, SkipForward } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { FamilyProfile } from '../../types';

interface OnboardingHousingProps {
  data: Partial<FamilyProfile>;
  onUpdate: (updates: Partial<FamilyProfile>) => void;
  onNext: () => void;
  onPrev: () => void;
  onSkip: () => void;
}

export function OnboardingHousing({
  data,
  onUpdate,
  onNext,
  onPrev,
  onSkip
}: OnboardingHousingProps) {
  const updateCompatibility = (key: keyof FamilyProfile['compatibility'], value: number) => {
    onUpdate({
      compatibility: {
        ...data.compatibility,
        [key]: value
      }
    });
  };

  const housingOptions = [
    {
      value: 'maison',
      label: 'Maison',
      description: 'Maison individuelle ou mitoyenne',
      emoji: '🏡'
    },
    {
      value: 'appartement',
      label: 'Appartement',
      description: 'Logement dans un immeuble',
      emoji: '🏢'
    },
    {
      value: 'studio',
      label: 'Studio',
      description: 'Pièce unique avec cuisine et salle de bain',
      emoji: '🏬'
    },
    {
      value: 'chambre',
      label: 'Chambre',
      description: 'Chambre dans une colocation ou chez l\'habitant',
      emoji: '🛏️'
    },
    {
      value: 'other',
      label: 'Autre',
      description: 'Situation particulière',
      emoji: '🏘️'
    }
  ];

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-kiweetoTeal-100 rounded-full flex items-center justify-center mx-auto">
          <Home className="h-8 w-8 text-kiweetoTeal-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            Parlez-nous de votre logement
          </h1>
          <p className="text-gray-600">
            Ces informations nous aident à vous proposer des animaux adaptés à votre environnement.
          </p>
        </div>
      </div>

      {/* Housing Type */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Type de logement</h3>
        <div className="space-y-3">
          {housingOptions.map((option) => (
            <label
              key={option.value}
              className={`flex items-center p-4 border-2 rounded-lg cursor-pointer transition-all ${
                data.housingType === option.value
                  ? 'border-kiweetoTeal-500 bg-kiweetoTeal-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <input
                type="radio"
                name="housingType"
                value={option.value}
                checked={data.housingType === option.value}
                onChange={(e) => onUpdate({ housingType: e.target.value as FamilyProfile['housingType'] })}
                className="sr-only"
              />
              <div className="flex items-center space-x-4 flex-1">
                <span className="text-2xl">{option.emoji}</span>
                <div>
                  <div className="font-medium text-gray-900">{option.label}</div>
                  <div className="text-sm text-gray-500">{option.description}</div>
                </div>
              </div>
            </label>
          ))}
        </div>
      </Card>

      {/* Housing Features */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Caractéristiques de votre logement</h3>
        <div className="space-y-4">
          <label className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
            <div className="flex items-center space-x-3">
              <span className="text-xl">🌳</span>
              <div>
                <div className="font-medium text-gray-900">Jardin disponible</div>
                <div className="text-sm text-gray-500">Espace extérieur clôturé</div>
              </div>
            </div>
            <input
              type="checkbox"
              checked={data.hasGarden || false}
              onChange={(e) => onUpdate({ hasGarden: e.target.checked })}
              className="rounded border-gray-300 text-kiweetoTeal-600 focus:ring-kiweetoTeal-500"
            />
          </label>

          <label className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
            <div className="flex items-center space-x-3">
              <span className="text-xl">🚪</span>
              <div>
                <div className="font-medium text-gray-900">Pièce dédiée à l'animal</div>
                <div className="text-sm text-gray-500">Espace tranquille pour l'adaptation</div>
              </div>
            </div>
            <input
              type="checkbox"
              checked={data.hasDedicatedRoom || false}
              onChange={(e) => onUpdate({ hasDedicatedRoom: e.target.checked })}
              className="rounded border-gray-300 text-kiweetoTeal-600 focus:ring-kiweetoTeal-500"
            />
          </label>
        </div>
      </Card>

      {/* Compatibility */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Composition du foyer</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nombre d'adultes dans le foyer
            </label>
            <input
              type="number"
              value={data.compatibility?.withHumans || 1}
              onChange={(e) => updateCompatibility('withHumans', parseInt(e.target.value) || 1)}
              min="1"
              max="10"
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nombre d'enfants dans le foyer
            </label>
            <input
              type="number"
              value={data.compatibility?.withChildren || 0}
              onChange={(e) => updateCompatibility('withChildren', parseInt(e.target.value) || 0)}
              min="0"
              max="10"
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nombre de chats dans le foyer
            </label>
            <input
              type="number"
              value={data.compatibility?.withCats || 0}
              onChange={(e) => updateCompatibility('withCats', parseInt(e.target.value) || 0)}
              min="0"
              max="10"
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nombre de chiens dans le foyer
            </label>
            <input
              type="number"
              value={data.compatibility?.withDogs || 0}
              onChange={(e) => updateCompatibility('withDogs', parseInt(e.target.value) || 0)}
              min="0"
              max="10"
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nombre d'autres animaux dans le foyer
            </label>
            <input
              type="number"
              value={data.compatibility?.withOtherAnimals || 0}
              onChange={(e) => updateCompatibility('withOtherAnimals', parseInt(e.target.value) || 0)}
              min="0"
              max="10"
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
            />
            <p className="text-xs text-gray-500 mt-1">
              NAC, oiseaux, reptiles, etc.
            </p>
          </div>
        </div>
      </Card>

      {/* Encouragement */}
      {data.housingType && (
        <Card className="bg-kiweetoTeal-50 border-kiweetoTeal-200">
          <div className="text-center">
            <p className="text-kiweetoTeal-800 font-medium">
              🏠 Votre logement semble parfait pour accueillir des animaux !
            </p>
          </div>
        </Card>
      )}

      {/* Navigation */}
      <div className="flex justify-between items-center pt-6">
        <Button
          variant="outline"
          icon={ArrowLeft}
          onClick={onPrev}
        >
          Précédent
        </Button>

        <Button
          variant="ghost"
          icon={SkipForward}
          onClick={onSkip}
          className="text-gray-500"
        >
          Passer cette étape
        </Button>

        <Button
          variant="kiweetoTeal"
          icon={ArrowRight}
          iconPosition="right"
          onClick={onNext}
        >
          Suivant
        </Button>
      </div>
    </div>
  );
}