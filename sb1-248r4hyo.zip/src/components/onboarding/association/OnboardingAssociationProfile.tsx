import React from 'react';
import { Building2, ArrowRight, ArrowLeft, SkipForward, MapPin, Globe, Phone, Mail } from 'lucide-react';
import { Button } from '../../ui/Button';
import { Card } from '../../ui/Card';
import { Input } from '../../ui/Input';
import { AssociationProfile } from '../../../types';

interface OnboardingAssociationProfileProps {
  data: Partial<AssociationProfile>;
  onUpdate: (updates: Partial<AssociationProfile>) => void;
  onNext: () => void;
  onPrev: () => void;
  onSkip: () => void;
}

export function OnboardingAssociationProfile({
  data,
  onUpdate,
  onNext,
  onPrev,
  onSkip
}: OnboardingAssociationProfileProps) {
  const updateAnimalTypes = (type: string, checked: boolean) => {
    const currentTypes = data.animalTypes || [];
    if (checked) {
      onUpdate({ animalTypes: [...currentTypes, type] });
    } else {
      onUpdate({ animalTypes: currentTypes.filter(t => t !== type) });
    }
  };

  const updateServices = (service: keyof AssociationProfile['services'], checked: boolean) => {
    onUpdate({
      services: {
        ...data.services,
        [service]: checked
      }
    });
  };

  const animalTypeOptions = [
    { value: 'chien', label: 'Chiens', emoji: '🐕' },
    { value: 'chat', label: 'Chats', emoji: '🐱' },
    { value: 'nac', label: 'NAC (lapins, furets...)', emoji: '🐰' },
    { value: 'reptile', label: 'Reptiles', emoji: '🦎' },
    { value: 'animaux de laboratoire', label: 'Animaux de laboratoire', emoji: '🐭' },
    { value: 'animaux de ferme', label: 'Animaux de ferme', emoji: '🐷' }
  ];

  const serviceOptions = [
    { key: 'fostering', label: 'Familles d\'accueil', description: 'Placement temporaire d\'animaux' },
    { key: 'adoption', label: 'Adoption', description: 'Placement définitif d\'animaux' },
    { key: 'veterinaryCare', label: 'Soins vétérinaires', description: 'Prise en charge médicale' },
    { key: 'behavioralSupport', label: 'Soutien comportemental', description: 'Rééducation et socialisation' },
    { key: 'emergency', label: 'Urgences', description: 'Interventions d\'urgence' }
  ];

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-kiweetoTeal-100 rounded-full flex items-center justify-center mx-auto">
          <Building2 className="h-8 w-8 text-kiweetoTeal-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            Profil de votre association
          </h1>
          <p className="text-gray-600">
            Présentez votre association et vos activités pour attirer les bonnes familles d'accueil.
          </p>
        </div>
      </div>

      {/* Contact Information */}
      <Card>
        <div className="flex items-center space-x-2 mb-4">
          <Phone className="h-5 w-5 text-kiweetoTeal-600" />
          <h3 className="text-lg font-semibold text-gray-900">Informations de contact</h3>
        </div>
        <div className="space-y-4">
          <Input
            label="Adresse complète *"
            value={data.fullAddress || ''}
            onChange={(e) => onUpdate({ fullAddress: e.target.value })}
            placeholder="123 Rue de la République, 69000 Lyon"
            icon={MapPin}
            required
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Email de contact"
              type="email"
              value={data.contactEmail || ''}
              onChange={(e) => onUpdate({ contactEmail: e.target.value })}
              placeholder="contact@association.fr"
              icon={Mail}
            />
            
            <Input
              label="Téléphone de contact"
              type="tel"
              value={data.contactPhone || ''}
              onChange={(e) => onUpdate({ contactPhone: e.target.value })}
              placeholder="01 23 45 67 89"
              icon={Phone}
            />
          </div>
          
          <Input
            label="Site web"
            value={data.website || ''}
            onChange={(e) => onUpdate({ website: e.target.value })}
            placeholder="https://www.association.fr"
            icon={Globe}
          />
        </div>
      </Card>

      {/* Description */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Description de l'association</h3>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Présentez votre association *
          </label>
          <textarea
            value={data.description || ''}
            onChange={(e) => onUpdate({ description: e.target.value })}
            rows={4}
            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-kiweetoTeal-500 focus:ring-kiweetoTeal-500"
            placeholder="Décrivez votre mission, vos valeurs, votre historique et vos actions..."
            required
          />
          <p className="text-xs text-gray-500 mt-1">
            Cette description sera visible par les familles d'accueil potentielles
          </p>
        </div>
      </Card>

      {/* Animal Types */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Types d'animaux pris en charge</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {animalTypeOptions.map((option) => (
            <label
              key={option.value}
              className={`flex items-center p-3 border-2 rounded-lg cursor-pointer transition-all ${
                data.animalTypes?.includes(option.value)
                  ? 'border-kiweetoTeal-500 bg-kiweetoTeal-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <input
                type="checkbox"
                checked={data.animalTypes?.includes(option.value) || false}
                onChange={(e) => updateAnimalTypes(option.value, e.target.checked)}
                className="sr-only"
              />
              <div className="flex items-center space-x-3">
                <span className="text-xl">{option.emoji}</span>
                <span className="font-medium text-gray-900">{option.label}</span>
              </div>
            </label>
          ))}
        </div>
      </Card>

      {/* Services */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Services proposés</h3>
        <div className="space-y-3">
          {serviceOptions.map((service) => (
            <label
              key={service.key}
              className="flex items-center justify-between p-4 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50"
            >
              <div>
                <div className="font-medium text-gray-900">{service.label}</div>
                <div className="text-sm text-gray-500">{service.description}</div>
              </div>
              <input
                type="checkbox"
                checked={data.services?.[service.key as keyof AssociationProfile['services']] || false}
                onChange={(e) => updateServices(service.key as keyof AssociationProfile['services'], e.target.checked)}
                className="rounded border-gray-300 text-kiweetoTeal-600 focus:ring-kiweetoTeal-500"
              />
            </label>
          ))}
        </div>
      </Card>

      {/* Current Animals */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Animaux suivis</h3>
        <div className="space-y-4">
          <Input
            label="Combien d'animaux sont actuellement suivis par votre association (en famille d'accueil ou en refuge) ?"
            type="number"
            value={data.animalsCurrentlyInCare || 0}
            onChange={(e) => onUpdate({ animalsCurrentlyInCare: parseInt(e.target.value) || 0 })}
            min="0"
          />
          <p className="text-sm text-gray-500">
            Cette information nous permet de mieux comprendre l'activité de votre association. Elle ne sera pas affichée publiquement.
          </p>
          
          <Input
            label="Animaux aidés par an (moyenne)"
            type="number"
            value={data.averageAnimalsPerYear || 0}
            onChange={(e) => onUpdate({ averageAnimalsPerYear: parseInt(e.target.value) || 0 })}
            min="0"
          />
        </div>
      </Card>

      {/* Coverage Area */}
      <Card>
        <div className="flex items-center space-x-2 mb-4">
          <MapPin className="h-5 w-5 text-kiweetoTeal-600" />
          <h3 className="text-lg font-semibold text-gray-900">Zone d'intervention</h3>
        </div>
        <div className="space-y-4">
          <Input
            label="Rayon d'action (km)"
            type="number"
            value={data.coverageRadius || 50}
            onChange={(e) => onUpdate({ coverageRadius: parseInt(e.target.value) || 50 })}
            min="1"
            max="500"
          />
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Villes ou départements couverts
            </label>
            <textarea
              value={data.coverageCities?.join('\n') || ''}
              onChange={(e) => onUpdate({ 
                coverageCities: e.target.value.split('\n').filter(city => city.trim()) 
              })}
              placeholder="Lyon&#10;Villeurbanne&#10;Rhône (69)"
              rows={3}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-kiweetoTeal-500 focus:ring-kiweetoTeal-500"
            />
            <p className="text-xs text-gray-500 mt-1">
              Une ville ou département par ligne
            </p>
          </div>
        </div>
      </Card>

      {/* Navigation */}
      <div className="flex justify-between items-center pt-6">
        <Button
          variant="outline"
          icon={ArrowLeft}
          onClick={onPrev}
        >
          Précédent
        </Button>

        <Button
          variant="ghost"
          icon={SkipForward}
          onClick={onSkip}
          className="text-gray-500"
        >
          Passer cette étape
        </Button>

        <Button
          variant="kiweetoTeal"
          icon={ArrowRight}
          iconPosition="right"
          onClick={onNext}
        >
          Suivant
        </Button>
      </div>
    </div>
  );
}