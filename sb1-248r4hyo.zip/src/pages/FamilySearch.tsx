import React, { useState, useMemo } from 'react';
import { Grid, List, Users, MessageCircle } from 'lucide-react';
import { User, FamilySearchFilters as FamilySearchFiltersType, ViewMode } from '../types';
import { getFamiliesForSearch } from '../data/mockData';
import { FamilySearchFilters } from '../components/search/FamilySearchFilters';
import { FamilyCard } from '../components/families/FamilyCard';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { calculateDistance, getCurrentPosition, geocodeAddress } from '../utils/geolocation';

export function FamilySearch() {
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [filters, setFilters] = useState<FamilySearchFiltersType>({});
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [isGeolocating, setIsGeolocating] = useState(false);

  // Fonction pour calculer un score de qualité pour une famille
  const getScoreForFamily = (family: User) => {
    let score = 0;
    const profile = family.profile?.familyProfile;
    const badges = family.profile?.badges;
    
    if (family.verified) score += 10;
    if (badges?.isTopFosterFamily) score += 15;
    if (badges?.isExperiencedFA) score += 10;
    if (profile?.experienceLevel === 'experienced') score += 8;
    if (profile?.experienceLevel === 'intermediate') score += 5;
    if (profile?.canProvideMedicalCare) score += 5;
    if (profile?.hasVehicle) score += 3;
    if (profile?.previousFosterCount && profile.previousFosterCount > 0) score += profile.previousFosterCount;
    
    return score;
  };

  // Fonction pour obtenir les coordonnées simulées d'une famille
  const getFamilyCoordinates = (location: string) => {
    const cityCoords: Record<string, { lat: number; lon: number }> = {
      'lyon': { lat: 45.7640, lon: 4.8357 },
      'paris': { lat: 48.8566, lon: 2.3522 },
      'marseille': { lat: 43.2965, lon: 5.3698 },
      'toulouse': { lat: 43.6047, lon: 1.4442 },
      'nice': { lat: 43.7102, lon: 7.2620 }
    };
    
    const normalizedLocation = location.toLowerCase();
    for (const [city, coords] of Object.entries(cityCoords)) {
      if (normalizedLocation.includes(city)) {
        return coords;
      }
    }
    
    return null;
  };

  // Filtrer les familles selon les critères
  const filteredFamilies = useMemo(() => {
    console.log('🔍 Starting family filtering...');
    const families = getFamiliesForSearch();
    console.log('📊 Total families available:', families.length);
    console.log('🎛️ Current filters:', filters);
    
    const filtered = families.filter(family => {
      const profile = family.profile?.familyProfile;
      const badges = family.profile?.badges;
      
      if (!profile) {
        console.log(`❌ Family ${family.name} filtered out: no profile`);
        return false;
      }
      
      // Filtre par type de logement
      if (filters.housingType && profile.housingType !== filters.housingType) {
        console.log(`❌ Family ${family.name} filtered out by housing type: ${profile.housingType} !== ${filters.housingType}`);
        return false;
      }
      
      // Filtre par jardin
      if (filters.hasGarden && !profile.hasGarden) {
        console.log(`❌ Family ${family.name} filtered out: no garden`);
        return false;
      }
      
      // Filtre par pièce dédiée
      if (filters.hasDedicatedRoom && !profile.hasDedicatedRoom) {
        console.log(`❌ Family ${family.name} filtered out: no dedicated room`);
        return false;
      }
      
      // Filtre par types d'animaux acceptés
      if (filters.acceptedAnimalTypes) {
        const hasRequiredTypes = Object.entries(filters.acceptedAnimalTypes).every(([type, required]) => {
          if (!required) return true;
          return profile.acceptedAnimalTypes[type as keyof typeof profile.acceptedAnimalTypes];
        });
        
        if (!hasRequiredTypes) {
          console.log(`❌ Family ${family.name} filtered out by animal types`);
          return false;
        }
      }
      
      // Filtre par niveau d'expérience
      if (filters.experienceLevel && profile.experienceLevel !== filters.experienceLevel) {
        console.log(`❌ Family ${family.name} filtered out by experience level: ${profile.experienceLevel} !== ${filters.experienceLevel}`);
        return false;
      }
      
      // Filtre par nombre d'accueils précédents
      if (filters.minPreviousFosterCount && profile.previousFosterCount < filters.minPreviousFosterCount) {
        console.log(`❌ Family ${family.name} filtered out by foster count: ${profile.previousFosterCount} < ${filters.minPreviousFosterCount}`);
        return false;
      }
      
      // Filtre par capacités
      if (filters.canProvideMedicalCare && !profile.canProvideMedicalCare) {
        console.log(`❌ Family ${family.name} filtered out: cannot provide medical care`);
        return false;
      }
      
      if (filters.hasVehicle && !profile.hasVehicle) {
        console.log(`❌ Family ${family.name} filtered out: no vehicle`);
        return false;
      }
      
      // Filtre par statut de vérification
      if (filters.isVerified && !family.verified) {
        console.log(`❌ Family ${family.name} filtered out: not verified`);
        return false;
      }
      
      if (filters.isTopFosterFamily && !badges?.isTopFosterFamily) {
        console.log(`❌ Family ${family.name} filtered out: not top foster family`);
        return false;
      }
      
      // Filtre par compatibilité
      if (filters.compatibility) {
        const hasRequiredCompatibility = Object.entries(filters.compatibility).every(([compat, required]) => {
          if (required === undefined) return true;
          return profile.compatibility[compat as keyof typeof profile.compatibility] > 0;
        });
        
        if (!hasRequiredCompatibility) {
          console.log(`❌ Family ${family.name} filtered out by compatibility`);
          return false;
        }
      }
      
      // Filtre par localisation (recherche simple dans le nom de la ville)
      if (filters.location && !family.location?.toLowerCase().includes(filters.location.toLowerCase())) {
        // Si on a des coordonnées de centre et un rayon, on ne filtre pas par nom de ville
        if (!(filters.centerLatitude && filters.centerLongitude && filters.radius)) {
          console.log(`❌ Family ${family.name} filtered out by location: ${family.location} doesn't contain ${filters.location}`);
          return false;
        }
      }
      
      // Filtre par rayon géographique (simulation - en production, vous auriez les coordonnées des familles)
      if (filters.centerLatitude && filters.centerLongitude && filters.radius) {
        // Pour la démo, on utilise des coordonnées simulées basées sur la ville
        const familyCoords = getFamilyCoordinates(family.location || '');
        if (familyCoords) {
          const distance = calculateDistance(
            filters.centerLatitude,
            filters.centerLongitude,
            familyCoords.lat,
            familyCoords.lon
          );
          
          console.log(`📍 Distance for ${family.name}: ${distance} km (limit: ${filters.radius} km)`);
          
          if (distance > filters.radius) {
            console.log(`❌ Family ${family.name} filtered out by distance: ${distance} > ${filters.radius}`);
            return false;
          }
          
          // Ajouter la distance calculée à la famille pour l'affichage
          (family as any).calculatedDistance = distance;
        }
      }
      
      console.log(`✅ Family ${family.name} passed all filters`);
      return true;
    }).sort((a, b) => {
      // Trier par distance si on a une recherche géographique
      if (filters.centerLatitude && filters.centerLongitude) {
        const distanceA = (a as any).calculatedDistance || 0;
        const distanceB = (b as any).calculatedDistance || 0;
        return distanceA - distanceB;
      }
      
      // Trier par statut de vérification et expérience
      const scoreA = getScoreForFamily(a);
      const scoreB = getScoreForFamily(b);
      return scoreB - scoreA;
    });

    console.log('🎯 Filtered families count:', filtered.length);
    console.log('📋 Filtered families:', filtered.map(f => ({ 
      name: f.name, 
      location: f.location,
      verified: f.verified,
      experience: f.profile?.familyProfile?.experienceLevel
    })));
    
    return filtered;
  }, [filters]);

  const handleContact = (familyId: string) => {
    console.log('Contact family:', familyId);
    // Ici vous pourriez naviguer vers la page de messagerie ou ouvrir un modal de contact
  };

  const handleGeolocation = async () => {
    setIsGeolocating(true);
    try {
      const position = await getCurrentPosition();
      const { latitude, longitude } = position.coords;
      
      console.log('📍 User position obtained:', { latitude, longitude });
      
      setFilters(prev => ({
        ...prev,
        centerLatitude: latitude,
        centerLongitude: longitude,
        location: 'Ma position actuelle',
        radius: prev.radius || 20 // Rayon par défaut de 20km
      }));
    } catch (error) {
      console.error('Erreur de géolocalisation:', error);
      alert('Impossible d\'obtenir votre position. Veuillez vérifier les autorisations de géolocalisation.');
    } finally {
      setIsGeolocating(false);
    }
  };

  const handleFiltersChange = async (newFilters: FamilySearchFiltersType) => {
    console.log('🔄 Filters changing from:', filters, 'to:', newFilters);
    
    // Si la localisation a changé et qu'on n'a pas de coordonnées, essayer de géocoder
    if (newFilters.location !== filters.location && newFilters.location && !newFilters.centerLatitude) {
      try {
        console.log('🌍 Geocoding address:', newFilters.location);
        const geocoded = await geocodeAddress(newFilters.location);
        if (geocoded) {
          console.log('✅ Geocoding successful:', geocoded);
          newFilters.centerLatitude = geocoded.lat;
          newFilters.centerLongitude = geocoded.lon;
          newFilters.location = geocoded.displayName;
        }
      } catch (error) {
        console.error('Erreur de géocodage:', error);
      }
    }
    
    setFilters(newFilters);
  };

  const clearFilters = () => {
    console.log('🧹 Clearing all filters');
    setFilters({});
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Rechercher des familles d'accueil
          </h1>
          <p className="text-gray-600">
            Trouvez les familles parfaites pour vos animaux
          </p>
        </div>

        {/* Filtres */}
        <div className="mb-6">
          <FamilySearchFilters
            filters={filters}
            onFiltersChange={handleFiltersChange}
            onClearFilters={clearFilters}
            onGeolocation={handleGeolocation}
            showAdvanced={showAdvancedFilters}
            onToggleAdvanced={() => setShowAdvancedFilters(!showAdvancedFilters)}
            isGeolocating={isGeolocating}
          />
        </div>

        {/* Barre d'outils */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-600">
              {filteredFamilies.length} famille{filteredFamilies.length > 1 ? 's' : ''} trouvée{filteredFamilies.length > 1 ? 's' : ''}
            </span>
            {filters.centerLatitude && filters.centerLongitude && filters.radius && (
              <span className="text-sm text-primary-600">
                dans un rayon de {filters.radius} km
              </span>
            )}
            {filters.experienceLevel && (
              <span className="text-sm text-secondary-600">
                • niveau {filters.experienceLevel}
              </span>
            )}
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="flex bg-white rounded-lg border border-gray-200 p-1">
              <Button
                variant={viewMode === 'grid' ? 'primary' : 'ghost'}
                size="sm"
                icon={Grid}
                onClick={() => setViewMode('grid')}
                className="rounded-md"
              >
                <span className="sr-only">Grille</span>
              </Button>
              <Button
                variant={viewMode === 'list' ? 'primary' : 'ghost'}
                size="sm"
                icon={List}
                onClick={() => setViewMode('list')}
                className="rounded-md"
              >
                <span className="sr-only">Liste</span>
              </Button>
            </div>
          </div>
        </div>

        {/* Contenu principal */}
        <div className={
          viewMode === 'grid' 
            ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
            : 'space-y-4'
        }>
          {filteredFamilies.length > 0 ? (
            filteredFamilies.map((family) => (
              <div key={family.id} className={viewMode === 'list' ? 'max-w-4xl' : ''}>
                <FamilyCard
                  family={family}
                  onContact={handleContact}
                />
                {/* Affichage de la distance si disponible */}
                {(family as any).calculatedDistance && (
                  <div className="mt-2 text-xs text-gray-500 text-center">
                    📍 À {(family as any).calculatedDistance} km
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="col-span-full">
              <Card className="text-center py-12">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  Aucune famille trouvée
                </h3>
                <p className="text-gray-600 mb-4">
                  Essayez de modifier vos critères de recherche pour voir plus de résultats.
                </p>
                <Button onClick={clearFilters} variant="outline">
                  Effacer les filtres
                </Button>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}