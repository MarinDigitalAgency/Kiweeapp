import React from 'react';
import { Shield, ArrowRight, ArrowLeft, CheckCircle } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { FamilyProfile } from '../../types';

interface OnboardingCharterConsentProps {
  data: Partial<FamilyProfile>;
  onUpdate: (updates: Partial<FamilyProfile>) => void;
  onNext: () => void;
  onPrev: () => void;
}

export function OnboardingCharterConsent({
  data,
  onUpdate,
  onNext,
  onPrev
}: OnboardingCharterConsentProps) {
  const charterPoints = [
    {
      title: 'Bien-être animal',
      description: 'Je m\'engage à assurer le bien-être physique et psychologique de l\'animal accueilli.',
      icon: '❤️'
    },
    {
      title: 'Soins vétérinaires',
      description: 'Je m\'engage à suivre les recommandations vétérinaires et à informer l\'association de tout problème de santé.',
      icon: '🏥'
    },
    {
      title: 'Communication',
      description: 'Je m\'engage à maintenir une communication régulière avec l\'association et à donner des nouvelles de l\'animal.',
      icon: '💬'
    },
    {
      title: 'Respect des consignes',
      description: 'Je m\'engage à respecter les consignes spécifiques données par l\'association pour chaque animal.',
      icon: '📋'
    },
    {
      title: 'Socialisation',
      description: 'Je m\'engage à favoriser la socialisation de l\'animal pour faciliter son adoption future.',
      icon: '🤝'
    },
    {
      title: 'Retour à l\'association',
      description: 'Je m\'engage à rendre l\'animal à l\'association selon les modalités convenues.',
      icon: '🔄'
    },
    {
      title: 'Confidentialité',
      description: 'Je m\'engage à respecter la confidentialité des informations partagées par l\'association.',
      icon: '🔒'
    },
    {
      title: 'Bienveillance',
      description: 'Je m\'engage à traiter l\'animal avec respect, patience et bienveillance en toutes circonstances.',
      icon: '🌟'
    }
  ];

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-kiweetoTeal-100 rounded-full flex items-center justify-center mx-auto">
          <Shield className="h-8 w-8 text-kiweetoTeal-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            Charte de la famille d'accueil
          </h1>
          <p className="text-gray-600">
            Prenez connaissance de nos engagements mutuels pour le bien-être des animaux.
          </p>
        </div>
      </div>

      {/* Charter Content */}
      <Card className="bg-gradient-to-br from-kiweetoTeal-50 to-kiweetoLightBlue-50 border-kiweetoTeal-200">
        <div className="text-center mb-6">
          <h2 className="text-xl font-semibold text-kiweetoTeal-800 mb-2">
            Nos engagements mutuels
          </h2>
          <p className="text-kiweetoTeal-700">
            En tant que famille d'accueil Kiweeto, nous nous engageons ensemble pour le bien-être des animaux.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {charterPoints.map((point, index) => (
            <div
              key={index}
              className="flex items-start space-x-3 p-4 bg-white rounded-lg border border-kiweetoTeal-100"
            >
              <span className="text-2xl flex-shrink-0">{point.icon}</span>
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">{point.title}</h3>
                <p className="text-sm text-gray-600">{point.description}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Association Commitments */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          🤝 Nos engagements envers vous
        </h3>
        <div className="space-y-3 text-sm text-gray-700">
          <div className="flex items-start space-x-2">
            <CheckCircle className="h-4 w-4 text-kiweetoTeal-600 mt-0.5 flex-shrink-0" />
            <span>Support et accompagnement tout au long de l'accueil</span>
          </div>
          <div className="flex items-start space-x-2">
            <CheckCircle className="h-4 w-4 text-kiweetoTeal-600 mt-0.5 flex-shrink-0" />
            <span>Prise en charge des frais vétérinaires selon les modalités convenues</span>
          </div>
          <div className="flex items-start space-x-2">
            <CheckCircle className="h-4 w-4 text-kiweetoTeal-600 mt-0.5 flex-shrink-0" />
            <span>Fourniture des accessoires de base (selon disponibilité)</span>
          </div>
          <div className="flex items-start space-x-2">
            <CheckCircle className="h-4 w-4 text-kiweetoTeal-600 mt-0.5 flex-shrink-0" />
            <span>Disponibilité pour répondre à vos questions et préoccupations</span>
          </div>
          <div className="flex items-start space-x-2">
            <CheckCircle className="h-4 w-4 text-kiweetoTeal-600 mt-0.5 flex-shrink-0" />
            <span>Respect de vos disponibilités et contraintes personnelles</span>
          </div>
        </div>
      </Card>

      {/* Consent */}
      <Card className="border-2 border-kiweetoTeal-200">
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-gray-900">
            Acceptation de la charte
          </h3>
          
          <label className="flex items-start space-x-3 p-4 bg-kiweetoTeal-50 rounded-lg cursor-pointer">
            <input
              type="checkbox"
              checked={data.agreesToCharter || false}
              onChange={(e) => onUpdate({ agreesToCharter: e.target.checked })}
              className="rounded border-gray-300 text-kiweetoTeal-600 focus:ring-kiweetoTeal-500 mt-1"
              required
            />
            <div className="flex-1">
              <div className="font-medium text-gray-900 mb-1">
                J'accepte la charte de la famille d'accueil Kiweeto
              </div>
              <div className="text-sm text-gray-600">
                En cochant cette case, je m'engage à respecter tous les points de cette charte 
                et à agir dans l'intérêt supérieur des animaux qui me seront confiés.
              </div>
            </div>
          </label>

          {!data.agreesToCharter && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
              <p className="text-sm text-yellow-800">
                ⚠️ L'acceptation de la charte est obligatoire pour devenir famille d'accueil.
              </p>
            </div>
          )}
        </div>
      </Card>

      {/* Success Message */}
      {data.agreesToCharter && (
        <Card className="bg-kiweetoTeal-50 border-kiweetoTeal-200">
          <div className="text-center">
            <p className="text-kiweetoTeal-800 font-medium">
              🎉 Merci ! Vous êtes maintenant officiellement membre de la communauté Kiweeto !
            </p>
          </div>
        </Card>
      )}

      {/* Navigation */}
      <div className="flex justify-between items-center pt-6">
        <Button
          variant="outline"
          icon={ArrowLeft}
          onClick={onPrev}
        >
          Précédent
        </Button>

        <Button
          variant="kiweetoTeal"
          icon={ArrowRight}
          iconPosition="right"
          onClick={onNext}
          disabled={!data.agreesToCharter}
        >
          Suivant
        </Button>
      </div>
    </div>
  );
}