import React from 'react';

export type UserType = 'family' | 'association';

export interface User {
  id: string;
  email: string;
  name: string;
  type: UserType;
  avatar?: string;
  location?: string;
  phone?: string;
  verified: boolean;
  createdAt: Date;
  profile?: UserProfile;
}

export interface UserProfile {
  // Common fields
  dateOfBirth?: Date;
  address?: string;
  city?: string;
  postalCode?: string;
  country?: string;
  description?: string;
  
  // Family-specific fields
  familyProfile?: FamilyProfile;
  
  // Association-specific fields
  associationProfile?: AssociationProfile;
  
  // Trust badges
  badges: UserBadges;
  
  // Documents
  documents: UserDocuments;
  
  // Profile completion
  completionPercentage: number;
  isProfileComplete: boolean;
  onboardingCompleted?: boolean;
}

export interface FamilyProfile {
  // Housing information
  housingType: 'maison' | 'appartement' | 'studio' | 'chambre' | 'other';
  hasGarden: boolean;
  hasDedicatedRoom: boolean;
  
  // Fostering availability
  fosteringAvailability?: {
    startDate?: Date;
    endDate?: Date;
    duration: 'short' | 'medium' | 'long' | 'permanent'; // < 1 mois, 1-6 mois, 6+ mois, adoption
    frequency: 'occasional' | 'regular' | 'emergency'; // ponctuel, régulier, urgence
    maxAnimalsAtOnce: number;
    preferredSeasons?: string[]; // été, hiver, etc.
  };
  
  // Accepted animal types
  acceptedAnimalTypes: {
    dogs: boolean;
    cats: boolean;
    nac: boolean; // Nouveaux Animaux de Compagnie
    reptiles: boolean;
    labAnimals: boolean;
    farmAnimals: boolean;
  };
  
  // Accepted animal characteristics
  acceptedAges: {
    baby: boolean; // < 1 an
    junior: boolean; // 1-2 ans
    adult: boolean; // 3-7 ans
    senior: boolean; // 8+ ans
  };
  
  acceptedSizes: {
    small: boolean;
    medium: boolean;
    large: boolean;
  };
  
  acceptedSexes: {
    male: boolean;
    female: boolean;
  };
  
  // Care capabilities
  canProvideMedicalCare: boolean;
  
  // Compatibility
  compatibility: {
    withHumans: number;
    withChildren: number;
    withCats: number;
    withDogs: number;
    withOtherAnimals: number;
  };
  
  // Mobility
  hasVehicle: boolean;
  
  // Experience
  experienceLevel: 'beginner' | 'intermediate' | 'experienced';
  animalExperienceHistory?: 'beginner' | 'intermediate' | 'expert' | 'professional';
  previousFosterCount: number;
  specializations: string[]; // e.g., ['senior dogs', 'medical care', 'behavioral issues']
  
  // Charter consent
  agreesToCharter?: boolean;
  charterAcceptedAt?: Date;
}

export interface AssociationProfile {
  // Legal information
  rna: string; // Répertoire National des Associations
  siret?: string;
  presidentName: string;
  foundedYear: number;
  
  // Additional administrative details
  fullAddress?: string;
  description?: string;
  website?: string;
  contactEmail?: string;
  contactPhone?: string;
  
  // Certifications
  acacedCertifications: string[]; // ACACED certificate numbers
  otherCertifications: string[];
  
  // Activity
  animalTypes: string[]; // Types of animals the association works with
  averageAnimalsPerYear: number;
  totalAnimalsHelped: number;
  animalsCurrentlyInCare: number;
  
  // Services
  services: {
    fostering: boolean;
    adoption: boolean;
    veterinaryCare: boolean;
    behavioralSupport: boolean;
    emergency: boolean;
  };
  
  // Coverage area
  coverageRadius: number; // in kilometers
  coverageCities: string[];
  
  // Charter consent
  agreesToCharter?: boolean;
  charterAcceptedAt?: Date;
}

export interface UserBadges {
  // Family badges
  isProfileVerified: boolean;
  isTopFosterFamily: boolean;
  isExperiencedFA: boolean;
  
  // Association badges
  isCertifiedAssociation: boolean;
  isRnaVerified: boolean;
  
  // Common badges
  isEmailVerified: boolean;
  isPhoneVerified: boolean;
  hasCompletedProfile: boolean;
}

export interface UserDocuments {
  // Family documents
  identityDocument?: DocumentInfo; // CNI/Passport
  rcInsurance?: DocumentInfo; // Responsabilité Civile
  housingProof?: DocumentInfo;
  
  // Association documents
  statutes?: DocumentInfo;
  rnaDocument?: DocumentInfo;
  insuranceDocument?: DocumentInfo;
  acacedCertificates?: DocumentInfo[];
  
  // Common documents
  profilePhoto?: DocumentInfo;
}

export interface DocumentInfo {
  id: string;
  name: string;
  url: string;
  type: string;
  size: number;
  uploadedAt: Date;
  verified: boolean;
  verifiedAt?: Date;
  verifiedBy?: string;
}

export interface Animal {
  id: string;
  name: string;
  type: 'chien' | 'chat' | 'autre';
  breed?: string;
  age: number;
  sex: 'male' | 'female';
  size: 'petit' | 'moyen' | 'grand';
  photos: string[];
  description: string;
  health: {
    vaccinated: boolean;
    sterilized: boolean;
    treatments?: string[];
  };
  characterTraits?: {
    sociability: number;
    obedience: number;
    cuddliness: number;
    independence: number;
  };
  compatibility: {
    withDogs: boolean;
    withCats: boolean;
    withChildren: boolean;
  };
  associationId: string;
  associationName: string;
  associationRating?: number; // Rating of the association (1-5 stars)
  location: string;
  latitude: number;
  longitude: number;
  availableFrom: Date;
  availableUntil?: Date;
  status: 'available' | 'in_care' | 'adopted' | 'archived';
  createdAt: Date;
  // Sensitive information - only visible to authorized users
  sensitiveInfo?: {
    icad?: string; // Identification number
    veterinaryClinic?: string;
    veterinaryContact?: string;
    medicalHistory?: string;
    behavioralNotes?: string;
  };
}

export interface UserInteraction {
  id: string;
  userId: string;
  animalId: string;
  type: 'like' | 'pass';
  timestamp: Date;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  content: string;
  timestamp: Date;
  read: boolean;
}

export interface Conversation {
  id: string;
  animalId: string;
  animalName: string;
  participants: {
    familyId: string;
    familyName: string;
    associationId: string;
    associationName: string;
  };
  lastMessage?: Message;
  unreadCount: number;
  createdAt: Date;
}

export interface SearchFilters {
  type?: 'chien' | 'chat' | 'autre';
  breed?: string;
  age?: { min?: number; max?: number };
  sex?: 'male' | 'female';
  size?: 'petit' | 'moyen' | 'grand';
  location?: string;
  radius?: number;
  centerLatitude?: number;
  centerLongitude?: number;
  distance?: number;
  compatibility?: {
    withDogs?: boolean;
    withCats?: boolean;
    withChildren?: boolean;
  };
  minAssociationRating?: number; // Minimum association rating filter
}

// Family search filters for associations
export interface FamilySearchFilters {
  location?: string;
  radius?: number;
  centerLatitude?: number;
  centerLongitude?: number;
  
  // Housing filters
  housingType?: 'house_with_garden' | 'house_without_garden' | 'apartment_with_outdoor' | 'apartment_without_outdoor' | 'other';
  hasGarden?: boolean;
  hasDedicatedRoom?: boolean;
  
  // Animal type preferences
  acceptedAnimalTypes?: {
    dogs?: boolean;
    cats?: boolean;
    nac?: boolean;
    reptiles?: boolean;
    labAnimals?: boolean;
    farmAnimals?: boolean;
  };
  
  // Experience level
  experienceLevel?: 'beginner' | 'intermediate' | 'experienced';
  minPreviousFosterCount?: number;
  
  // Capabilities
  canProvideMedicalCare?: boolean;
  hasVehicle?: boolean;
  
  // Verification status
  isVerified?: boolean;
  isTopFosterFamily?: boolean;
  
  // Compatibility
  compatibility?: {
    withChildren?: boolean;
    withCats?: boolean;
    withDogs?: boolean;
    withOtherAnimals?: boolean;
  };
}

export type ViewMode = 'grid' | 'list' | 'map';

// Partner/Ad Banner Types
export interface PartnerOffer {
  id: string;
  title: string;
  productImageUrl: string;
  offerUrl: string;
  backgroundColor?: string;
}

// Adoption Request Types
export type AdoptionRequestStatus = 'pending' | 'accepted' | 'rejected' | 'contract_pending' | 'completed';

export interface FamilyAdoptionProfile {
  // Family situation
  familyComposition: {
    adults: number;
    children: number;
    childrenAges?: string;
  };
  
  // Housing details
  housingType: 'house_with_garden' | 'house_without_garden' | 'apartment_with_outdoor' | 'apartment_without_outdoor' | 'other';
  housingSize: string; // e.g., "100m²"
  hasGarden: boolean;
  gardenSize?: string;
  isOwner: boolean;
  landlordAgreement?: boolean;
  
  // Experience with animals
  previousPets: boolean;
  previousPetsDetails?: string;
  experienceLevel: 'none' | 'beginner' | 'intermediate' | 'experienced';
  
  // Daily presence and availability
  workSchedule: string;
  dailyPresence: string; // How many hours per day someone is home
  vacationPlans: string;
  
  // Financial situation
  monthlyBudget: string;
  emergencyFund: boolean;
  
  // Motivation and expectations
  adoptionMotivation: string;
  expectations: string;
  
  // Veterinary care
  veterinarianContact?: string;
  veterinaryClinic?: string;
  
  // Agreement and commitment
  agreesToVisits: boolean;
  agreesToUpdates: boolean;
  understandsCommitment: boolean;
  
  // Compatibility
  compatibility?: {
    withChildren: number;
    withCats: number;
    withDogs: number;
    withOtherAnimals: number;
  };
  
  // Additional information
  additionalInfo?: string;
}

export interface AdoptionRequest {
  id: string;
  requestType: 'foster' | 'adopt';
  animalId: string;
  animalName: string;
  familyId: string;
  familyName: string;
  associationId: string;
  associationName: string;
  status: AdoptionRequestStatus;
  familyAdoptionProfile: FamilyAdoptionProfile;
  submittedAt: Date;
  reviewedAt?: Date;
  reviewedBy?: string;
  reviewNotes?: string;
  contractUrl?: string;
  contractSignedAt?: Date;
}

export interface AdoptionContract {
  id: string;
  adoptionRequestId: string;
  animalId: string;
  familyId: string;
  associationId: string;
  contractUrl: string;
  createdAt: Date;
  signedByFamily?: boolean;
  signedByAssociation?: boolean;
  familySignedAt?: Date;
  associationSignedAt?: Date;
  completedAt?: Date;
}

// Notification System Types
export type NotificationType = 
  | 'new_message'
  | 'adoption_request_status'
  | 'animal_liked'
  | 'new_animal_available'
  | 'profile_verification'
  | 'reminder'
  | 'system_announcement';

export interface Notification {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  read: boolean;
  createdAt: Date;
  readAt?: Date;
  
  // Optional data for different notification types
  data?: {
    animalId?: string;
    animalName?: string;
    conversationId?: string;
    adoptionRequestId?: string;
    associationId?: string;
    associationName?: string;
    familyId?: string;
    familyName?: string;
    url?: string; // Link to relevant page
  };
  
  // Visual properties
  priority?: 'low' | 'medium' | 'high';
  category?: 'info' | 'success' | 'warning' | 'error';
}

// Predefined Messages Types
export interface PredefinedMessage {
  id: string;
  content: string;
  forUserType?: 'family' | 'association' | 'all';
  category?: string; // e.g., 'availability', 'care', 'documentation'
}