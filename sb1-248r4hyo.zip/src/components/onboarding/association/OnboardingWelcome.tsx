import React from 'react';
import { Building2, Users, Shield, ArrowRight, Award } from 'lucide-react';
import { Button } from '../../ui/Button';
import { Card } from '../../ui/Card';

interface OnboardingWelcomeProps {
  onNext: () => void;
}

export function OnboardingWelcome({ onNext }: OnboardingWelcomeProps) {
  return (
    <div className="max-w-2xl mx-auto text-center space-y-8">
      {/* Hero Section */}
      <div className="space-y-6">
        <div className="w-20 h-20 bg-kiweetoTeal-100 rounded-full flex items-center justify-center mx-auto">
          <Building2 className="h-10 w-10 text-kiweetoTeal-600" />
        </div>
        
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Bienvenue sur Kiweeto ! 🎉
          </h1>
          <p className="text-xl text-gray-600 leading-relaxed">
            Merci de rejoindre notre réseau d'associations partenaires. 
            Ensemble, nous facilitons la mise en relation avec des familles d'accueil de confiance.
          </p>
        </div>
      </div>

      {/* Mission Statement */}
      <Card className="bg-gradient-to-r from-kiweetoTeal-50 to-kiweetoLightBlue-50 border-kiweetoTeal-200">
        <div className="text-center space-y-4">
          <h2 className="text-xl font-semibold text-kiweetoTeal-800">
            Votre mission sur Kiweeto
          </h2>
          <p className="text-kiweetoTeal-700 leading-relaxed">
            En tant qu'association partenaire, vous bénéficiez d'outils modernes pour gérer 
            vos animaux, trouver des familles d'accueil qualifiées et suivre les placements 
            en toute sérénité.
          </p>
        </div>
      </Card>

      {/* Key Benefits */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="text-center p-6">
          <div className="w-12 h-12 bg-kiweetoTeal-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Users className="h-6 w-6 text-kiweetoTeal-600" />
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">Familles vérifiées</h3>
          <p className="text-sm text-gray-600">
            Accédez à un réseau de familles d'accueil pré-qualifiées et motivées
          </p>
        </Card>

        <Card className="text-center p-6">
          <div className="w-12 h-12 bg-kiweetoLightBlue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Shield className="h-6 w-6 text-kiweetoLightBlue-600" />
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">Gestion sécurisée</h3>
          <p className="text-sm text-gray-600">
            Outils de suivi complets avec protection des données sensibles
          </p>
        </Card>

        <Card className="text-center p-6">
          <div className="w-12 h-12 bg-kiweetoOrange-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Award className="h-6 w-6 text-kiweetoOrange-600" />
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">Visibilité accrue</h3>
          <p className="text-sm text-gray-600">
            Augmentez la portée de vos actions et trouvez plus rapidement des solutions
          </p>
        </Card>
      </div>

      {/* Next Steps */}
      <Card className="bg-white border-2 border-kiweetoTeal-200">
        <div className="text-center space-y-4">
          <h2 className="text-lg font-semibold text-gray-900">
            Configurons votre association
          </h2>
          <p className="text-gray-600">
            Nous allons vous accompagner dans la configuration de votre profil pour optimiser 
            vos chances de trouver des familles d'accueil adaptées à vos animaux.
          </p>
          <p className="text-sm text-gray-500">
            ⏱️ Cela prend environ 10-15 minutes
          </p>
        </div>
      </Card>

      {/* CTA */}
      <div className="pt-4">
        <Button
          onClick={onNext}
          size="lg"
          variant="kiweetoTeal"
          icon={ArrowRight}
          iconPosition="right"
          className="px-8"
        >
          Commencer la configuration
        </Button>
      </div>
    </div>
  );
}