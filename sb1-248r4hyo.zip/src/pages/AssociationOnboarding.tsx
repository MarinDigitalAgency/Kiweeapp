import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, CheckCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '../components/ui/Button';
import { AssociationProfile } from '../types';

// Import onboarding step components
import { OnboardingWelcome } from '../components/onboarding/association/OnboardingWelcome';
import { OnboardingAdminValidation } from '../components/onboarding/association/OnboardingAdminValidation';
import { OnboardingAssociationProfile } from '../components/onboarding/association/OnboardingAssociationProfile';
import { OnboardingFeaturesPresentation } from '../components/onboarding/association/OnboardingFeaturesPresentation';
import { OnboardingSummaryAndCommitment } from '../components/onboarding/association/OnboardingSummaryAndCommitment';

const TOTAL_STEPS = 5;

const stepTitles = [
  'Bienvenue',
  'Validation administrative',
  'Profil association',
  'Fonctionnalités',
  'Récapitulatif'
];

export function AssociationOnboarding() {
  const { user, updateUserProfile } = useAuth();
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [onboardingData, setOnboardingData] = useState<Partial<AssociationProfile>>({
    // Initialize with default values
    rna: '',
    siret: '',
    presidentName: '',
    foundedYear: new Date().getFullYear(),
    fullAddress: '',
    description: '',
    website: '',
    contactEmail: '',
    contactPhone: '',
    acacedCertifications: [],
    otherCertifications: [],
    animalTypes: [],
    animalsCurrentlyInCare: 0,
    averageAnimalsPerYear: 0,
    totalAnimalsHelped: 0,
    services: {
      fostering: true,
      adoption: true,
      veterinaryCare: false,
      behavioralSupport: false,
      emergency: false
    },
    coverageRadius: 50,
    coverageCities: [],
    agreesToCharter: false
  });

  // Redirect if user is not an association or already completed onboarding
  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    if (user.type !== 'association') {
      navigate('/dashboard');
      return;
    }

    if (user.profile?.onboardingCompleted) {
      navigate('/dashboard');
      return;
    }
  }, [user, navigate]);

  const handleUpdateData = (updates: Partial<AssociationProfile>) => {
    setOnboardingData(prev => ({ ...prev, ...updates }));
  };

  const nextStep = () => {
    if (currentStep < TOTAL_STEPS) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const skipStep = () => {
    nextStep();
  };

  const goToStep = (step: number) => {
    setCurrentStep(step);
  };

  const handleComplete = async () => {
    if (!user) return;

    try {
      // Update user profile with onboarding data
      updateUserProfile({
        associationProfile: {
          ...user.profile?.associationProfile,
          ...onboardingData,
          charterAcceptedAt: onboardingData.agreesToCharter ? new Date() : undefined
        },
        onboardingCompleted: true
      });

      // Navigate to dashboard with success message
      navigate('/dashboard', {
        state: {
          message: 'Félicitations ! Votre association est maintenant configurée. Vous pouvez commencer à ajouter vos animaux et rechercher des familles d\'accueil.',
          type: 'success'
        }
      });
    } catch (error) {
      console.error('Error completing onboarding:', error);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return <OnboardingWelcome onNext={nextStep} />;
      case 2:
        return (
          <OnboardingAdminValidation
            data={onboardingData}
            onUpdate={handleUpdateData}
            onNext={nextStep}
            onPrev={prevStep}
            onSkip={skipStep}
          />
        );
      case 3:
        return (
          <OnboardingAssociationProfile
            data={onboardingData}
            onUpdate={handleUpdateData}
            onNext={nextStep}
            onPrev={prevStep}
            onSkip={skipStep}
          />
        );
      case 4:
        return (
          <OnboardingFeaturesPresentation
            onNext={nextStep}
            onPrev={prevStep}
          />
        );
      case 5:
        return (
          <OnboardingSummaryAndCommitment
            data={onboardingData}
            onComplete={handleComplete}
            onPrev={prevStep}
            onGoToStep={goToStep}
          />
        );
      default:
        return null;
    }
  };

  if (!user || user.type !== 'association') {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-kiweetoTeal-50 to-kiweetoLightBlue-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                icon={ArrowLeft}
                onClick={() => navigate('/dashboard')}
                className="text-gray-600"
              >
                Quitter
              </Button>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Configuration de votre association</h1>
                <p className="text-sm text-gray-600">
                  Étape {currentStep} sur {TOTAL_STEPS} : {stepTitles[currentStep - 1]}
                </p>
              </div>
            </div>
            <div className="text-sm text-gray-500">
              {Math.round((currentStep / TOTAL_STEPS) * 100)}% complété
            </div>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-4xl mx-auto px-4">
          <div className="w-full bg-gray-200 h-2">
            <div
              className="bg-kiweetoTeal-600 h-2 transition-all duration-500 ease-out"
              style={{ width: `${(currentStep / TOTAL_STEPS) * 100}%` }}
            />
          </div>
        </div>
      </div>

      {/* Step Navigation */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-4xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between text-xs">
            {stepTitles.map((title, index) => {
              const stepNumber = index + 1;
              const isCompleted = stepNumber < currentStep;
              const isCurrent = stepNumber === currentStep;
              
              return (
                <div
                  key={stepNumber}
                  className={`flex items-center space-x-1 ${
                    stepNumber <= currentStep ? 'text-kiweetoTeal-600' : 'text-gray-400'
                  }`}
                >
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium ${
                      isCompleted
                        ? 'bg-kiweetoTeal-600 text-white'
                        : isCurrent
                        ? 'bg-kiweetoTeal-100 text-kiweetoTeal-600 border-2 border-kiweetoTeal-600'
                        : 'bg-gray-200 text-gray-500'
                    }`}
                  >
                    {isCompleted ? (
                      <CheckCircle className="h-4 w-4" />
                    ) : (
                      stepNumber
                    )}
                  </div>
                  <span className="hidden sm:block font-medium">{title}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        {renderStep()}
      </div>
    </div>
  );
}