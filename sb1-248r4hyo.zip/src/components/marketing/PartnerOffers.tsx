import React, { useState, useEffect } from 'react';
import { AdBanner } from './AdBanner';
import { PartnerOffer } from '../../types';

interface PartnerOffersProps {
  partners: PartnerOffer[];
}

export function PartnerOffers({ partners }: PartnerOffersProps) {
  const [currentPartner, setCurrentPartner] = useState<PartnerOffer | null>(null);
  
  // Select a random partner on mount and when partners change
  useEffect(() => {
    if (partners.length > 0) {
      const randomIndex = Math.floor(Math.random() * partners.length);
      setCurrentPartner(partners[randomIndex]);
    }
  }, [partners]);
  
  if (!currentPartner) return null;
  
  return (
    <section className="py-8 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AdBanner partner={currentPartner} />
      </div>
    </section>
  );
}