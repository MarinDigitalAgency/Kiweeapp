import React, { useState, useEffect } from 'react';
import { Save, Building2, Award, MapPin, Activity } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Card } from '../ui/Card';
import { AssociationProfile } from '../../types';

export function AssociationProfileForm() {
  const { user, updateUserProfile } = useAuth();
  const [profile, setProfile] = useState<Partial<AssociationProfile>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    if (user?.profile?.associationProfile) {
      setProfile(user.profile.associationProfile);
    } else {
      // Set default values if no profile exists
      setProfile({
        rna: '',
        siret: '',
        presidentName: '',
        foundedYear: new Date().getFullYear(),
        acacedCertifications: [],
        otherCertifications: [],
        animalTypes: ['chien', 'chat'],
        animalsCurrentlyInCare: 0,
        averageAnimalsPerYear: 0,
        totalAnimalsHelped: 0,
        services: {
          fostering: true,
          adoption: true,
          veterinaryCare: false,
          behavioralSupport: false,
          emergency: false
        },
        coverageRadius: 50,
        coverageCities: []
      });
    }
  }, [user]);

  const handleSave = async () => {
    setIsLoading(true);
    setSuccessMessage('');
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Update the user profile
      updateUserProfile({
        associationProfile: profile as AssociationProfile
      });
      
      setSuccessMessage('Profil mis à jour avec succès !');
      
      // Clear success message after 3 seconds
      setTimeout(() => setSuccessMessage(''), 3000);
    } catch (error) {
      console.error('Error updating profile:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const updateProfile = (updates: Partial<AssociationProfile>) => {
    setProfile(prev => ({ ...prev, ...updates }));
  };

  const updateNestedField = (field: keyof AssociationProfile, subField: string, value: any) => {
    setProfile(prev => ({
      ...prev,
      [field]: {
        ...prev[field],
        [subField]: value
      }
    }));
  };

  return (
    <div className="space-y-6">
      {successMessage && (
        <div className="bg-success-50 border border-success-200 text-success-700 px-4 py-3 rounded-md">
          {successMessage}
        </div>
      )}

      {/* Informations légales */}
      <Card>
        <div className="flex items-center space-x-2 mb-6">
          <Building2 className="h-5 w-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Informations légales</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Numéro RNA"
            value={profile.rna || ''}
            onChange={(e) => updateProfile({ rna: e.target.value })}
            placeholder="W123456789"
            required
          />

          <Input
            label="SIRET (optionnel)"
            value={profile.siret || ''}
            onChange={(e) => updateProfile({ siret: e.target.value })}
            placeholder="12345678901234"
          />

          <Input
            label="Nom du président"
            value={profile.presidentName || ''}
            onChange={(e) => updateProfile({ presidentName: e.target.value })}
            required
          />

          <Input
            label="Année de création"
            type="number"
            value={profile.foundedYear || new Date().getFullYear()}
            onChange={(e) => updateProfile({ foundedYear: parseInt(e.target.value) || new Date().getFullYear() })}
            min="1900"
            max={new Date().getFullYear()}
            required
          />
        </div>
      </Card>

      {/* Certifications */}
      <Card>
        <div className="flex items-center space-x-2 mb-6">
          <Award className="h-5 w-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Certifications</h3>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Certifications ACACED
            </label>
            <textarea
              value={profile.acacedCertifications?.join('\n') || ''}
              onChange={(e) => updateProfile({ 
                acacedCertifications: e.target.value.split('\n').filter(cert => cert.trim()) 
              })}
              placeholder="Entrez les numéros de certification ACACED (un par ligne)"
              rows={3}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
            />
            <p className="text-xs text-gray-500 mt-1">
              Un numéro de certification par ligne
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Autres certifications
            </label>
            <textarea
              value={profile.otherCertifications?.join('\n') || ''}
              onChange={(e) => updateProfile({ 
                otherCertifications: e.target.value.split('\n').filter(cert => cert.trim()) 
              })}
              placeholder="Autres certifications ou agréments (un par ligne)"
              rows={3}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
            />
          </div>
        </div>
      </Card>

      {/* Activité */}
      <Card>
        <div className="flex items-center space-x-2 mb-6">
          <Activity className="h-5 w-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Activité</h3>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Types d'animaux pris en charge
            </label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {['chien', 'chat', 'nac', 'reptile', 'animaux de laboratoire', 'animaux de ferme'].map((type) => (
                <label key={type} className="flex items-center">
                  <input
                    type="checkbox"
                    checked={profile.animalTypes?.includes(type) || false}
                    onChange={(e) => {
                      const types = profile.animalTypes || [];
                      if (e.target.checked) {
                        updateProfile({ animalTypes: [...types, type] });
                      } else {
                        updateProfile({ animalTypes: types.filter(t => t !== type) });
                      }
                    }}
                    className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                  />
                  <span className="ml-2 text-sm text-gray-700 capitalize">{type}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Animaux actuellement suivis"
              type="number"
              value={profile.animalsCurrentlyInCare || 0}
              onChange={(e) => updateProfile({ animalsCurrentlyInCare: parseInt(e.target.value) || 0 })}
              min="0"
            />

            <Input
              label="Animaux aidés par an (moyenne)"
              type="number"
              value={profile.averageAnimalsPerYear || 0}
              onChange={(e) => updateProfile({ averageAnimalsPerYear: parseInt(e.target.value) || 0 })}
              min="0"
            />
          </div>
        </div>
      </Card>

      {/* Services */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-6">Services proposés</h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {Object.entries(profile.services || {}).map(([key, value]) => (
            <label key={key} className="flex items-center">
              <input
                type="checkbox"
                checked={value || false}
                onChange={(e) => updateNestedField('services', key, e.target.checked)}
                className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
              />
              <span className="ml-2 text-sm text-gray-700">
                {key === 'fostering' && 'Familles d\'accueil'}
                {key === 'adoption' && 'Adoption'}
                {key === 'veterinaryCare' && 'Soins vétérinaires'}
                {key === 'behavioralSupport' && 'Soutien comportemental'}
                {key === 'emergency' && 'Urgences'}
              </span>
            </label>
          ))}
        </div>
      </Card>

      {/* Zone de couverture */}
      <Card>
        <div className="flex items-center space-x-2 mb-6">
          <MapPin className="h-5 w-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Zone de couverture</h3>
        </div>

        <div className="space-y-4">
          <Input
            label="Rayon d'action (km)"
            type="number"
            value={profile.coverageRadius || 0}
            onChange={(e) => updateProfile({ coverageRadius: parseInt(e.target.value) || 0 })}
            min="0"
            max="500"
          />

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Villes couvertes
            </label>
            <textarea
              value={profile.coverageCities?.join('\n') || ''}
              onChange={(e) => updateProfile({ 
                coverageCities: e.target.value.split('\n').filter(city => city.trim()) 
              })}
              placeholder="Entrez les villes couvertes (une par ligne)"
              rows={4}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
            />
            <p className="text-xs text-gray-500 mt-1">
              Une ville par ligne
            </p>
          </div>
        </div>
      </Card>

      {/* Actions */}
      <div className="flex justify-end space-x-4">
        <Button
          onClick={handleSave}
          loading={isLoading}
          icon={Save}
        >
          Enregistrer
        </Button>
      </div>
    </div>
  );
}