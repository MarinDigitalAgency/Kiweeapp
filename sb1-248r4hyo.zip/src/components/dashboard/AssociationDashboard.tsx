import React, { useState } from 'react';
import { Plus, BarChart3, Users, MessageCircle, Calendar, Search } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { AnimalManagementList } from '../animals/AnimalManagementList';
import { InterestedFamiliesList } from './InterestedFamiliesList';
import { mockAnimals } from '../../data/mockData';
import { Animal } from '../../types';

export function AssociationDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [animals, setAnimals] = useState(mockAnimals.filter(animal => animal.associationId === user?.id));
  
  const [stats] = useState({
    totalAnimals: animals.length,
    availableAnimals: animals.filter(a => a.status === 'available').length,
    inCareAnimals: animals.filter(a => a.status === 'in_care').length,
    adoptedAnimals: animals.filter(a => a.status === 'adopted').length,
    totalRequests: 15,
    pendingRequests: 3
  });

  const handleStatusChange = (animalId: string, newStatus: Animal['status']) => {
    setAnimals(prev => prev.map(animal => 
      animal.id === animalId 
        ? { ...animal, status: newStatus }
        : animal
    ));
    // En production, vous feriez un appel API ici
    console.log(`Animal ${animalId} status changed to ${newStatus}`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-kiweetoTeal-700">
          Tableau de bord - {user?.name}
        </h1>
        <p className="text-gray-600 mt-2">
          Gérez vos animaux et suivez vos demandes d'accueil
        </p>
      </div>

      {/* Quick Actions */}
      <div className="mb-8 flex flex-wrap gap-4">
        <Button as={Link} to="/animals/new" icon={Plus} variant="kiweetoTeal">
          Ajouter un animal
        </Button>
        <Button variant="outline" as={Link} to="/search-families" icon={Search}>
          Rechercher des familles
        </Button>
        <Button variant="outline" as={Link} to="/messages" icon={MessageCircle}>
          Messages ({stats.pendingRequests})
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="text-center">
          <div className="text-2xl font-bold text-kiweetoTeal-600">{stats.totalAnimals}</div>
          <div className="text-gray-600">Animaux</div>
        </Card>
        <Card className="text-center">
          <div className="text-2xl font-bold text-warning-600">{stats.availableAnimals}</div>
          <div className="text-gray-600">Recherchent famille</div>
        </Card>
        <Card className="text-center">
          <div className="text-2xl font-bold text-kiweetoOrange-600">{stats.inCareAnimals}</div>
          <div className="text-gray-600">En cours d'accueil</div>
        </Card>
        <Card className="text-center">
          <div className="text-2xl font-bold text-success-600">{stats.adoptedAnimals}</div>
          <div className="text-gray-600">Ont trouvé une famille</div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Main Content - Animal Management List */}
        <div className="lg:col-span-4">
          <AnimalManagementList
            animals={animals}
            onStatusChange={handleStatusChange}
          />
        </div>
      </div>

      {/* Familles intéressées - Section séparée en bas */}
      <div className="mt-12">
        <InterestedFamiliesList />
      </div>

      {/* Sidebar content moved to bottom for better mobile experience */}
      <div className="mt-12 grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Messages récents */}
        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Messages récents</h3>
          <div className="space-y-3">
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                <span className="text-xs font-medium text-primary-600">SM</span>
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-900">Sophie Martin</p>
                <p className="text-xs text-gray-600">Intéressée par Luna</p>
                <p className="text-xs text-gray-400">Il y a 2h</p>
              </div>
              <div className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></div>
            </div>
            
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-secondary-100 rounded-full flex items-center justify-center">
                <span className="text-xs font-medium text-secondary-600">JD</span>
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-900">Julie Dupont</p>
                <p className="text-xs text-gray-600">Question sur Rex</p>
                <p className="text-xs text-gray-400">Il y a 5h</p>
              </div>
            </div>
          </div>
          <Button size="sm" variant="outline" className="w-full mt-4" as={Link} to="/messages">
            Voir tous les messages
          </Button>
        </Card>

        {/* Statistiques rapides */}
        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Activité</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Vues cette semaine</span>
              <span className="font-semibold text-gray-900">47</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Nouvelles demandes</span>
              <span className="font-semibold text-kiweetoTeal-600">3</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Matches cette semaine</span>
              <span className="font-semibold text-kiweetoLightBlue-600">2</span>
            </div>
          </div>
        </Card>

        {/* Conseils */}
        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">💡 Conseil du jour</h3>
          <p className="text-sm text-gray-600 mb-3">
            Utilisez les filtres par statut pour suivre facilement l'évolution de vos animaux. 
            Changez leur statut directement depuis la liste !
          </p>
          <Button size="sm" variant="outline" className="w-full" as={Link} to="/search-families">
            Rechercher des familles
          </Button>
        </Card>
      </div>
    </div>
  );
}