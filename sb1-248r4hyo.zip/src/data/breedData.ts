// Common breeds for different animal types
export const breedData = {
  chien: [
    'Berger Allemand',
    'Berger Australien',
    'Beagle',
    'Border Collie',
    'Bouledogue Français',
    'Boxer',
    'Caniche',
    'Cavalier King Charles',
    'Chihuahua',
    'Cocker',
    'Golden Retriever',
    'Husky',
    'Jack Russell',
    'Labrador',
    'Malinois',
    'Rottweiler',
    'Shih Tzu',
    'Teckel',
    'Yorkshire',
    'Croisé',
    'Inconnue'
  ],
  chat: [
    'Abyssin',
    'American Shorthair',
    'Bengal',
    'British Shorthair',
    'Chartreux',
    'Européen',
    'Maine Coon',
    'Norvégien',
    'Persan',
    'Ragdoll',
    'Sacré de Birmanie',
    'Siamois',
    'Sphynx',
    'Croisé',
    'Inconnue'
  ],
  autre: [
    'Lapin',
    'Hamster',
    'Cochon d\'Inde',
    'Furet',
    'Rat',
    'Souris',
    'Gerbille',
    'Chinchilla',
    'Tortue',
    'Oiseau',
    'Poisson',
    'Reptile',
    'Croisé',
    'Inconnue'
  ]
};

// Get all unique breeds from all animal types
export const getAllBreeds = () => {
  const allBreeds = new Set<string>();
  
  Object.values(breedData).forEach(breeds => {
    breeds.forEach(breed => allBreeds.add(breed));
  });
  
  return Array.from(allBreeds).sort();
};

// Get breeds for a specific animal type
export const getBreedsByType = (type?: string) => {
  if (!type || !breedData[type as keyof typeof breedData]) {
    return getAllBreeds();
  }
  
  return breedData[type as keyof typeof breedData];
};