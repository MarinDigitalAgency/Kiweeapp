import React, { useState } from 'react';
import { Save, ArrowLeft, Users, Home, Heart, DollarSign, FileText, AlertCircle } from 'lucide-react';
import { FamilyAdoptionProfile } from '../../types';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Card } from '../ui/Card';

interface AdoptionRequestFormProps {
  onSubmit: (profile: FamilyAdoptionProfile) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function AdoptionRequestForm({ onSubmit, onCancel, isLoading = false }: AdoptionRequestFormProps) {
  const [profile, setProfile] = useState<FamilyAdoptionProfile>({
    familyComposition: {
      adults: 1,
      children: 0,
      childrenAges: ''
    },
    housingType: 'house_with_garden',
    housingSize: '',
    hasGarden: true,
    gardenSize: '',
    isOwner: true,
    landlordAgreement: false,
    previousPets: false,
    previousPetsDetails: '',
    experienceLevel: 'beginner',
    workSchedule: '',
    dailyPresence: '',
    vacationPlans: '',
    monthlyBudget: '',
    emergencyFund: false,
    adoptionMotivation: '',
    expectations: '',
    veterinarianContact: '',
    veterinaryClinic: '',
    agreesToVisits: false,
    agreesToUpdates: false,
    understandsCommitment: false,
    additionalInfo: '',
    compatibility: {
      withChildren: 0,
      withCats: 0,
      withDogs: 0,
      withOtherAnimals: 0
    }
  });

  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 6;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    const requiredFields = [
      'adoptionMotivation',
      'expectations',
      'workSchedule',
      'dailyPresence',
      'monthlyBudget'
    ];
    
    const missingFields = requiredFields.filter(field => !profile[field as keyof FamilyAdoptionProfile]);
    
    if (missingFields.length > 0 || !profile.agreesToVisits || !profile.agreesToUpdates || !profile.understandsCommitment) {
      alert('Veuillez remplir tous les champs obligatoires et accepter les conditions.');
      return;
    }
    
    onSubmit(profile);
  };

  const updateProfile = (updates: Partial<FamilyAdoptionProfile>) => {
    setProfile(prev => ({ ...prev, ...updates }));
  };

  const updateNestedField = (field: keyof FamilyAdoptionProfile, subField: string, value: any) => {
    setProfile(prev => ({
      ...prev,
      [field]: {
        ...prev[field],
        [subField]: value
      }
    }));
  };

  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <Card>
            <div className="flex items-center space-x-2 mb-6">
              <Users className="h-5 w-5 text-primary-600" />
              <h3 className="text-lg font-semibold text-gray-900">Composition familiale</h3>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  label="Nombre d'adultes *"
                  type="number"
                  value={profile.familyComposition.adults}
                  onChange={(e) => updateNestedField('familyComposition', 'adults', parseInt(e.target.value) || 1)}
                  min="1"
                  max="10"
                  required
                />

                <Input
                  label="Nombre d'enfants"
                  type="number"
                  value={profile.familyComposition.children}
                  onChange={(e) => updateNestedField('familyComposition', 'children', parseInt(e.target.value) || 0)}
                  min="0"
                  max="10"
                />
              </div>

              {profile.familyComposition.children > 0 && (
                <Input
                  label="Âges des enfants"
                  value={profile.familyComposition.childrenAges || ''}
                  onChange={(e) => updateNestedField('familyComposition', 'childrenAges', e.target.value)}
                  placeholder="Ex: 5 ans, 8 ans, 12 ans"
                />
              )}
            </div>
          </Card>
        );

      case 2:
        return (
          <Card>
            <div className="flex items-center space-x-2 mb-6">
              <Home className="h-5 w-5 text-primary-600" />
              <h3 className="text-lg font-semibold text-gray-900">Logement</h3>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Type de logement *
                </label>
                <select
                  value={profile.housingType}
                  onChange={(e) => updateProfile({ housingType: e.target.value as any })}
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                  required
                >
                  <option value="maison">Maison</option>
                  <option value="appartement">Appartement</option>
                  <option value="studio">Studio</option>
                  <option value="chambre">Chambre</option>
                  <option value="other">Autre</option>
                </select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  label="Superficie du logement *"
                  value={profile.housingSize}
                  onChange={(e) => updateProfile({ housingSize: e.target.value })}
                  placeholder="Ex: 100m²"
                  required
                />

                {profile.hasGarden && (
                  <Input
                    label="Taille du jardin"
                    value={profile.gardenSize || ''}
                    onChange={(e) => updateProfile({ gardenSize: e.target.value })}
                    placeholder="Ex: 500m²"
                  />
                )}
              </div>

              <div className="space-y-3">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={profile.hasGarden}
                    onChange={(e) => updateProfile({ hasGarden: e.target.checked })}
                    className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Jardin disponible</span>
                </label>

                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={profile.isOwner}
                    onChange={(e) => updateProfile({ isOwner: e.target.checked })}
                    className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Propriétaire du logement</span>
                </label>

                {!profile.isOwner && (
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={profile.landlordAgreement || false}
                      onChange={(e) => updateProfile({ landlordAgreement: e.target.checked })}
                      className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                    />
                    <span className="ml-2 text-sm text-gray-700">Accord du propriétaire obtenu</span>
                  </label>
                )}
              </div>
            </div>
          </Card>
        );

      case 3:
        return (
          <>
          <Card>
            <div className="flex items-center space-x-2 mb-6">
              <Users className="h-5 w-5 text-primary-600" />
              <h3 className="text-lg font-semibold text-gray-900">Animaux et enfants dans le foyer</h3>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nombre d'enfants dans le foyer
                </label>
                <input
                  type="number"
                  value={profile.compatibility?.withChildren || 0}
                  onChange={(e) => updateNestedField('compatibility', 'withChildren', parseInt(e.target.value) || 0)}
                  min="0"
                  max="10"
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nombre de chats dans le foyer
                </label>
                <input
                  type="number"
                  value={profile.compatibility?.withCats || 0}
                  onChange={(e) => updateNestedField('compatibility', 'withCats', parseInt(e.target.value) || 0)}
                  min="0"
                  max="10"
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nombre de chiens dans le foyer
                </label>
                <input
                  type="number"
                  value={profile.compatibility?.withDogs || 0}
                  onChange={(e) => updateNestedField('compatibility', 'withDogs', parseInt(e.target.value) || 0)}
                  min="0"
                  max="10"
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nombre d'autres animaux dans le foyer
                </label>
                <input
                  type="number"
                  value={profile.compatibility?.withOtherAnimals || 0}
                  onChange={(e) => updateNestedField('compatibility', 'withOtherAnimals', parseInt(e.target.value) || 0)}
                  min="0"
                  max="10"
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                />
                <p className="text-xs text-gray-500 mt-1">
                  NAC, oiseaux, reptiles, etc.
                </p>
              </div>
            </div>
          </Card>

          <Card>
            <div className="flex items-center space-x-2 mb-6">
              <Heart className="h-5 w-5 text-primary-600" />
              <h3 className="text-lg font-semibold text-gray-900">Expérience avec les animaux</h3>
            </div>

            <div className="space-y-4">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={profile.previousPets}
                  onChange={(e) => updateProfile({ previousPets: e.target.checked })}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">J'ai déjà eu des animaux de compagnie</span>
              </label>

              {profile.previousPets && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Détails sur vos animaux précédents
                  </label>
                  <textarea
                    value={profile.previousPetsDetails || ''}
                    onChange={(e) => updateProfile({ previousPetsDetails: e.target.value })}
                    rows={3}
                    className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                    placeholder="Types d'animaux, durée, expériences..."
                  />
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Niveau d'expérience *
                </label>
                <select
                  value={profile.experienceLevel}
                  onChange={(e) => updateProfile({ experienceLevel: e.target.value as any })}
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                  required
                >
                  <option value="none">Aucune expérience</option>
                  <option value="beginner">Débutant</option>
                  <option value="intermediate">Intermédiaire</option>
                  <option value="experienced">Expérimenté</option>
                </select>
              </div>
            </div>
          </Card>
          </>
        );

      case 4:
        return (
          <Card>
            <div className="flex items-center space-x-2 mb-6">
              <FileText className="h-5 w-5 text-primary-600" />
              <h3 className="text-lg font-semibold text-gray-900">Disponibilité et mode de vie</h3>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Horaires de travail *
                </label>
                <textarea
                  value={profile.workSchedule}
                  onChange={(e) => updateProfile({ workSchedule: e.target.value })}
                  rows={2}
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                  placeholder="Ex: 9h-17h du lundi au vendredi, télétravail 2 jours/semaine"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Présence quotidienne à domicile *
                </label>
                <input
                  type="text"
                  value={profile.dailyPresence}
                  onChange={(e) => updateProfile({ dailyPresence: e.target.value })}
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                  placeholder="Ex: 6-8h par jour, quelqu'un toujours présent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Projets de vacances/absences
                </label>
                <textarea
                  value={profile.vacationPlans}
                  onChange={(e) => updateProfile({ vacationPlans: e.target.value })}
                  rows={2}
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                  placeholder="Fréquence, durée, solutions de garde prévues..."
                />
              </div>
            </div>
          </Card>
        );

      case 5:
        return (
          <Card>
            <div className="flex items-center space-x-2 mb-6">
              <DollarSign className="h-5 w-5 text-primary-600" />
              <h3 className="text-lg font-semibold text-gray-900">Situation financière et motivation</h3>
            </div>

            <div className="space-y-4">
              <Input
                label="Budget mensuel prévu pour l'animal *"
                value={profile.monthlyBudget}
                onChange={(e) => updateProfile({ monthlyBudget: e.target.value })}
                placeholder="Ex: 100-150€ (nourriture, soins, accessoires)"
                required
              />

              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={profile.emergencyFund}
                  onChange={(e) => updateProfile({ emergencyFund: e.target.checked })}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">
                  Je dispose d'un fonds d'urgence pour les frais vétérinaires imprévus
                </span>
              </label>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Motivation pour l'adoption *
                </label>
                <textarea
                  value={profile.adoptionMotivation}
                  onChange={(e) => updateProfile({ adoptionMotivation: e.target.value })}
                  rows={3}
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                  placeholder="Pourquoi souhaitez-vous adopter cet animal ?"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Attentes et projet de vie avec l'animal *
                </label>
                <textarea
                  value={profile.expectations}
                  onChange={(e) => updateProfile({ expectations: e.target.value })}
                  rows={3}
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                  placeholder="Que recherchez-vous ? Quelles activités prévoyez-vous ?"
                  required
                />
              </div>
            </div>
          </Card>
        );

      case 6:
        return (
          <Card>
            <div className="flex items-center space-x-2 mb-6">
              <AlertCircle className="h-5 w-5 text-primary-600" />
              <h3 className="text-lg font-semibold text-gray-900">Informations complémentaires et engagements</h3>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  label="Vétérinaire habituel"
                  value={profile.veterinarianContact || ''}
                  onChange={(e) => updateProfile({ veterinarianContact: e.target.value })}
                  placeholder="Nom du vétérinaire"
                />

                <Input
                  label="Clinique vétérinaire"
                  value={profile.veterinaryClinic || ''}
                  onChange={(e) => updateProfile({ veterinaryClinic: e.target.value })}
                  placeholder="Nom de la clinique"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Informations complémentaires
                </label>
                <textarea
                  value={profile.additionalInfo || ''}
                  onChange={(e) => updateProfile({ additionalInfo: e.target.value })}
                  rows={3}
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                  placeholder="Autres informations que vous souhaitez partager..."
                />
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-medium text-blue-900 mb-3">Engagements requis</h4>
                <div className="space-y-3">
                  <label className="flex items-start">
                    <input
                      type="checkbox"
                      checked={profile.agreesToVisits}
                      onChange={(e) => updateProfile({ agreesToVisits: e.target.checked })}
                      className="rounded border-gray-300 text-primary-600 focus:ring-primary-500 mt-1"
                      required
                    />
                    <span className="ml-2 text-sm text-blue-800">
                      J'accepte les visites de pré-adoption et de suivi de l'association
                    </span>
                  </label>

                  <label className="flex items-start">
                    <input
                      type="checkbox"
                      checked={profile.agreesToUpdates}
                      onChange={(e) => updateProfile({ agreesToUpdates: e.target.checked })}
                      className="rounded border-gray-300 text-primary-600 focus:ring-primary-500 mt-1"
                      required
                    />
                    <span className="ml-2 text-sm text-blue-800">
                      Je m'engage à donner des nouvelles régulières de l'animal
                    </span>
                  </label>

                  <label className="flex items-start">
                    <input
                      type="checkbox"
                      checked={profile.understandsCommitment}
                      onChange={(e) => updateProfile({ understandsCommitment: e.target.checked })}
                      className="rounded border-gray-300 text-primary-600 focus:ring-primary-500 mt-1"
                      required
                    />
                    <span className="ml-2 text-sm text-blue-800">
                      Je comprends que l'adoption est un engagement à vie (10-15 ans en moyenne)
                    </span>
                  </label>
                </div>
              </div>
            </div>
          </Card>
        );

      default:
        return null;
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Progress bar */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-gray-700">
            Étape {currentStep} sur {totalSteps}
          </span>
          <span className="text-sm text-gray-500">
            {Math.round((currentStep / totalSteps) * 100)}% complété
          </span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-primary-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${(currentStep / totalSteps) * 100}%` }}
          />
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        {renderStep()}

        {/* Navigation buttons */}
        <div className="flex justify-between mt-8">
          <div>
            {currentStep > 1 ? (
              <Button
                type="button"
                variant="outline"
                onClick={prevStep}
                icon={ArrowLeft}
              >
                Précédent
              </Button>
            ) : (
              <Button
                type="button"
                variant="outline"
                onClick={onCancel}
                icon={ArrowLeft}
              >
                Annuler
              </Button>
            )}
          </div>

          <div>
            {currentStep < totalSteps ? (
              <Button
                type="button"
                onClick={nextStep}
              >
                Suivant
              </Button>
            ) : (
              <Button
                type="submit"
                loading={isLoading}
                icon={Save}
              >
                Soumettre la demande
              </Button>
            )}
          </div>
        </div>
      </form>
    </div>
  );
}