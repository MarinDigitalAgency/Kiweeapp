import React from 'react';
import { MessageCircle, Clock } from 'lucide-react';
import { Conversation } from '../../types';
import { Badge } from '../ui/Badge';

interface ConversationListProps {
  conversations: Conversation[];
  selectedConversationId?: string;
  onSelectConversation: (conversationId: string) => void;
}

export function ConversationList({ 
  conversations, 
  selectedConversationId, 
  onSelectConversation 
}: ConversationListProps) {
  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);

    if (days > 0) {
      return `${days}j`;
    } else if (hours > 0) {
      return `${hours}h`;
    } else {
      return 'maintenant';
    }
  };

  return (
    <div className="bg-white border-r border-gray-200 h-full overflow-y-auto">
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-900 flex items-center">
          <MessageCircle className="h-5 w-5 mr-2 text-primary-600" />
          Messages
        </h2>
      </div>

      <div className="divide-y divide-gray-100">
        {conversations.map((conversation) => (
          <div
            key={conversation.id}
            onClick={() => onSelectConversation(conversation.id)}
            className={`p-4 cursor-pointer transition-colors duration-200 hover:bg-gray-50 ${
              selectedConversationId === conversation.id ? 'bg-primary-50 border-r-2 border-primary-500' : ''
            }`}
          >
            <div className="flex items-start space-x-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <h3 className="text-sm font-medium text-gray-900 truncate">
                    {conversation.animalName}
                  </h3>
                  <div className="flex items-center space-x-2">
                    {conversation.unreadCount > 0 && (
                      <Badge variant="primary" size="sm">
                        {conversation.unreadCount}
                      </Badge>
                    )}
                    <span className="text-xs text-gray-500 flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {conversation.lastMessage ? formatTime(conversation.lastMessage.timestamp) : ''}
                    </span>
                  </div>
                </div>
                
                <p className="text-sm text-gray-600 mb-1">
                  {conversation.participants.associationName}
                </p>
                
                {conversation.lastMessage && (
                  <p className="text-xs text-gray-500 truncate">
                    <span className="font-medium">
                      {conversation.lastMessage.senderName}:
                    </span>{' '}
                    {conversation.lastMessage.content}
                  </p>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {conversations.length === 0 && (
        <div className="p-8 text-center">
          <MessageCircle className="h-12 w-12 text-gray-300 mx-auto mb-4" />
          <h3 className="text-sm font-medium text-gray-900 mb-2">Aucune conversation</h3>
          <p className="text-xs text-gray-500">
            Vos conversations apparaîtront ici une fois que vous aurez contacté des associations ou des familles d'accueil.
          </p>
        </div>
      )}
    </div>
  );
}