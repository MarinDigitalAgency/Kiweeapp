import React from 'react';
import { Link } from 'react-router-dom';
import { Building2, MapPin } from 'lucide-react';
import { Animal } from '../../types';

interface ConversationHeaderProps {
  animal: Animal;
  associationName: string;
}

export function ConversationHeader({ animal, associationName }: ConversationHeaderProps) {
  return (
    <div className="bg-white border-b border-gray-200 p-4">
      <div className="flex items-center space-x-4">
        {/* Photo de l'animal */}
        <div className="flex-shrink-0">
          <img
            src={animal.photos[0]}
            alt={animal.name}
            className="w-16 h-16 rounded-lg object-cover border-2 border-gray-100"
          />
        </div>

        {/* Informations */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center space-x-2 mb-1">
            <span className="text-lg">📌</span>
            <span className="text-gray-700 font-medium">Pour l'accueil de</span>
            <Link
              to={`/animal/${animal.id}`}
              className="text-primary-600 hover:text-primary-700 font-semibold text-lg transition-colors duration-200 hover:underline"
            >
              {animal.name}
            </Link>
          </div>
          
          <div className="flex items-center space-x-2">
            <Building2 className="h-4 w-4 text-gray-400" />
            <span className="text-gray-600 text-sm">Association :</span>
            <span className="text-gray-900 font-medium">{associationName}</span>
          </div>

          {/* Informations supplémentaires sur l'animal */}
          <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
            <span>{animal.breed} • {animal.age} {animal.age > 1 ? 'ans' : 'an'}</span>
            <div className="flex items-center space-x-1">
              <MapPin className="h-3 w-3" />
              <span>{animal.location}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}