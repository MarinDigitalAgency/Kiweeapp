import React from 'react';
import { CheckCircle, Edit, ArrowLeft, Sparkles, Shield } from 'lucide-react';
import { Button } from '../../ui/Button';
import { Card } from '../../ui/Card';
import { Badge } from '../../ui/Badge';
import { AssociationProfile } from '../../../types';

interface OnboardingSummaryAndCommitmentProps {
  data: Partial<AssociationProfile>;
  onComplete: () => void;
  onPrev: () => void;
  onGoToStep: (step: number) => void;
}

export function OnboardingSummaryAndCommitment({
  data,
  onComplete,
  onPrev,
  onGoToStep
}: OnboardingSummaryAndCommitmentProps) {
  const summaryData = [
    {
      step: 2,
      title: 'Informations légales',
      icon: '🏛️',
      items: [
        { label: 'RNA', value: data.rna || 'Non renseigné' },
        { label: 'Président', value: data.presidentName || 'Non renseigné' },
        { label: 'Année de création', value: data.foundedYear?.toString() || 'Non renseigné' },
        { label: 'SIRET', value: data.siret || 'Non renseigné' }
      ]
    },
    {
      step: 3,
      title: 'Profil association',
      icon: '🏢',
      items: [
        { label: 'Adresse', value: data.fullAddress || 'Non renseignée' },
        { label: 'Email', value: data.contactEmail || 'Non renseigné' },
        { label: 'Téléphone', value: data.contactPhone || 'Non renseigné' },
        { label: 'Site web', value: data.website || 'Non renseigné' }
      ]
    }
  ];

  const getAnimalTypesText = () => {
    return data.animalTypes && data.animalTypes.length > 0 
      ? data.animalTypes.join(', ') 
      : 'Non spécifié';
  };

  const getServicesText = () => {
    if (!data.services) return 'Non spécifié';
    const activeServices = Object.entries(data.services)
      .filter(([_, active]) => active)
      .map(([key, _]) => {
        const serviceMap: Record<string, string> = {
          fostering: 'Familles d\'accueil',
          adoption: 'Adoption',
          veterinaryCare: 'Soins vétérinaires',
          behavioralSupport: 'Soutien comportemental',
          emergency: 'Urgences'
        };
        return serviceMap[key] || key;
      });
    return activeServices.length > 0 ? activeServices.join(', ') : 'Non spécifié';
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-gradient-to-br from-kiweetoTeal-500 to-kiweetoLightBlue-500 rounded-full flex items-center justify-center mx-auto">
          <Sparkles className="h-8 w-8 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            Récapitulatif et engagement
          </h1>
          <p className="text-gray-600">
            Vérifiez vos informations et acceptez la charte d'utilisation pour finaliser votre inscription.
          </p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {summaryData.map((section) => (
          <Card key={section.step} className="relative">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <span className="text-2xl">{section.icon}</span>
                <h3 className="text-lg font-semibold text-gray-900">{section.title}</h3>
              </div>
              <Button
                variant="ghost"
                size="sm"
                icon={Edit}
                onClick={() => onGoToStep(section.step)}
                className="text-gray-500 hover:text-gray-700"
              >
                Modifier
              </Button>
            </div>
            
            <div className="space-y-3">
              {section.items.map((item, index) => (
                <div key={index} className="flex justify-between items-start">
                  <span className="text-sm text-gray-600 font-medium">{item.label} :</span>
                  <span className="text-sm text-gray-900 text-right max-w-xs">{item.value}</span>
                </div>
              ))}
            </div>
          </Card>
        ))}
      </div>

      {/* Description */}
      {data.description && (
        <Card>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">📝 Description</h3>
            <Button
              variant="ghost"
              size="sm"
              icon={Edit}
              onClick={() => onGoToStep(3)}
              className="text-gray-500 hover:text-gray-700"
            >
              Modifier
            </Button>
          </div>
          <p className="text-gray-700 leading-relaxed">{data.description}</p>
        </Card>
      )}

      {/* Activity Summary */}
      <Card>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">🐾 Activité</h3>
          <Button
            variant="ghost"
            size="sm"
            icon={Edit}
            onClick={() => onGoToStep(3)}
            className="text-gray-500 hover:text-gray-700"
          >
            Modifier
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <span className="font-medium text-gray-600">Types d'animaux :</span>
            <p className="text-gray-900 mt-1">{getAnimalTypesText()}</p>
          </div>
          <div>
            <span className="font-medium text-gray-600">Services :</span>
            <p className="text-gray-900 mt-1">{getServicesText()}</p>
          </div>
          <div>
            <span className="font-medium text-gray-600">Capacité :</span>
            <p className="text-gray-900 mt-1">
              {data.animalsCurrentlyInCare || 0} animaux actuellement suivis
            </p>
          </div>
          <div>
            <span className="font-medium text-gray-600">Zone d'action :</span>
            <p className="text-gray-900 mt-1">{data.coverageRadius || 50} km de rayon</p>
          </div>
        </div>
      </Card>

      {/* Charter Acceptance */}
      <Card className="border-2 border-kiweetoTeal-200">
        <div className="flex items-center space-x-3 mb-6">
          <Shield className="h-6 w-6 text-kiweetoTeal-600" />
          <h3 className="text-lg font-semibold text-gray-900">
            Charte d'utilisation Kiweeto
          </h3>
        </div>
        
        <div className="bg-kiweetoTeal-50 border border-kiweetoTeal-200 rounded-lg p-4 mb-6">
          <h4 className="font-semibold text-kiweetoTeal-800 mb-3">Nos engagements mutuels</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-kiweetoTeal-700">
            <div className="space-y-2">
              <div className="flex items-start space-x-2">
                <CheckCircle className="h-4 w-4 text-kiweetoTeal-600 mt-0.5 flex-shrink-0" />
                <span>Respect du bien-être animal en toutes circonstances</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle className="h-4 w-4 text-kiweetoTeal-600 mt-0.5 flex-shrink-0" />
                <span>Communication transparente avec les familles d'accueil</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle className="h-4 w-4 text-kiweetoTeal-600 mt-0.5 flex-shrink-0" />
                <span>Suivi régulier des animaux placés</span>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-start space-x-2">
                <CheckCircle className="h-4 w-4 text-kiweetoTeal-600 mt-0.5 flex-shrink-0" />
                <span>Respect de la confidentialité des données</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle className="h-4 w-4 text-kiweetoTeal-600 mt-0.5 flex-shrink-0" />
                <span>Utilisation éthique de la plateforme</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle className="h-4 w-4 text-kiweetoTeal-600 mt-0.5 flex-shrink-0" />
                <span>Collaboration bienveillante avec la communauté</span>
              </div>
            </div>
          </div>
        </div>

        <label className="flex items-start space-x-3 p-4 bg-white border border-kiweetoTeal-200 rounded-lg cursor-pointer">
          <input
            type="checkbox"
            checked={data.agreesToCharter || false}
            onChange={(e) => {
              const updates: Partial<AssociationProfile> = { 
                agreesToCharter: e.target.checked 
              };
              if (e.target.checked) {
                updates.charterAcceptedAt = new Date();
              }
              // This would need to be passed from parent component
              // onUpdate(updates);
            }}
            className="rounded border-gray-300 text-kiweetoTeal-600 focus:ring-kiweetoTeal-500 mt-1"
            required
          />
          <div className="flex-1">
            <div className="font-medium text-gray-900 mb-1">
              J'accepte la charte d'utilisation Kiweeto
            </div>
            <div className="text-sm text-gray-600">
              En cochant cette case, je m'engage à respecter tous les points de cette charte 
              et à utiliser la plateforme dans l'intérêt des animaux et des familles d'accueil.
            </div>
          </div>
        </label>

        {!data.agreesToCharter && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mt-4">
            <p className="text-sm text-yellow-800">
              ⚠️ L'acceptation de la charte est obligatoire pour utiliser Kiweeto.
            </p>
          </div>
        )}
      </Card>

      {/* Success Message */}
      {data.agreesToCharter && (
        <Card className="bg-gradient-to-r from-kiweetoTeal-50 to-kiweetoLightBlue-50 border-kiweetoTeal-200">
          <div className="text-center space-y-4">
            <h3 className="text-xl font-semibold text-kiweetoTeal-800">
              🎉 Félicitations ! Votre association est prête !
            </h3>
            <p className="text-kiweetoTeal-700">
              Votre profil est maintenant configuré. Vous pouvez commencer à ajouter vos animaux 
              et à rechercher des familles d'accueil qualifiées.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-kiweetoTeal-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <span className="text-xl">🐾</span>
                </div>
                <h4 className="font-medium text-kiweetoTeal-800">Ajouter des animaux</h4>
                <p className="text-sm text-kiweetoTeal-600">Créez les fiches de vos protégés</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-kiweetoTeal-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <span className="text-xl">👥</span>
                </div>
                <h4 className="font-medium text-kiweetoTeal-800">Trouver des familles</h4>
                <p className="text-sm text-kiweetoTeal-600">Recherchez des familles d'accueil</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-kiweetoTeal-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <span className="text-xl">📊</span>
                </div>
                <h4 className="font-medium text-kiweetoTeal-800">Suivre vos placements</h4>
                <p className="text-sm text-kiweetoTeal-600">Gérez vos statistiques</p>
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Navigation */}
      <div className="flex justify-between items-center pt-6">
        <Button
          variant="outline"
          icon={ArrowLeft}
          onClick={onPrev}
        >
          Précédent
        </Button>

        <Button
          variant="kiweetoTeal"
          icon={CheckCircle}
          iconPosition="right"
          onClick={onComplete}
          disabled={!data.agreesToCharter}
          size="lg"
          className="px-8"
        >
          Finaliser l'inscription
        </Button>
      </div>
    </div>
  );
}