import React, { useMemo } from 'react';
import { Heart, X, Calendar, MessageCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { mockAnimals, getUserInteractions } from '../../data/mockData';

export function MyInteractions() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const { likedAnimals, passedAnimals } = useMemo(() => {
    if (!user || user.type !== 'family') {
      return { likedAnimals: [], passedAnimals: [] };
    }

    const interactions = getUserInteractions(user.id);
    
    const liked = interactions
      .filter(interaction => interaction.type === 'like')
      .map(interaction => {
        const animal = mockAnimals.find(a => a.id === interaction.animalId);
        return animal ? { animal, timestamp: interaction.timestamp } : null;
      })
      .filter(Boolean)
      .sort((a, b) => b!.timestamp.getTime() - a!.timestamp.getTime());

    const passed = interactions
      .filter(interaction => interaction.type === 'pass')
      .map(interaction => {
        const animal = mockAnimals.find(a => a.id === interaction.animalId);
        return animal ? { animal, timestamp: interaction.timestamp } : null;
      })
      .filter(Boolean)
      .sort((a, b) => b!.timestamp.getTime() - a!.timestamp.getTime());

    return { 
      likedAnimals: liked as Array<{ animal: any; timestamp: Date }>, 
      passedAnimals: passed as Array<{ animal: any; timestamp: Date }>
    };
  }, [user]);

  const handleContactAnimal = (animalId: string, associationId: string) => {
    // Navigate to messages page with animal and association info
    navigate(`/messages?animalId=${animalId}&associationId=${associationId}`);
  };

  if (!user || user.type !== 'family') {
    return null;
  }

  const getAgeText = (age: number) => {
    return age > 1 ? `${age} ans` : `${age} an`;
  };

  const getSizeText = (size: string) => {
    const sizeMap = { petit: 'Petit', moyen: 'Moyen', grand: 'Grand' };
    return sizeMap[size as keyof typeof sizeMap] || size;
  };

  return (
    <div className="space-y-6">
      {/* Animaux likés */}
      <Card>
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 flex items-center space-x-2">
              <Heart className="h-5 w-5 text-error-500" />
              <span>Mes coups de cœur</span>
            </h2>
            <p className="text-sm text-gray-600 mt-1">
              {likedAnimals.length} animal{likedAnimals.length > 1 ? 'x' : ''} que vous avez aimé{likedAnimals.length > 1 ? 's' : ''}
            </p>
          </div>
        </div>

        {likedAnimals.length > 0 ? (
          <div className="space-y-4">
            {likedAnimals.map(({ animal, timestamp }, index) => (
              <div key={index} className="flex items-center space-x-4 p-4 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors">
                <img
                  src={animal.photos[0]}
                  alt={animal.name}
                  className="w-16 h-16 rounded-lg object-cover"
                />
                <div className="flex-1">
                  <h3 className="font-medium text-gray-900">{animal.name}</h3>
                  <p className="text-sm text-gray-600">
                    {animal.breed} • {getAgeText(animal.age)} • {getSizeText(animal.size)}
                  </p>
                  <p className="text-sm text-gray-500">{animal.location}</p>
                  <div className="flex items-center space-x-1 text-xs text-gray-400 mt-1">
                    <Calendar className="h-3 w-3" />
                    <span>Liké le {timestamp.toLocaleDateString('fr-FR')}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge
                    variant={animal.status === 'available' ? 'success' : 'warning'}
                    size="sm"
                  >
                    {animal.status === 'available' ? 'Disponible' : 'En accueil'}
                  </Badge>
                  <Button
                    size="sm"
                    icon={MessageCircle}
                    onClick={() => handleContactAnimal(animal.id, animal.associationId)}
                  >
                    Contacter
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Aucun coup de cœur pour le moment
            </h3>
            <p className="text-gray-600 text-sm">
              Utilisez la fonction "Découvrir" pour swiper sur les animaux et trouver vos coups de cœur !
            </p>
          </div>
        )}
      </Card>

    </div>
  );
}