import React from 'react';
import { Search, Filter, X, MapPin, Navigation, Star } from 'lucide-react';
import { SearchFilters as SearchFiltersType } from '../../types';
import { getBreedsByType } from '../../data/breedData';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';

interface SearchFiltersProps {
  filters: SearchFiltersType;
  onFiltersChange: (filters: SearchFiltersType) => void;
  onClearFilters: () => void;
  onGeolocation: () => void;
  showAdvanced?: boolean;
  onToggleAdvanced?: () => void;
  isGeolocating?: boolean;
}

export function SearchFilters({
  filters,
  onFiltersChange,
  onClearFilters,
  onGeolocation,
  showAdvanced = false,
  onToggleAdvanced,
  isGeolocating = false
}: SearchFiltersProps) {
  const handleFilterChange = (key: keyof SearchFiltersType, value: any) => {
    onFiltersChange({
      ...filters,
      [key]: value
    });
  };

  const hasActiveFilters = Object.values(filters).some(value => 
    value !== undefined && value !== null && value !== ''
  );

  const radiusOptions = [
    { value: 5, label: '5 km' },
    { value: 10, label: '10 km' },
    { value: 20, label: '20 km' },
    { value: 50, label: '50 km' },
    { value: 100, label: '100 km' }
  ];

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`h-4 w-4 ${
          index < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
        }`}
      />
    ));
  };

  return (
    <Card className="space-y-4">
      {/* Recherche principale */}
      <div className="flex space-x-2">
        <div className="flex-1">
          <Input
            placeholder="Rechercher par nom, race..."
            icon={Search}
            value={filters.location || ''}
            onChange={(e) => handleFilterChange('location', e.target.value)}
          />
        </div>
        <Button
          variant="outline"
          icon={Filter}
          onClick={onToggleAdvanced}
          className={showAdvanced ? 'bg-primary-50 border-primary-200' : ''}
        >
          Filtres
        </Button>
        {hasActiveFilters && (
          <Button
            variant="ghost"
            icon={X}
            onClick={onClearFilters}
            className="text-gray-500"
          >
            Effacer
          </Button>
        )}
      </div>

      {/* Recherche géographique */}
      <div className="space-y-3">
        <div className="flex space-x-2">
          <div className="flex-1">
            <Input
              placeholder="Adresse ou ville..."
              icon={MapPin}
              value={filters.location || ''}
              onChange={(e) => handleFilterChange('location', e.target.value)}
            />
          </div>
          <Button
            variant="outline"
            icon={Navigation}
            onClick={onGeolocation}
            loading={isGeolocating}
            className="px-4"
          >
            Autour de moi
          </Button>
        </div>

        <div className="flex items-center space-x-3">
          <label className="text-sm font-medium text-gray-700 whitespace-nowrap">
            Rayon :
          </label>
          <select
            value={filters.radius || ''}
            onChange={(e) => handleFilterChange('radius', e.target.value ? parseInt(e.target.value) : undefined)}
            className="flex-1 rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 text-sm"
          >
            <option value="">Sélectionner</option>
            {radiusOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>

        {filters.centerLatitude && filters.centerLongitude && filters.radius && (
          <div className="text-sm text-gray-600 bg-primary-50 p-2 rounded-lg">
            📍 Recherche dans un rayon de {filters.radius} km
            {filters.location && ` autour de ${filters.location}`}
          </div>
        )}
      </div>

      {/* Filtres avancés */}
      {showAdvanced && (
        <div className="space-y-4 pt-4 border-t border-gray-100">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Type d'animal */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Type d'animal
              </label>
              <select
                value={filters.type || ''}
                onChange={(e) => handleFilterChange('type', e.target.value || undefined)}
                className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
              >
                <option value="">Tous</option>
                <option value="chien">Chien</option>
                <option value="chat">Chat</option>
                <option value="autre">Autre</option>
              </select>
            </div>
            
            {/* Race */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Race
              </label>
              <select
                value={filters.breed || ''}
                onChange={(e) => handleFilterChange('breed', e.target.value || undefined)}
                className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
              >
                <option value="">Toutes les races</option>
                {getBreedsByType(filters.type).map((breed) => (
                  <option key={breed} value={breed}>
                    {breed}
                  </option>
                ))}
              </select>
            </div>

            {/* Sexe */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Sexe
              </label>
              <select
                value={filters.sex || ''}
                onChange={(e) => handleFilterChange('sex', e.target.value || undefined)}
                className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
              >
                <option value="">Indifférent</option>
                <option value="male">Mâle</option>
                <option value="female">Femelle</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Taille */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Taille
              </label>
              <select
                value={filters.size || ''}
                onChange={(e) => handleFilterChange('size', e.target.value || undefined)}
                className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
              >
                <option value="">Toutes</option>
                <option value="petit">Petit</option>
                <option value="moyen">Moyen</option>
                <option value="grand">Grand</option>
              </select>
            </div>
            
            {/* Âge */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Âge (années)
              </label>
              <div className="grid grid-cols-2 gap-2">
                <Input
                  type="number"
                  placeholder="Min"
                  value={filters.age?.min || ''}
                  onChange={(e) => handleFilterChange('age', {
                    ...filters.age,
                    min: e.target.value ? parseInt(e.target.value) : undefined
                  })}
                />
                <Input
                  type="number"
                  placeholder="Max"
                  value={filters.age?.max || ''}
                  onChange={(e) => handleFilterChange('age', {
                    ...filters.age,
                    max: e.target.value ? parseInt(e.target.value) : undefined
                  })}
                />
              </div>
            </div>

            {/* Notation des associations */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Notation des associations
              </label>
              <select
                value={filters.minAssociationRating || ''}
                onChange={(e) => handleFilterChange('minAssociationRating', e.target.value ? parseInt(e.target.value) : undefined)}
                className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
              >
                <option value="">Toutes les associations</option>
                <option value="5">5 étoiles uniquement</option>
                <option value="4">4 étoiles et plus</option>
                <option value="3">3 étoiles et plus</option>
                <option value="2">2 étoiles et plus</option>
              </select>
              
              {/* Affichage visuel des étoiles pour la sélection actuelle */}
              {filters.minAssociationRating && (
                <div className="mt-2 flex items-center space-x-2 text-sm text-gray-600">
                  <span>Minimum :</span>
                  <div className="flex items-center space-x-1">
                    {renderStars(filters.minAssociationRating)}
                  </div>
                  <span>et plus</span>
                </div>
              )}
            </div>
          </div>

          {/* Compatibilité */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Compatibilité
            </label>
            <div className="space-y-2">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={filters.compatibility?.withDogs || false}
                  onChange={(e) => handleFilterChange('compatibility', {
                    ...filters.compatibility,
                    withDogs: e.target.checked
                  })}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">Compatible avec les chiens</span>
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={filters.compatibility?.withCats || false}
                  onChange={(e) => handleFilterChange('compatibility', {
                    ...filters.compatibility,
                    withCats: e.target.checked
                  })}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">Compatible avec les chats</span>
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={filters.compatibility?.withChildren || false}
                  onChange={(e) => handleFilterChange('compatibility', {
                    ...filters.compatibility,
                    withChildren: e.target.checked
                  })}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">Compatible avec les enfants</span>
              </label>
            </div>
          </div>
        </div>
      )}
    </Card>
  );
}