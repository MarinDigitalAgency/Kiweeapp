import React, { useState, useMemo } from 'react';
import { Heart, X, RotateCcw, Zap } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { SwipeCard } from '../components/swipe/SwipeCard';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { mockAnimals, hasUserInteractedWithAnimal, handleLikeInteraction, clearUserInteractions } from '../data/mockData';
import { createNotification } from '../data/mockData';
import { UserInteraction } from '../types';

export function Swipe() {
  const { user } = useAuth();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [matches, setMatches] = useState<string[]>([]);
  const [showMatch, setShowMatch] = useState(false);
  const [lastMatch, setLastMatch] = useState<string>('');
  const [swipeSessionKey, setSwipeSessionKey] = useState(0); // Force re-evaluation of available animals

  // Filter animals that the user hasn't interacted with yet
  const availableAnimals = useMemo(() => {
    if (!user) return [];
    
    console.log('🔄 Recalculating available animals (session key:', swipeSessionKey, ')');
    
    const filtered = mockAnimals.filter(animal => 
      animal.status === 'available' && 
      !hasUserInteractedWithAnimal(user.id, animal.id)
    );
    
    console.log('📊 Available animals:', filtered.length, 'out of', mockAnimals.filter(a => a.status === 'available').length);
    
    return filtered;
  }, [user, swipeSessionKey]); // Add swipeSessionKey as dependency

  const handleSwipe = (animalId: string, direction: 'like' | 'pass') => {
    if (!user) return;

    // Create and save the interaction
    const interaction: UserInteraction = {
      id: Date.now().toString(),
      userId: user.id,
      animalId,
      type: direction,
      timestamp: new Date()
    };

    // Use the enhanced function that auto-creates conversations for likes
    handleLikeInteraction(interaction);

    // Create additional notification for successful match
    if (direction === 'like') {
      setMatches(prev => [...prev, animalId]);
      setLastMatch(animalId);
      setShowMatch(true);
      
      // Create a success notification for the user
      const animal = availableAnimals.find(a => a.id === animalId);
      if (animal && user) {
        createNotification(
          user.id,
          'animal_liked',
          'Animal ajouté aux favoris',
          `${animal.name} a été ajouté à vos favoris et une conversation a été créée avec ${animal.associationName}`,
          {
            animalId: animal.id,
            animalName: animal.name,
            associationId: animal.associationId,
            associationName: animal.associationName,
            url: `/animal/${animal.id}`
          },
          'medium',
          'success'
        );
      }
      
      // Hide match notification after 3 seconds
      setTimeout(() => setShowMatch(false), 3000);
    }

    setCurrentIndex(prev => prev + 1);
  };

  const handleButtonSwipe = (direction: 'like' | 'pass') => {
    if (currentIndex < availableAnimals.length) {
      handleSwipe(availableAnimals[currentIndex].id, direction);
    }
  };

  const handleRestart = () => {
    if (!user) return;
    
    console.log('🔄 Restarting swipe session for user:', user.id);
    
    // Clear all interactions for this user
    clearUserInteractions(user.id);
    
    // Reset local state
    setCurrentIndex(0);
    setMatches([]);
    setShowMatch(false);
    setLastMatch('');
    
    // Force re-evaluation of available animals
    setSwipeSessionKey(prev => prev + 1);
    
    console.log('✅ Swipe session restarted');
  };

  const currentAnimal = availableAnimals[currentIndex];
  const hasMoreCards = currentIndex < availableAnimals.length;

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="text-center max-w-md w-full">
          <div className="py-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              Connexion requise
            </h2>
            <p className="text-gray-600">
              Vous devez être connecté pour utiliser la fonction de découverte.
            </p>
          </div>
        </Card>
      </div>
    );
  }

  if (!hasMoreCards) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="text-center max-w-md w-full">
          <div className="py-8">
            <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="h-8 w-8 text-primary-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              Plus d'animaux à découvrir !
            </h2>
            <p className="text-gray-600 mb-6">
              Vous avez vu tous les animaux disponibles. Vous pouvez recommencer pour revoir tous les animaux ou revenir plus tard pour découvrir de nouveaux compagnons.
            </p>
            <div className="space-y-3">
              <Button 
                className="w-full"
                onClick={handleRestart}
                icon={RotateCcw}
              >
                Recommencer
              </Button>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => window.history.back()}
              >
                Retour au tableau de bord
              </Button>
            </div>
            
            {matches.length > 0 && (
              <div className="mt-6 p-4 bg-secondary-50 rounded-lg">
                <p className="text-sm text-secondary-700">
                  Vous avez liké {matches.length} animal{matches.length > 1 ? 'x' : ''} !
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  Consultez vos messages pour échanger avec les associations
                </p>
              </div>
            )}
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 to-secondary-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Découvrir</h1>
              <p className="text-gray-600">
                {currentIndex + 1} / {availableAnimals.length}
              </p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Zap className="h-5 w-5 text-accent-500" />
                <span className="text-accent-600 font-medium">{matches.length} match{matches.length > 1 ? 's' : ''}</span>
              </div>
              <Button
                variant="outline"
                size="sm"
                icon={RotateCcw}
                onClick={handleRestart}
                className="text-gray-600 hover:text-gray-800"
              >
                Recommencer
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-md mx-auto px-4 py-8">
        {/* Progress Bar */}
        <div className="w-full bg-gray-200 rounded-full h-2 mb-6">
          <div 
            className="bg-primary-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${((currentIndex + 1) / availableAnimals.length) * 100}%` }}
          />
        </div>

        {/* Card Stack */}
        <div className="relative h-[600px] mb-8">
          <SwipeCard
            animal={currentAnimal}
            onSwipe={handleSwipe}
          />
        </div>

        {/* Action Buttons */}
        <div className="flex justify-center space-x-6">
          <Button
            variant="outline"
            size="lg"
            onClick={() => handleButtonSwipe('pass')}
            className="w-16 h-16 rounded-full p-0 border-2 border-gray-300 hover:border-gray-400"
          >
            <X className="h-6 w-6 text-gray-600" />
          </Button>
          
          <Button
            size="lg"
            onClick={() => handleButtonSwipe('like')}
            className="w-16 h-16 rounded-full p-0 bg-error-500 hover:bg-error-600 border-0"
          >
            <Heart className="h-6 w-6 text-white" />
          </Button>
        </div>

        {/* Instructions */}
        <div className="text-center mt-6 text-sm text-gray-500">
          <p>Glissez vers la droite pour aimer, vers la gauche pour passer</p>
          <p className="mt-1 text-xs">Utilisez le bouton "Recommencer" pour revoir tous les animaux</p>
        </div>
      </div>

      {/* Match Notification */}
      {showMatch && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 animate-fade-in">
          <Card className="text-center max-w-sm mx-4">
            <div className="py-8">
              <div className="w-20 h-20 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce-soft">
                <Heart className="h-10 w-10 text-secondary-600 fill-current" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">C'est un match ! ✨</h3>
              <p className="text-gray-600 mb-4">
                Vous avez ajouté {availableAnimals.find(a => a.id === lastMatch)?.name} à vos favoris
              </p>
              <p className="text-sm text-gray-500 mb-4">
                Une conversation a été créée automatiquement avec l'association !
              </p>
              <Button
                onClick={() => setShowMatch(false)}
                className="px-8"
              >
                Continuer
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}