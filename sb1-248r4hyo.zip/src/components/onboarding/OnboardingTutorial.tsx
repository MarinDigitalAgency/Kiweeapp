import React, { useState } from 'react';
import { BookOpen, ArrowRight, ArrowLeft, Search, Heart, MessageCircle, User, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';

interface OnboardingTutorialProps {
  onNext: () => void;
  onPrev: () => void;
}

export function OnboardingTutorial({ onNext, onPrev }: OnboardingTutorialProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const tutorialSlides = [
    {
      title: 'Rechercher des animaux',
      icon: Search,
      content: (
        <div className="space-y-4">
          <div className="bg-gray-100 rounded-lg p-4">
            <img 
              src="https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&cs=tinysrgb&w=400" 
              alt="Interface de recherche"
              className="w-full h-32 object-cover rounded-lg mb-3"
            />
            <p className="text-sm text-gray-600">
              Utilisez les filtres pour trouver des animaux qui correspondent à vos préférences : 
              type, âge, taille, localisation...
            </p>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Filtrez par type d'animal (chien, chat, NAC...)</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Utilisez la géolocalisation pour trouver des animaux près de chez vous</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Consultez les fiches détaillées pour en savoir plus</span>
            </div>
          </div>
        </div>
      )
    },
    {
      title: 'Gérer vos favoris',
      icon: Heart,
      content: (
        <div className="space-y-4">
          <div className="bg-gray-100 rounded-lg p-4">
            <div className="flex items-center justify-center h-32 bg-gradient-to-br from-pink-100 to-red-100 rounded-lg mb-3">
              <Heart className="h-12 w-12 text-red-500 fill-current" />
            </div>
            <p className="text-sm text-gray-600">
              Ajoutez des animaux à vos favoris pour les retrouver facilement et montrer 
              votre intérêt aux associations.
            </p>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Cliquez sur le cœur pour ajouter aux favoris</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Retrouvez tous vos favoris dans votre tableau de bord</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Les associations peuvent voir votre intérêt</span>
            </div>
          </div>
        </div>
      )
    },
    {
      title: 'Messagerie intégrée',
      icon: MessageCircle,
      content: (
        <div className="space-y-4">
          <div className="bg-gray-100 rounded-lg p-4">
            <div className="space-y-2 mb-3">
              <div className="bg-kiweetoTeal-500 text-white p-2 rounded-lg text-sm max-w-xs">
                Bonjour ! Je suis intéressé(e) par Luna 🐕
              </div>
              <div className="bg-white border p-2 rounded-lg text-sm max-w-xs ml-auto">
                Parfait ! Luna est très sociable. Avez-vous de l'expérience ?
              </div>
            </div>
            <p className="text-sm text-gray-600">
              Communiquez directement avec les associations via notre messagerie sécurisée.
            </p>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Conversations automatiquement créées quand vous likez un animal</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Posez toutes vos questions sur l'animal</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Organisez les rencontres et l'accueil</span>
            </div>
          </div>
        </div>
      )
    },
    {
      title: 'Compléter votre profil',
      icon: User,
      content: (
        <div className="space-y-4">
          <div className="bg-gray-100 rounded-lg p-4">
            <div className="flex items-center justify-center h-32 bg-gradient-to-br from-blue-100 to-purple-100 rounded-lg mb-3">
              <User className="h-12 w-12 text-blue-500" />
            </div>
            <p className="text-sm text-gray-600">
              Un profil complet inspire confiance aux associations et améliore vos chances 
              d'être sélectionné(e).
            </p>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Ajoutez vos documents (assurance, pièce d'identité)</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Complétez vos informations personnelles</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></span>
              <span>Obtenez des badges de confiance</span>
            </div>
          </div>
        </div>
      )
    }
  ];

  const nextSlide = () => {
    if (currentSlide < tutorialSlides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const currentSlideData = tutorialSlides[currentSlide];
  const Icon = currentSlideData.icon;

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-kiweetoTeal-100 rounded-full flex items-center justify-center mx-auto">
          <BookOpen className="h-8 w-8 text-kiweetoTeal-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            Guide d'utilisation de Kiweeto
          </h1>
          <p className="text-gray-600">
            Découvrez comment utiliser la plateforme pour trouver et accueillir des animaux.
          </p>
        </div>
      </div>

      {/* Tutorial Slides */}
      <Card className="relative">
        {/* Slide Content */}
        <div className="p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-12 h-12 bg-kiweetoTeal-100 rounded-full flex items-center justify-center">
              <Icon className="h-6 w-6 text-kiweetoTeal-600" />
            </div>
            <h2 className="text-xl font-semibold text-gray-900">
              {currentSlideData.title}
            </h2>
          </div>
          
          {currentSlideData.content}
        </div>

        {/* Slide Navigation */}
        <div className="flex items-center justify-between p-4 border-t border-gray-100">
          <Button
            variant="ghost"
            icon={ChevronLeft}
            onClick={prevSlide}
            disabled={currentSlide === 0}
            className="text-gray-500"
          >
            Précédent
          </Button>

          {/* Slide Indicators */}
          <div className="flex space-x-2">
            {tutorialSlides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentSlide ? 'bg-kiweetoTeal-600' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>

          <Button
            variant="ghost"
            icon={ChevronRight}
            iconPosition="right"
            onClick={nextSlide}
            disabled={currentSlide === tutorialSlides.length - 1}
            className="text-gray-500"
          >
            Suivant
          </Button>
        </div>
      </Card>

      {/* Quick Tips */}
      <Card className="bg-kiweetoTeal-50 border-kiweetoTeal-200">
        <h3 className="text-lg font-semibold text-kiweetoTeal-800 mb-4">
          💡 Conseils pour bien commencer
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-kiweetoTeal-700">
          <div className="space-y-2">
            <div className="flex items-start space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full mt-2 flex-shrink-0"></span>
              <span>Commencez par parcourir les animaux disponibles pour vous familiariser</span>
            </div>
            <div className="flex items-start space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full mt-2 flex-shrink-0"></span>
              <span>N'hésitez pas à poser des questions aux associations</span>
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex items-start space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full mt-2 flex-shrink-0"></span>
              <span>Complétez votre profil pour inspirer confiance</span>
            </div>
            <div className="flex items-start space-x-2">
              <span className="w-2 h-2 bg-kiweetoTeal-500 rounded-full mt-2 flex-shrink-0"></span>
              <span>Prenez votre temps pour choisir le bon animal</span>
            </div>
          </div>
        </div>
      </Card>

      {/* Navigation */}
      <div className="flex justify-between items-center pt-6">
        <Button
          variant="outline"
          icon={ArrowLeft}
          onClick={onPrev}
        >
          Précédent
        </Button>

        <Button
          variant="kiweetoTeal"
          icon={ArrowRight}
          iconPosition="right"
          onClick={onNext}
        >
          Terminer le guide
        </Button>
      </div>
    </div>
  );
}