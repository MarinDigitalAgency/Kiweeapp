import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, UserProfile, FamilyProfile, AssociationProfile, UserDocuments, UserBadges } from '../types';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  register: (userData: Partial<User>, password: string) => Promise<void>;
  logout: () => void;
  loading: boolean;
  updateUserProfile: (profileData: Partial<UserProfile>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Helper function to create default profile
const createDefaultProfile = (userType: 'family' | 'association'): UserProfile => {
  const defaultBadges: UserBadges = {
    isProfileVerified: false,
    isTopFosterFamily: false,
    isExperiencedFA: false,
    isCertifiedAssociation: false,
    isRnaVerified: false,
    isEmailVerified: true, // Default to true for demo
    isPhoneVerified: false,
    hasCompletedProfile: false
  };

  const defaultDocuments: UserDocuments = {};

  const defaultFamilyProfile: FamilyProfile = {
    housingType: 'maison',
    hasGarden: true,
    hasDedicatedRoom: false,
    acceptedAnimalTypes: {
      dogs: true,
      cats: true,
      nac: false,
      reptiles: false,
      labAnimals: false,
      farmAnimals: false
    },
    acceptedAges: {
      baby: true,
      junior: true,
      adult: true,
      senior: false
    },
    acceptedSizes: {
      small: true,
      medium: true,
      large: false
    },
    acceptedSexes: {
      male: true,
      female: true
    },
    canProvideMedicalCare: false,
    compatibility: {
      withHumans: 1,
      withChildren: 0,
      withCats: 0,
      withDogs: 0,
      withOtherAnimals: 0
    },
    hasVehicle: true,
    experienceLevel: 'beginner',
    animalExperienceHistory: 'beginner',
    previousFosterCount: 0,
    specializations: []
  };

  const defaultAssociationProfile: AssociationProfile = {
    rna: '',
    siret: '',
    presidentName: '',
    foundedYear: new Date().getFullYear(),
    fullAddress: '',
    description: '',
    website: '',
    contactEmail: '',
    contactPhone: '',
    acacedCertifications: [],
    otherCertifications: [],
    animalTypes: ['chien', 'chat'],
    animalsCurrentlyInCare: 0,
    averageAnimalsPerYear: 0,
    totalAnimalsHelped: 0,
    services: {
      fostering: true,
      adoption: true,
      veterinaryCare: false,
      behavioralSupport: false,
      emergency: false
    },
    coverageRadius: 50,
    coverageCities: [],
    agreesToCharter: false
  };

  return {
    badges: defaultBadges,
    documents: defaultDocuments,
    completionPercentage: 25, // Base completion for having an account
    isProfileComplete: false,
    ...(userType === 'family' ? { familyProfile: defaultFamilyProfile } : { associationProfile: defaultAssociationProfile })
  };
};

// Helper function to calculate profile completion percentage
const calculateCompletionPercentage = (user: User): number => {
  let completed = 0;
  let total = 0;

  // Basic info (25%)
  total += 25;
  if (user.name && user.email && user.location && user.phone) {
    completed += 25;
  } else if (user.name && user.email) {
    completed += 15;
  }

  if (!user.profile) return completed;

  if (user.type === 'family' && user.profile.familyProfile) {
    const fp = user.profile.familyProfile;
    
    // Housing info (20%)
    total += 20;
    if (fp.housingType) completed += 10;
    if (fp.hasGarden !== undefined && fp.hasDedicatedRoom !== undefined) completed += 10;

    // Animal preferences (25%)
    total += 25;
    const hasAnimalTypes = Object.values(fp.acceptedAnimalTypes).some(v => v);
    const hasAges = Object.values(fp.acceptedAges).some(v => v);
    const hasSizes = Object.values(fp.acceptedSizes).some(v => v);
    if (hasAnimalTypes) completed += 10;
    if (hasAges) completed += 8;
    if (hasSizes) completed += 7;

    // Experience (15%)
    total += 15;
    if (fp.experienceLevel) completed += 10;
    if (fp.previousFosterCount !== undefined) completed += 5;

    // Capabilities (15%)
    total += 15;
    if (fp.canProvideMedicalCare !== undefined) completed += 5;
    if (fp.hasVehicle !== undefined) completed += 5;
    const hasCompatibility = Object.values(fp.compatibility).some(v => v > 0);
    if (hasCompatibility) completed += 5;

  } else if (user.type === 'association' && user.profile.associationProfile) {
    const ap = user.profile.associationProfile;
    
    // Legal info (30%)
    total += 30;
    if (ap.rna) completed += 10;
    if (ap.presidentName) completed += 8;
    if (ap.fullAddress) completed += 7;
    if (ap.foundedYear) completed += 5;

    // Activity and description (25%)
    total += 25;
    if (ap.animalTypes.length > 0) completed += 10;
    if (ap.description) completed += 7;
    if (ap.animalsCurrentlyInCare > 0) completed += 4;
    if (ap.averageAnimalsPerYear > 0) completed += 2;
    if (ap.totalAnimalsHelped > 0) completed += 2;

    // Services (20%)
    total += 20;
    const hasServices = Object.values(ap.services).some(v => v);
    if (hasServices) completed += 20;
    
    // Charter acceptance (25%)
    total += 25;
    if (ap.agreesToCharter) completed += 25;
  }

  return Math.min(100, Math.round((completed / total) * 100));
};

// Helper function to parse dates in user object
const parseUserDates = (userData: any): User => {
  const user = { ...userData };
  
  if (user.createdAt && typeof user.createdAt === 'string') {
    user.createdAt = new Date(user.createdAt);
  }
  
  if (user.profile?.dateOfBirth && typeof user.profile.dateOfBirth === 'string') {
    user.profile.dateOfBirth = new Date(user.profile.dateOfBirth);
  }
  
  // Parse document dates
  if (user.profile?.documents) {
    Object.keys(user.profile.documents).forEach(key => {
      const doc = user.profile.documents[key];
      if (doc && typeof doc === 'object') {
        if (doc.uploadedAt && typeof doc.uploadedAt === 'string') {
          doc.uploadedAt = new Date(doc.uploadedAt);
        }
        if (doc.verifiedAt && typeof doc.verifiedAt === 'string') {
          doc.verifiedAt = new Date(doc.verifiedAt);
        }
      }
    });
  }
  
  return user;
};

// Mock data for demo
const mockUsers: User[] = [
  {
    id: '1',
    email: 'association@example.com',
    name: 'Association Refuge du Cœur',
    type: 'association',
    location: 'Paris, France',
    verified: true,
    createdAt: new Date('2024-01-15'),
  },
  {
    id: '2',
    email: 'famille@example.com',
    name: 'Sophie Martin',
    type: 'family',
    location: 'Lyon, France',
    verified: true,
    createdAt: new Date('2024-02-10'),
  },
];

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading auth state
    const timer = setTimeout(() => {
      const savedUser = localStorage.getItem('kiweeto_user');
      if (savedUser) {
        try {
          const parsedUser = parseUserDates(JSON.parse(savedUser));
          setUser(parsedUser);
        } catch (error) {
          console.error('Error parsing saved user:', error);
          localStorage.removeItem('kiweeto_user');
        }
      }
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const login = async (email: string, password: string) => {
    setLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const foundUser = mockUsers.find(u => u.email === email);
    if (foundUser) {
      // Initialize profile if it doesn't exist
      if (!foundUser.profile) {
        foundUser.profile = createDefaultProfile(foundUser.type);
      }
      
      // Calculate completion percentage
      foundUser.profile.completionPercentage = calculateCompletionPercentage(foundUser);
      
      setUser(foundUser);
      localStorage.setItem('kiweeto_user', JSON.stringify(foundUser));
    } else {
      throw new Error('Utilisateur non trouvé');
    }
    setLoading(false);
  };

  const register = async (userData: Partial<User>, password: string) => {
    setLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newUser: User = {
      id: Date.now().toString(),
      email: userData.email!,
      name: userData.name!,
      type: userData.type!,
      location: userData.location,
      phone: userData.phone,
      verified: false,
      createdAt: new Date(),
      profile: createDefaultProfile(userData.type!)
    };

    // Calculate initial completion percentage
    newUser.profile.completionPercentage = calculateCompletionPercentage(newUser);

    setUser(newUser);
    localStorage.setItem('kiweeto_user', JSON.stringify(newUser));
    setLoading(false);
  };

  const updateUserProfile = (profileData: Partial<UserProfile>) => {
    if (!user) return;

    const updatedUser = {
      ...user,
      profile: {
        ...user.profile,
        ...profileData
      }
    };

    // Recalculate completion percentage
    if (updatedUser.profile) {
      updatedUser.profile.completionPercentage = calculateCompletionPercentage(updatedUser);
      updatedUser.profile.isProfileComplete = updatedUser.profile.completionPercentage >= 90;
    }

    setUser(updatedUser);
    localStorage.setItem('kiweeto_user', JSON.stringify(updatedUser));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('kiweeto_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, loading, updateUserProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}