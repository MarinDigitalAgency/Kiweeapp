import React from 'react';
import { CheckCircle, Clock, Heart, Info } from 'lucide-react';

interface AnimalStatusSelectorProps {
  value: 'available' | 'in_care' | 'adopted';
  onChange: (status: 'available' | 'in_care' | 'adopted') => void;
  className?: string;
}

export function AnimalStatusSelector({ value, onChange, className = '' }: AnimalStatusSelectorProps) {
  const statusOptions = [
    {
      value: 'available' as const,
      label: 'Disponible',
      description: 'L\'animal est disponible pour l\'accueil',
      icon: CheckCircle,
      color: 'text-success-600',
      bgColor: 'bg-success-50',
      borderColor: 'border-success-200'
    },
    {
      value: 'in_care' as const,
      label: 'En famille d\'accueil',
      description: 'L\'animal est actuellement en famille d\'accueil',
      icon: Clock,
      color: 'text-warning-600',
      bgColor: 'bg-warning-50',
      borderColor: 'border-warning-200'
    },
    {
      value: 'adopted' as const,
      label: 'Adopté',
      description: 'L\'animal a été adopté définitivement',
      icon: Heart,
      color: 'text-primary-600',
      bgColor: 'bg-primary-50',
      borderColor: 'border-primary-200'
    }
  ];

  return (
    <div className={className}>
      <label className="block text-sm font-medium text-gray-700 mb-3">
        Statut de l'animal
      </label>
      
      <div className="space-y-3">
        {statusOptions.map((option) => {
          const Icon = option.icon;
          const isSelected = value === option.value;
          
          return (
            <label
              key={option.value}
              className={`relative flex items-start p-4 border-2 rounded-lg cursor-pointer transition-all duration-200 hover:shadow-sm ${
                isSelected
                  ? `${option.bgColor} ${option.borderColor} shadow-sm`
                  : 'bg-white border-gray-200 hover:border-gray-300'
              }`}
            >
              <input
                type="radio"
                name="animalStatus"
                value={option.value}
                checked={isSelected}
                onChange={(e) => onChange(e.target.value as 'available' | 'in_care' | 'adopted')}
                className="sr-only"
              />
              
              <div className={`flex-shrink-0 w-5 h-5 rounded-full border-2 mr-3 mt-0.5 transition-colors ${
                isSelected
                  ? `${option.borderColor.replace('border-', 'border-')} ${option.bgColor}`
                  : 'border-gray-300 bg-white'
              }`}>
                {isSelected && (
                  <div className={`w-full h-full rounded-full flex items-center justify-center`}>
                    <div className={`w-2 h-2 rounded-full ${option.color.replace('text-', 'bg-')}`} />
                  </div>
                )}
              </div>
              
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-1">
                  <Icon className={`h-4 w-4 ${isSelected ? option.color : 'text-gray-400'}`} />
                  <span className={`font-medium ${isSelected ? 'text-gray-900' : 'text-gray-700'}`}>
                    {option.label}
                  </span>
                </div>
                <p className={`text-sm ${isSelected ? 'text-gray-700' : 'text-gray-500'}`}>
                  {option.description}
                </p>
              </div>
            </label>
          );
        })}
      </div>
      
      {/* Help text */}
      <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
        <div className="flex items-start space-x-2">
          <Info className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
          <p className="text-sm text-blue-800">
            <strong>Important :</strong> Le statut permet de gérer la visibilité de l'animal sur la plateforme. 
            Seuls les animaux disponibles apparaissent dans les recherches.
          </p>
        </div>
      </div>
    </div>
  );
}