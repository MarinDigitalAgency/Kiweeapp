import React, { useState } from 'react';
import { Heart, Search, MessageCircle, Calendar, Star } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { AnimalCard } from '../animals/AnimalCard';
import { MyInteractions } from './MyInteractions';
import { mockAnimals, getUserInteractions } from '../../data/mockData';

export function FamilyDashboard() {
  const { user } = useAuth();
  const [favorites] = useState(['1', '3']); // Mock favorites
  
  // Get user interactions for stats
  const userInteractions = user ? getUserInteractions(user.id) : [];
  const likedAnimals = userInteractions.filter(i => i.type === 'like');
  
  const [stats] = useState({
    favoriteAnimals: likedAnimals.length,
    applications: 2,
    messages: 3,
    matches: likedAnimals.length
  });

  const favoriteAnimals = mockAnimals.filter(animal => favorites.includes(animal.id));
  const recommendedAnimals = mockAnimals.slice(0, 3);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-kiweetoTeal-700">
          Bonjour {user?.name} 👋
        </h1>
        <p className="text-gray-600 mt-2">
          Découvrez les animaux qui ont besoin d'une famille d'accueil
        </p>
      </div>

      {/* Quick Actions */}
      <div className="mb-8 flex flex-wrap gap-4">
        <Button as={Link} to="/search" icon={Search} variant="kiweetoTeal">
          Rechercher des animaux
        </Button>
        <Button variant="outline" as={Link} to="/swipe" icon={Heart}>
          Découvrir (Swipe)
        </Button>
        <Button variant="outline" as={Link} to="/messages" icon={MessageCircle}>
          Messages ({stats.messages})
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="text-center">
          <div className="text-2xl font-bold text-error-600">{stats.favoriteAnimals}</div>
          <div className="text-gray-600">Coups de cœur</div>
        </Card>
        <Card className="text-center">
          <div className="text-2xl font-bold text-kiweetoTeal-600">{stats.applications}</div>
          <div className="text-gray-600">Candidatures</div>
        </Card>
        <Card className="text-center">
          <div className="text-2xl font-bold text-kiweetoLightBlue-600">{stats.matches}</div>
          <div className="text-gray-600">Matches</div>
        </Card>
        <Card className="text-center">
          <div className="text-2xl font-bold text-kiweetoOrange-600">{stats.messages}</div>
          <div className="text-gray-600">Messages</div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          {/* Recommandations */}
          <Card>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-xl font-semibold text-gray-900">Animaux recommandés</h2>
                <p className="text-sm text-gray-600">Basé sur vos préférences</p>
              </div>
              <Button size="sm" variant="outline" as={Link} to="/search">
                Voir plus
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {recommendedAnimals.slice(0, 2).map((animal) => (
                <AnimalCard
                  key={animal.id}
                  animal={animal}
                  isFavorited={favorites.includes(animal.id)}
                  onFavorite={(id) => console.log('Toggle favorite:', id)}
                  onMessage={(id) => console.log('Message animal:', id)}
                />
              ))}
            </div>
          </Card>

          {/* Mes interactions */}
          <MyInteractions />
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Messages récents */}
          <Card>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Messages récents</h3>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                  <span className="text-xs font-medium text-primary-600">RC</span>
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">Refuge du Cœur</p>
                  <p className="text-xs text-gray-600">Réponse pour Luna</p>
                  <p className="text-xs text-gray-400">Il y a 1h</p>
                </div>
                <div className="w-2 h-2 bg-kiweetoTeal-500 rounded-full"></div>
              </div>
            </div>
            <Button size="sm" variant="outline" className="w-full mt-4" as={Link} to="/messages">
              Voir tous les messages
            </Button>
          </Card>

          {/* Candidatures en cours */}
          <Card>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Mes candidatures</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <img
                  src={mockAnimals[0].photos[0]}
                  alt={mockAnimals[0].name}
                  className="w-10 h-10 rounded-lg object-cover"
                />
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">{mockAnimals[0].name}</p>
                  <Badge variant="warning" size="sm">
                    En attente
                  </Badge>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <img
                  src={mockAnimals[2].photos[0]}
                  alt={mockAnimals[2].name}
                  className="w-10 h-10 rounded-lg object-cover"
                />
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">{mockAnimals[2].name}</p>
                  <Badge variant="success" size="sm">
                    Acceptée
                  </Badge>
                </div>
              </div>
            </div>
          </Card>

          {/* Conseils du jour */}
          <Card>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">💡 Conseil du jour</h3>
            <p className="text-sm text-gray-600 mb-3">
              Préparez votre domicile avant l'arrivée de votre futur compagnon. 
              Sécurisez les zones dangereuses et préparez un espace dédié.
            </p>
            <Button size="sm" variant="outline" className="w-full">
              Lire l'article complet
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
}