import React from 'react';
import { Heart, Users, Shield, ArrowRight } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';

interface OnboardingWelcomeProps {
  onNext: () => void;
}

export function OnboardingWelcome({ onNext }: OnboardingWelcomeProps) {
  return (
    <div className="max-w-2xl mx-auto text-center space-y-8">
      {/* Hero Section */}
      <div className="space-y-6">
        <div className="w-20 h-20 bg-kiweetoTeal-100 rounded-full flex items-center justify-center mx-auto">
          <Heart className="h-10 w-10 text-kiweetoTeal-600 fill-current" />
        </div>
        
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Bienvenue dans la communauté Kiweeto ! 🎉
          </h1>
          <p className="text-xl text-gray-600 leading-relaxed">
            Merci de rejoindre notre communauté de familles d'accueil. 
            Ensemble, nous offrons une seconde chance aux animaux dans le besoin.
          </p>
        </div>
      </div>

      {/* Mission Statement */}
      <Card className="bg-gradient-to-r from-kiweetoTeal-50 to-kiweetoLightBlue-50 border-kiweetoTeal-200">
        <div className="text-center space-y-4">
          <h2 className="text-xl font-semibold text-kiweetoTeal-800">
            Votre rôle de famille d'accueil
          </h2>
          <p className="text-kiweetoTeal-700 leading-relaxed">
            En tant que famille d'accueil, vous offrez un foyer temporaire sécurisé et aimant 
            aux animaux en attente d'adoption. Votre engagement fait toute la différence dans 
            leur parcours vers une famille définitive.
          </p>
        </div>
      </Card>

      {/* Key Benefits */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="text-center p-6">
          <div className="w-12 h-12 bg-kiweetoTeal-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Heart className="h-6 w-6 text-kiweetoTeal-600" />
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">Impact direct</h3>
          <p className="text-sm text-gray-600">
            Chaque animal accueilli est une vie sauvée et une chance de bonheur
          </p>
        </Card>

        <Card className="text-center p-6">
          <div className="w-12 h-12 bg-kiweetoLightBlue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Users className="h-6 w-6 text-kiweetoLightBlue-600" />
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">Communauté</h3>
          <p className="text-sm text-gray-600">
            Rejoignez une communauté bienveillante de passionnés d'animaux
          </p>
        </Card>

        <Card className="text-center p-6">
          <div className="w-12 h-12 bg-kiweetoOrange-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Shield className="h-6 w-6 text-kiweetoOrange-600" />
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">Accompagnement</h3>
          <p className="text-sm text-gray-600">
            Support complet des associations partenaires à chaque étape
          </p>
        </Card>
      </div>

      {/* Next Steps */}
      <Card className="bg-white border-2 border-kiweetoTeal-200">
        <div className="text-center space-y-4">
          <h2 className="text-lg font-semibold text-gray-900">
            Configurons votre profil ensemble
          </h2>
          <p className="text-gray-600">
            Nous allons vous poser quelques questions pour personnaliser votre expérience 
            et vous mettre en relation avec les animaux qui vous correspondent le mieux.
          </p>
          <p className="text-sm text-gray-500">
            ⏱️ Cela prend environ 5-10 minutes
          </p>
        </div>
      </Card>

      {/* CTA */}
      <div className="pt-4">
        <Button
          onClick={onNext}
          size="lg"
          variant="kiweetoTeal"
          icon={ArrowRight}
          iconPosition="right"
          className="px-8"
        >
          Commencer la configuration
        </Button>
      </div>
    </div>
  );
}