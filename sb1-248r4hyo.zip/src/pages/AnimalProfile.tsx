import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Heart, MessageCircle, MapPin, Calendar, Users, Star, Shield, Stethoscope, Camera, Share2, Flag, FolderHeart as UserHeart, Edit, Save, X, Lock, LogIn, UserPlus, Activity } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Animal } from '../types';
import { mockAnimals, hasUserInteractedWithAnimal, handleLikeInteraction, createNotification } from '../data/mockData';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Input } from '../components/ui/Input';
import { AnimalStatusEditor } from '../components/animals/AnimalStatusEditor';

export function AnimalProfile() {
  const { animalId } = useParams<{ animalId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [animal, setAnimal] = useState<Animal | null>(null);
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);
  const [isLiked, setIsLiked] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isEditingMode, setIsEditingMode] = useState(false);
  const [editedAnimal, setEditedAnimal] = useState<Animal | null>(null);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    if (!animalId) {
      navigate('/search');
      return;
    }

    // Find the animal
    const foundAnimal = mockAnimals.find(a => a.id === animalId);
    if (foundAnimal) {
      const animalCopy = { ...foundAnimal };
      setAnimal(animalCopy);
      setEditedAnimal(animalCopy);
      
      // Check if user has already liked this animal
      if (user) {
        setIsLiked(hasUserInteractedWithAnimal(user.id, animalId));
      }
    }
    
    setLoading(false);
  }, [animalId, user, navigate]);

  const handleLike = () => {
    if (!user || !animal) return;

    const interaction = {
      id: Date.now().toString(),
      userId: user.id,
      animalId: animal.id,
      type: 'like' as const,
      timestamp: new Date()
    };

    handleLikeInteraction(interaction);
    setIsLiked(true);
  };

  const handleContact = () => {
    if (!animal) return;
    navigate(`/messages?animalId=${animal.id}&associationId=${animal.associationId}`);
  };

  const handleFosteringRequest = () => {
    if (!animal) return;
    navigate(`/animal/${animal.id}/request?type=foster`);
  };

  const handleExternalAdoption = () => {
    window.open('https://animaux.fr', '_blank');
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `${animal?.name} - Kiweeto`,
        text: `Découvrez ${animal?.name}, un ${animal?.type} à la recherche d'une famille d'accueil`,
        url: window.location.href
      });
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href);
      // You could show a toast notification here
    }
  };

  const isOwner = user && user.type === 'association' && animal?.associationId === user.id;

  const handleEditToggle = () => {
    setIsEditingMode(!isEditingMode);
    if (!isEditingMode) {
      // Enter edit mode - make a copy of the animal data
      setEditedAnimal({ ...animal! });
    } else {
      // Exit edit mode without saving
      setEditedAnimal(animal);
    }
  };

  const handleSave = () => {
    if (!editedAnimal) return;
    
    // In a real app, this would be an API call
    // For now, we'll just update our local state
    setAnimal(editedAnimal);
    
    // Show success message
    setSuccessMessage('Modifications enregistrées avec succès !');
    setShowSuccessMessage(true);
    setTimeout(() => setShowSuccessMessage(false), 3000);
    
    // Exit edit mode
    setIsEditingMode(false);
  };

  const handleStatusChange = (newStatus: Animal['status']) => {
    if (!animal || !editedAnimal) return;
    
    // Update the edited animal
    const updatedAnimal = { ...editedAnimal, status: newStatus };
    setEditedAnimal(updatedAnimal);
    
    // Also update the displayed animal directly for immediate feedback
    setAnimal(updatedAnimal);
    
    // In a real app, this would be an API call to update the status
    // For demo purposes, we'll just show a success message
    setSuccessMessage(`Statut mis à jour : ${
      newStatus === 'available' ? 'Recherche famille' : 
      newStatus === 'in_care' ? 'En famille d\'accueil' : 
      'A trouvé famille'
    }`);
    setShowSuccessMessage(true);
    setTimeout(() => setShowSuccessMessage(false), 3000);
    
    // Create a notification for the status change
    if (user) {
      createNotification(
        user.id,
        'adoption_request_status',
        'Statut animal mis à jour',
        `Le statut de ${animal.name} a été mis à jour`,
        {
          animalId: animal.id,
          animalName: animal.name,
          url: `/animal/${animal.id}`
        },
        'medium',
        'info'
      );
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary-500 border-t-transparent"></div>
      </div>
    );
  }

  if (!animal) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="text-center max-w-md">
          <div className="py-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Animal non trouvé</h2>
            <p className="text-gray-600 mb-4">
              L'animal que vous recherchez n'existe pas ou n'est plus disponible.
            </p>
            <Button onClick={() => navigate('/search')}>
              Retour à la recherche
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  const displayedAnimal = isEditingMode ? editedAnimal : animal;
  if (!displayedAnimal) return null;

  const getAgeText = (age: number) => {
    return age > 1 ? `${age} ans` : `${age} an`;
  };

  const getSexText = (sex: string) => {
    const sexMap = {
      male: 'Mâle',
      female: 'Femelle'
    };
    return sexMap[sex as keyof typeof sexMap] || sex;
  };

  const getSizeText = (size: string) => {
    const sizeMap = { petit: 'Petit', moyen: 'Moyen', grand: 'Grand' };
    return sizeMap[size as keyof typeof sizeMap] || size;
  };

  const getTypeText = (type: string) => {
    const typeMap = { chien: 'Chien', chat: 'Chat', autre: 'Autre' };
    return typeMap[type as keyof typeof typeMap] || type;
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'available':
        return '🟡 Recherche famille';
      case 'in_care':
        return '🟠 En famille d\'accueil';
      case 'adopted':
        return '🟢 A trouvé famille';
      default:
        return status;
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`h-4 w-4 ${
          index < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
        }`}
      />
    ));
  };

  const canViewSensitiveInfo = isOwner;
  const isAvailableForAdoption = animal.status === 'available';
  const isAuthenticated = !!user;

  // Teasing mode - truncate description for unauthenticated users
  const getTeasedDescription = (description: string) => {
    if (isAuthenticated) return description;
    
    // Truncate to ~100 characters, ending at a space
    const maxLength = 100;
    if (description.length <= maxLength) return description;
    
    const truncated = description.substring(0, maxLength);
    const lastSpaceIndex = truncated.lastIndexOf(' ');
    
    return truncated.substring(0, lastSpaceIndex) + '...';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              icon={ArrowLeft}
              onClick={() => navigate(-1)}
            >
              Retour
            </Button>
            
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                icon={Share2}
                onClick={handleShare}
                size="sm"
              >
                Partager
              </Button>
              <Button
                variant="ghost"
                icon={Flag}
                size="sm"
                className="text-gray-500"
              >
                Signaler
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Association Owner Banner */}
        {isOwner && (
          <div className="mb-6 bg-kiweetoTeal-50 border border-kiweetoTeal-200 rounded-lg p-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center space-x-3">
                <div className="bg-kiweetoTeal-100 p-2 rounded-full">
                  <Lock className="h-5 w-5 text-kiweetoTeal-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-kiweetoTeal-800">
                    Vous consultez cette fiche en tant qu'association
                  </h3>
                  <p className="text-sm text-kiweetoTeal-600">
                    Vous pouvez modifier les informations et le statut de cet animal
                  </p>
                </div>
              </div>
              
              <Button
                variant={isEditingMode ? "outline" : "kiweetoTeal"}
                icon={isEditingMode ? X : Edit}
                onClick={handleEditToggle}
              >
                {isEditingMode ? "Annuler" : "Modifier la fiche"}
              </Button>
            </div>
          </div>
        )}

        {/* Teasing Banner for Unauthenticated Users */}
        {!isAuthenticated && (
          <div className="mb-6 bg-primary-50 border border-primary-200 rounded-lg p-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center space-x-3">
                <div className="bg-primary-100 p-2 rounded-full">
                  <LogIn className="h-5 w-5 text-primary-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-primary-800">
                    Connectez-vous pour voir tous les détails
                  </h3>
                  <p className="text-sm text-primary-600">
                    Créez un compte pour contacter l'association et accueillir {animal.name}
                  </p>
                </div>
              </div>
              
              <div className="flex space-x-2">
                <Button
                  variant="primary"
                  icon={LogIn}
                  onClick={() => navigate('/login')}
                  size="sm"
                >
                  Connexion
                </Button>
                <Button
                  variant="outline"
                  icon={UserPlus}
                  onClick={() => navigate('/register')}
                  size="sm"
                >
                  Inscription
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Success Message */}
        {showSuccessMessage && (
          <div className="fixed top-4 right-4 bg-success-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-slide-up">
            {successMessage}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Photos et informations principales */}
          <div className="lg:col-span-2 space-y-6">
            {/* Galerie photos */}
            <Card padding="none" className="overflow-hidden">
              <div className="relative h-96">
                <img
                  src={animal.photos[currentPhotoIndex]}
                  alt={`${animal.name} - Photo ${currentPhotoIndex + 1}`}
                  className="w-full h-full object-cover"
                />
                
                {/* Navigation photos */}
                {animal.photos.length > 1 && (
                  <>
                    <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                      {animal.photos.map((_, index) => (
                        <button
                          key={index}
                          onClick={() => setCurrentPhotoIndex(index)}
                          className={`w-2 h-2 rounded-full transition-colors ${
                            index === currentPhotoIndex ? 'bg-white' : 'bg-white/50'
                          }`}
                        />
                      ))}
                    </div>
                    
                    {currentPhotoIndex > 0 && (
                      <button
                        onClick={() => setCurrentPhotoIndex(currentPhotoIndex - 1)}
                        className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 text-white p-2 rounded-full hover:bg-black/70 transition-colors"
                      >
                        <ArrowLeft className="h-4 w-4" />
                      </button>
                    )}
                    
                    {currentPhotoIndex < animal.photos.length - 1 && (
                      <button
                        onClick={() => setCurrentPhotoIndex(currentPhotoIndex + 1)}
                        className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 text-white p-2 rounded-full hover:bg-black/70 transition-colors"
                      >
                        <ArrowLeft className="h-4 w-4 rotate-180" />
                      </button>
                    )}
                  </>
                )}

                {/* Badge type */}
                <div className="absolute top-4 left-4">
                  <Badge variant="primary" size="md">
                    {getTypeText(displayedAnimal.type)}
                  </Badge>
                </div>

                {/* Badge statut */}
                <div className="absolute top-4 right-4">
                  <Badge
                    variant={displayedAnimal.status === 'available' ? 'success' : 'warning'}
                    size="md"
                  >
                    {displayedAnimal.status === 'available' ? 'Disponible' : 'En accueil'}
                  </Badge>
                </div>
              </div>

              {/* Miniatures */}
              {animal.photos.length > 1 && (
                <div className="p-4 border-t border-gray-100">
                  <div className="flex space-x-2 overflow-x-auto">
                    {animal.photos.map((photo, index) => (
                      <button
                        key={index}
                        onClick={() => setCurrentPhotoIndex(index)}
                        className={`flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden border-2 transition-colors ${
                          index === currentPhotoIndex ? 'border-primary-500' : 'border-gray-200'
                        }`}
                      >
                        <img
                          src={photo}
                          alt={`${animal.name} - Miniature ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </Card>

            {/* Informations détaillées */}
            <Card>
              <div className="space-y-6">
                {/* En-tête */}
                <div>
                  <div className="flex items-center space-x-3">
                    <h1 className="text-3xl font-bold text-gray-900">{displayedAnimal.name}</h1>
                    {isOwner && (
                      <Badge variant="primary" size="md" className="flex items-center space-x-1">
                        <Lock className="h-3 w-3" />
                        <span>Propriétaire de la fiche</span>
                      </Badge>
                    )}
                  </div>
                  {isEditingMode ? (
                    <div className="mt-2 space-y-3">
                      <Input
                        label="Nom de l'animal"
                        value={editedAnimal?.name || ''}
                        onChange={(e) => setEditedAnimal(prev => prev ? { ...prev, name: e.target.value } : null)}
                        placeholder="Nom de l'animal"
                      />
                      <div className="grid grid-cols-3 gap-3">
                        <Input
                          label="Race"
                          value={editedAnimal?.breed || ''}
                          onChange={(e) => setEditedAnimal(prev => prev ? { ...prev, breed: e.target.value } : null)}
                          placeholder="Race"
                        />
                        <Input
                          label="Âge (années)"
                          type="number"
                          value={editedAnimal?.age || 0}
                          onChange={(e) => setEditedAnimal(prev => prev ? { ...prev, age: parseInt(e.target.value) || 0 } : null)}
                          min="0"
                        />
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Taille
                          </label>
                          <select
                            value={editedAnimal?.size || 'moyen'}
                            onChange={(e) => setEditedAnimal(prev => prev ? { ...prev, size: e.target.value as any } : null)}
                            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                          >
                            <option value="petit">Petit</option>
                            <option value="moyen">Moyen</option>
                            <option value="grand">Grand</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <p className="text-xl text-gray-600">
                      {displayedAnimal.breed} • {getSexText(displayedAnimal.sex)} • {getAgeText(displayedAnimal.age)} • {getSizeText(displayedAnimal.size)}
                    </p>
                  )}
                </div>

                {/* Description */}
                <div>
                  <div className="flex items-center space-x-2 mb-3">
                    <h3 className="text-lg font-semibold text-gray-900">À propos de {displayedAnimal.name}</h3>
                    {isOwner && !isEditingMode && (
                      <button 
                        onClick={handleEditToggle}
                        className="text-gray-400 hover:text-gray-600"
                        title="Modifier la description"
                      >
                        <Edit className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                  
                  {isEditingMode ? (
                    <div>
                      <textarea
                        value={editedAnimal?.description || ''}
                        onChange={(e) => setEditedAnimal(prev => prev ? { ...prev, description: e.target.value } : null)}
                        rows={5}
                        className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                        placeholder="Description de l'animal"
                      />
                      <div className="flex justify-end mt-2">
                        <Button
                          variant="kiweetoTeal"
                          size="sm"
                          icon={Save}
                          onClick={handleSave}
                        >
                          Enregistrer
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <p className="text-gray-700 leading-relaxed">
                        {getTeasedDescription(displayedAnimal.description)}
                      </p>
                      {!isAuthenticated && (
                        <div className="mt-4 p-3 bg-gray-50 border border-gray-200 rounded-lg">
                          <p className="text-sm text-gray-600 flex items-center">
                            <LogIn className="h-4 w-4 mr-2 text-primary-500" />
                            <Link to="/login" className="text-primary-600 hover:underline">Connectez-vous</Link> pour lire la description complète et contacter l'association
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Traits de caractère */}
                {displayedAnimal.characterTraits && (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center space-x-2">
                      <Activity className="h-5 w-5 text-primary-600" />
                      <span>Traits de caractère</span>
                    </h3>
                    
                    <div className="space-y-4">
                      {/* Sociabilité */}
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium text-gray-700">Sociabilité</span>
                          <span className="text-sm text-gray-600">{displayedAnimal.characterTraits.sociability}/5</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-primary-600 h-2 rounded-full"
                            style={{ width: `${(displayedAnimal.characterTraits.sociability / 5) * 100}%` }}
                          />
                        </div>
                      </div>
                      
                      {/* Obéissance */}
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium text-gray-700">Obéissance</span>
                          <span className="text-sm text-gray-600">{displayedAnimal.characterTraits.obedience}/5</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-primary-600 h-2 rounded-full"
                            style={{ width: `${(displayedAnimal.characterTraits.obedience / 5) * 100}%` }}
                          />
                        </div>
                      </div>
                      
                      {/* Câlins */}
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium text-gray-700">Câlins</span>
                          <span className="text-sm text-gray-600">{displayedAnimal.characterTraits.cuddliness}/5</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-primary-600 h-2 rounded-full"
                            style={{ width: `${(displayedAnimal.characterTraits.cuddliness / 5) * 100}%` }}
                          />
                        </div>
                      </div>
                      
                      {/* Indépendance */}
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium text-gray-700">Indépendance</span>
                          <span className="text-sm text-gray-600">{displayedAnimal.characterTraits.independence}/5</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-primary-600 h-2 rounded-full"
                            style={{ width: `${(displayedAnimal.characterTraits.independence / 5) * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Santé */}
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center space-x-2">
                    <Stethoscope className="h-5 w-5 text-primary-600" />
                    <span>Santé</span>
                  </h3>
                  
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${displayedAnimal.health.vaccinated ? 'bg-success-500' : 'bg-gray-300'}`} />
                      <span className="text-sm text-gray-700">
                        {displayedAnimal.health.vaccinated ? 'Vacciné' : 'Non vacciné'}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${displayedAnimal.health.sterilized ? 'bg-success-500' : 'bg-gray-300'}`} />
                      <span className="text-sm text-gray-700">
                        {displayedAnimal.health.sterilized ? 'Stérilisé' : 'Non stérilisé'}
                      </span>
                    </div>
                  </div>

                  {displayedAnimal.health.treatments && displayedAnimal.health.treatments.length > 0 && (
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">Traitements en cours :</h4>
                      <ul className="list-disc list-inside space-y-1">
                        {displayedAnimal.health.treatments.map((treatment, index) => (
                          <li key={index} className="text-sm text-gray-700">{treatment}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>

                {/* Compatibilité */}
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center space-x-2">
                    <Users className="h-5 w-5 text-primary-600" />
                    <span>Compatibilité</span>
                  </h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${displayedAnimal.compatibility.withDogs ? 'bg-success-500' : 'bg-gray-300'}`} />
                      <span className="text-sm text-gray-700">Avec les chiens</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${displayedAnimal.compatibility.withCats ? 'bg-success-500' : 'bg-gray-300'}`} />
                      <span className="text-sm text-gray-700">Avec les chats</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${displayedAnimal.compatibility.withChildren ? 'bg-success-500' : 'bg-gray-300'}`} />
                      <span className="text-sm text-gray-700">Avec les enfants</span>
                    </div>
                  </div>
                </div>

                {/* Status Editor (for association owners) */}
                {isOwner && (
                  <div className="border-t border-gray-200 pt-6">
                    <AnimalStatusEditor
                      value={displayedAnimal.status}
                      onChange={handleStatusChange}
                      isEditable={true}
                    />
                  </div>
                )}

                {/* Informations sensibles (uniquement pour l'association propriétaire) */}
                {canViewSensitiveInfo && displayedAnimal.sensitiveInfo && (
                  <div className="border-t border-gray-200 pt-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center space-x-2">
                      <Shield className="h-5 w-5 text-warning-600" />
                      <span>Informations confidentielles</span>
                      <Badge variant="warning" size="sm">Privé</Badge>
                    </h3>
                    
                    <div className="bg-warning-50 border border-warning-200 rounded-lg p-4 space-y-3">
                      {displayedAnimal.sensitiveInfo.icad && (
                        <div>
                          <span className="font-medium text-gray-900">ICAD :</span>
                          <span className="ml-2 text-gray-700">{displayedAnimal.sensitiveInfo.icad}</span>
                        </div>
                      )}
                      {displayedAnimal.sensitiveInfo.veterinaryClinic && (
                        <div>
                          <span className="font-medium text-gray-900">Vétérinaire :</span>
                          <span className="ml-2 text-gray-700">{displayedAnimal.sensitiveInfo.veterinaryClinic}</span>
                        </div>
                      )}
                      {displayedAnimal.sensitiveInfo.veterinaryContact && (
                        <div>
                          <span className="font-medium text-gray-900">Contact vétérinaire :</span>
                          <span className="ml-2 text-gray-700">{displayedAnimal.sensitiveInfo.veterinaryContact}</span>
                        </div>
                      )}
                      {displayedAnimal.sensitiveInfo.medicalHistory && (
                        <div>
                          <span className="font-medium text-gray-900">Historique médical :</span>
                          <p className="mt-1 text-gray-700">{displayedAnimal.sensitiveInfo.medicalHistory}</p>
                        </div>
                      )}
                      {displayedAnimal.sensitiveInfo.behavioralNotes && (
                        <div>
                          <span className="font-medium text-gray-900">Notes comportementales :</span>
                          <p className="mt-1 text-gray-700">{displayedAnimal.sensitiveInfo.behavioralNotes}</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Actions for Authenticated Families */}
            {user && user.type === 'family' && isAvailableForAdoption && !isOwner && (
              <Card>
                <div className="space-y-4">
                  <Button
                    onClick={handleFosteringRequest}
                    icon={UserHeart}
                    variant="kiweetoTeal"
                    className="w-full"
                    size="lg"
                  >
                    Je veux accueillir {animal.name}
                  </Button>
                  
                  <Button
                    onClick={handleContact}
                    variant="outline"
                    icon={MessageCircle}
                    className="w-full"
                    size="lg"
                  >
                    Contacter
                  </Button>
                  
                  <Button
                    onClick={handleExternalAdoption}
                    variant="outline"
                    icon={Heart}
                    className="w-full"
                    size="lg"
                  >
                    Je souhaite adopter
                  </Button>
                  
                  {!isLiked && (
                    <Button
                      onClick={handleLike}
                      variant="outline"
                      icon={Heart}
                      className="w-full"
                      size="lg"
                    >
                      Ajouter aux favoris
                    </Button>
                  )}
                  
                  {isLiked && (
                    <div className="flex items-center justify-center space-x-2 text-success-600 py-3">
                      <Heart className="h-5 w-5 fill-current" />
                      <span className="font-medium">Ajouté à vos favoris</span>
                    </div>
                  )}
                </div>
              </Card>
            )}
            
            {/* Actions for Unauthenticated Users (Teasing Mode) */}
            {!isAuthenticated && isAvailableForAdoption && (
              <Card>
                <div className="space-y-4">
                  <Button
                    onClick={() => navigate('/login')}
                    icon={LogIn}
                    variant="kiweetoTeal"
                    className="w-full"
                    size="lg"
                  >
                    Se connecter pour accueillir
                  </Button>
                  
                  <Button
                    onClick={() => navigate('/register')}
                    variant="outline"
                    icon={UserPlus}
                    className="w-full"
                    size="lg"
                  >
                    Créer un compte
                  </Button>
                  
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-600 mb-2">
                      <strong>Pourquoi créer un compte ?</strong>
                    </p>
                    <ul className="text-sm text-gray-600 space-y-1">
                      <li className="flex items-start">
                        <span className="text-primary-500 mr-2">•</span>
                        Contacter l'association
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary-500 mr-2">•</span>
                        Faire une demande d'accueil
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary-500 mr-2">•</span>
                        Ajouter aux favoris
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary-500 mr-2">•</span>
                        Voir toutes les informations
                      </li>
                    </ul>
                  </div>
                </div>
              </Card>
            )}
            
            {/* Actions for Association Owners */}
            {isOwner && (
              <Card>
                <div className="space-y-4">
                  {isEditingMode ? (
                    <Button
                      onClick={handleSave}
                      icon={Save}
                      variant="kiweetoTeal"
                      className="w-full"
                      size="lg"
                    >
                      Enregistrer les modifications
                    </Button>
                  ) : (
                    <Button
                      onClick={handleEditToggle}
                      icon={Edit}
                      variant="kiweetoTeal"
                      className="w-full"
                      size="lg"
                    >
                      Modifier la fiche
                    </Button>
                  )}
                  
                  <Button
                    as={Link}
                    to={`/animals/${displayedAnimal.id}/edit`}
                    variant="outline"
                    className="w-full"
                    size="lg"
                  >
                    Édition complète
                  </Button>
                </div>
              </Card>
            )}

            {/* Informations de localisation */}
            <Card>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Localisation</h3>
              {isEditingMode && isOwner ? (
                <div className="space-y-3">
                  <Input
                    label="Localisation"
                    icon={MapPin}
                    value={editedAnimal?.location || ''}
                    onChange={(e) => setEditedAnimal(prev => prev ? { ...prev, location: e.target.value } : null)}
                    placeholder="Ville, région..."
                  />
                  <div className="flex justify-end mt-2">
                    <Button
                      variant="kiweetoTeal"
                      size="sm"
                      icon={Save}
                      onClick={handleSave}
                    >
                      Enregistrer
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-5 w-5 text-gray-400" />
                    <span className="text-gray-700">{displayedAnimal.location}</span>
                    {isOwner && (
                      <button 
                        onClick={handleEditToggle}
                        className="text-gray-400 hover:text-gray-600"
                        title="Modifier la localisation"
                      >
                        <Edit className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-5 w-5 text-gray-400" />
                    <span className="text-gray-700">
                      Disponible depuis le {displayedAnimal.availableFrom.toLocaleDateString('fr-FR')}
                    </span>
                  </div>
                </div>
              )}
            </Card>

            {/* Association */}
            <Card>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Association</h3>
              <div className="space-y-3">
                <div>
                  <Link
                    to={`/association/${displayedAnimal.associationId}`}
                    className="font-medium text-primary-600 hover:text-primary-700 transition-colors"
                  >
                    {displayedAnimal.associationName}
                  </Link>
                </div>
                
                {displayedAnimal.associationRating && (
                  <div className="flex items-center space-x-2">
                    <div className="flex items-center">
                      {renderStars(displayedAnimal.associationRating)}
                    </div>
                    <span className="text-sm text-gray-600">
                      ({displayedAnimal.associationRating}/5)
                    </span>
                  </div>
                )}
                
                <p className="text-sm text-gray-600">
                  Membre depuis {displayedAnimal.createdAt.getFullYear()}
                </p>
              </div>
            </Card>

            {/* Conseils */}
            <Card>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">💡 Conseils</h3>
              <div className="space-y-3 text-sm text-gray-600">
                <p>• Préparez votre domicile avant l'arrivée de l'animal</p>
                <p>• Prévoyez une période d'adaptation</p>
                <p>• Gardez le contact avec l'association</p>
                <p>• Respectez les besoins spécifiques de l'animal</p>
              </div>
            </Card>
          </div>
        </div>
      </div>
      
      {/* Mobile sticky footer for editing */}
      {isOwner && !isEditingMode && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 md:hidden">
          <Button
            onClick={handleEditToggle}
            icon={Edit}
            variant="kiweetoTeal"
            className="w-full"
          >
            Modifier cette fiche
          </Button>
        </div>
      )}
      
      {/* Mobile sticky footer for unauthenticated users */}
      {!isAuthenticated && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 md:hidden">
          <Button
            onClick={() => navigate('/login')}
            icon={LogIn}
            variant="kiweetoTeal"
            className="w-full"
          >
            Se connecter pour accueillir {animal.name}
          </Button>
        </div>
      )}
    </div>
  );
}