import React, { useState, useEffect } from 'react';
import { Upload, FileText, Check, X, Eye, Trash2 } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { DocumentInfo } from '../../types';

export function DocumentsSection() {
  const { user, updateUserProfile } = useAuth();
  const [uploadingDocument, setUploadingDocument] = useState<string | null>(null);
  const [documents, setDocuments] = useState<Record<string, DocumentInfo>>({});

  useEffect(() => {
    if (user?.profile?.documents) {
      setDocuments(user.profile.documents);
    }
  }, [user]);

  const handleFileUpload = async (documentType: string, file: File) => {
    setUploadingDocument(documentType);
    
    // Simulate upload
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const newDocument: DocumentInfo = {
      id: Date.now().toString(),
      name: file.name,
      url: URL.createObjectURL(file),
      type: file.type,
      size: file.size,
      uploadedAt: new Date(),
      verified: false
    };

    const updatedDocuments = {
      ...documents,
      [documentType]: newDocument
    };

    setDocuments(updatedDocuments);
    
    // Update user profile
    updateUserProfile({
      documents: updatedDocuments
    });

    setUploadingDocument(null);
  };

  const handleDeleteDocument = (documentType: string) => {
    const updatedDocuments = { ...documents };
    delete updatedDocuments[documentType];
    
    setDocuments(updatedDocuments);
    
    // Update user profile
    updateUserProfile({
      documents: updatedDocuments
    });
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getDocumentRequirements = () => {
    if (user?.type === 'family') {
      return [
        {
          key: 'identityDocument',
          label: 'Pièce d\'identité',
          description: 'Carte d\'identité ou passeport en cours de validité',
          required: true
        },
        {
          key: 'rcInsurance',
          label: 'Assurance responsabilité civile',
          description: 'Attestation d\'assurance RC couvrant les animaux',
          required: true
        },
        {
          key: 'housingProof',
          label: 'Justificatif de domicile',
          description: 'Facture récente ou titre de propriété',
          required: false
        }
      ];
    } else {
      return [
        {
          key: 'statutes',
          label: 'Statuts de l\'association',
          description: 'Statuts déposés en préfecture',
          required: true
        },
        {
          key: 'rnaDocument',
          label: 'Récépissé RNA',
          description: 'Récépissé de déclaration en préfecture',
          required: true
        },
        {
          key: 'insuranceDocument',
          label: 'Assurance association',
          description: 'Attestation d\'assurance de l\'association',
          required: true
        },
        {
          key: 'acacedCertificates',
          label: 'Certificats ACACED',
          description: 'Certificats de capacité pour animaux domestiques',
          required: false
        }
      ];
    }
  };

  const DocumentUpload = ({ documentType, label, description, required }: any) => {
    const document = documents[documentType];
    const isUploading = uploadingDocument === documentType;

    return (
      <Card className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h4 className="font-medium text-gray-900 flex items-center space-x-2">
              <span>{label}</span>
              {required && <span className="text-error-500">*</span>}
            </h4>
            <p className="text-sm text-gray-600 mt-1">{description}</p>
          </div>
          
          {document && (
            <div className="flex items-center space-x-2">
              {document.verified ? (
                <Badge variant="success" className="flex items-center space-x-1">
                  <Check className="h-3 w-3" />
                  <span>Vérifié</span>
                </Badge>
              ) : (
                <Badge variant="warning" className="flex items-center space-x-1">
                  <X className="h-3 w-3" />
                  <span>En attente</span>
                </Badge>
              )}
            </div>
          )}
        </div>

        {document ? (
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <FileText className="h-8 w-8 text-gray-400" />
              <div>
                <p className="text-sm font-medium text-gray-900">{document.name}</p>
                <p className="text-xs text-gray-500">
                  {formatFileSize(document.size)} • Uploadé le {document.uploadedAt.toLocaleDateString('fr-FR')}
                </p>
                {document.verified && document.verifiedAt && (
                  <p className="text-xs text-success-600">
                    Vérifié le {document.verifiedAt.toLocaleDateString('fr-FR')}
                  </p>
                )}
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="sm" icon={Eye}>
                <span className="sr-only">Voir</span>
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                icon={Trash2}
                onClick={() => handleDeleteDocument(documentType)}
                className="text-error-600 hover:text-error-700"
              >
                <span className="sr-only">Supprimer</span>
              </Button>
            </div>
          </div>
        ) : (
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-gray-400 transition-colors">
            <input
              type="file"
              id={`upload-${documentType}`}
              className="hidden"
              accept=".pdf,.jpg,.jpeg,.png"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  handleFileUpload(documentType, file);
                }
              }}
              disabled={isUploading}
            />
            
            <label
              htmlFor={`upload-${documentType}`}
              className="cursor-pointer flex flex-col items-center space-y-2"
            >
              {isUploading ? (
                <div className="animate-spin rounded-full h-8 w-8 border-2 border-primary-600 border-t-transparent" />
              ) : (
                <Upload className="h-8 w-8 text-gray-400" />
              )}
              
              <div>
                <p className="text-sm font-medium text-gray-900">
                  {isUploading ? 'Upload en cours...' : 'Cliquez pour uploader'}
                </p>
                <p className="text-xs text-gray-500">
                  PDF, JPG, PNG jusqu'à 10MB
                </p>
              </div>
            </label>
          </div>
        )}
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Documents requis</h3>
        <p className="text-gray-600 mb-6">
          Uploadez vos documents pour vérifier votre profil et gagner la confiance des autres utilisateurs.
        </p>

        <div className="space-y-4">
          {getDocumentRequirements().map((req) => (
            <DocumentUpload
              key={req.key}
              documentType={req.key}
              label={req.label}
              description={req.description}
              required={req.required}
            />
          ))}
        </div>
      </Card>

      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Informations importantes</h3>
        <div className="space-y-3 text-sm text-gray-600">
          <p>• Tous les documents sont vérifiés manuellement par notre équipe</p>
          <p>• La vérification prend généralement 24-48h ouvrées</p>
          <p>• Vos documents sont stockés de manière sécurisée et ne sont jamais partagés</p>
          <p>• Vous pouvez supprimer vos documents à tout moment</p>
        </div>
      </Card>
    </div>
  );
}