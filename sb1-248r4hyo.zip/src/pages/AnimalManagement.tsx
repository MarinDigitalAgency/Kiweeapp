import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, PawPrint } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { AnimalForm } from '../components/animals/AnimalForm';
import { Button } from '../components/ui/Button';
import { Animal } from '../types';
import { mockAnimals } from '../data/mockData';

export function AnimalManagement() {
  const { animalId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [animal, setAnimal] = useState<Animal | undefined>();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const isEditing = Boolean(animalId);

  useEffect(() => {
    if (isEditing && animalId) {
      // Simuler le chargement des données de l'animal
      const foundAnimal = mockAnimals.find(a => a.id === animalId);
      if (foundAnimal && foundAnimal.associationId === user?.id) {
        setAnimal(foundAnimal);
      } else {
        setError('Animal non trouvé ou vous n\'avez pas les droits pour le modifier');
      }
    }
  }, [animalId, isEditing, user?.id]);

  const handleSubmit = async (animalData: Partial<Animal>) => {
    if (!user) return;

    setIsLoading(true);
    setError('');

    try {
      // Simuler l'appel API
      await new Promise(resolve => setTimeout(resolve, 1000));

      if (isEditing && animal) {
        // Mise à jour
        const updatedAnimal: Animal = {
          ...animal,
          ...animalData,
          associationId: user.id,
          associationName: user.name,
          associationRating: 5, // Mock rating
          createdAt: animal.createdAt
        };

        // En production, vous feriez un appel API ici
        console.log('Animal mis à jour:', updatedAnimal);
        
        // Rediriger vers le tableau de bord
        navigate('/dashboard', { 
          state: { 
            message: `La fiche de ${animalData.name} a été mise à jour avec succès !`,
            type: 'success'
          }
        });
      } else {
        // Création
        const newAnimal: Animal = {
          id: Date.now().toString(),
          ...animalData,
          associationId: user.id,
          associationName: user.name,
          associationRating: 5, // Mock rating
          createdAt: new Date(),
          status: 'available'
        } as Animal;

        // En production, vous feriez un appel API ici
        console.log('Nouvel animal créé:', newAnimal);
        
        // Rediriger vers le tableau de bord
        navigate('/dashboard', { 
          state: { 
            message: `La fiche de ${animalData.name} a été créée avec succès !`,
            type: 'success'
          }
        });
      }
    } catch (err) {
      setError('Une erreur est survenue lors de l\'enregistrement');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    navigate('/dashboard');
  };

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-error-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <PawPrint className="h-8 w-8 text-error-600" />
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Erreur</h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <Button onClick={() => navigate('/dashboard')}>
            Retour au tableau de bord
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            icon={ArrowLeft}
            onClick={handleCancel}
            className="mb-4"
          >
            Retour au tableau de bord
          </Button>
          
          <div className="flex items-center space-x-3">
            <div className="bg-primary-100 p-3 rounded-lg">
              <PawPrint className="h-6 w-6 text-primary-600" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                {isEditing ? `Modifier ${animal?.name}` : 'Ajouter un animal'}
              </h1>
              <p className="text-gray-600">
                {isEditing 
                  ? 'Mettez à jour les informations de l\'animal'
                  : 'Créez une nouvelle fiche pour un animal à placer'
                }
              </p>
            </div>
          </div>
        </div>

        {/* Formulaire */}
        <AnimalForm
          animal={animal}
          onSubmit={handleSubmit}
          onCancel={handleCancel}
          isLoading={isLoading}
        />
      </div>
    </div>
  );
}