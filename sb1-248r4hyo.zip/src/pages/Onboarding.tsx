import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowRight, CheckCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { FamilyProfile } from '../types';

// Import onboarding step components
import { OnboardingWelcome } from '../components/onboarding/OnboardingWelcome';
import { OnboardingAnimalPreferences } from '../components/onboarding/OnboardingAnimalPreferences';
import { OnboardingHousing } from '../components/onboarding/OnboardingHousing';
import { OnboardingExperience } from '../components/onboarding/OnboardingExperience';
import { OnboardingAvailabilityLocation } from '../components/onboarding/OnboardingAvailabilityLocation';
import { OnboardingCharterConsent } from '../components/onboarding/OnboardingCharterConsent';
import { OnboardingTutorial } from '../components/onboarding/OnboardingTutorial';
import { OnboardingSummary } from '../components/onboarding/OnboardingSummary';

const TOTAL_STEPS = 8;

const stepTitles = [
  'Bienvenue',
  'Préférences animaux',
  'Logement',
  'Expérience',
  'Disponibilités',
  'Charte d\'accueil',
  'Guide d\'utilisation',
  'Récapitulatif'
];

export function Onboarding() {
  const { user, updateUserProfile } = useAuth();
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [onboardingData, setOnboardingData] = useState<Partial<FamilyProfile>>({
    // Initialize with default values
    housingType: 'house_with_garden',
    hasGarden: true,
    hasDedicatedRoom: false,
    acceptedAnimalTypes: {
      dogs: false,
      cats: false,
      nac: false,
      reptiles: false,
      labAnimals: false,
      farmAnimals: false
    },
    acceptedAges: {
      baby: false,
      junior: false,
      adult: false,
      senior: false
    },
    acceptedSizes: {
      small: false,
      medium: false,
      large: false
    },
    acceptedSexes: {
      male: true,
      female: true
    },
    canProvideMedicalCare: false,
    compatibility: {
      withHumans: true,
      withChildren: false,
      withCats: false,
      withDogs: false,
      withOtherAnimals: false
    },
    hasVehicle: false,
    experienceLevel: 'beginner',
    animalExperienceHistory: 'beginner',
    previousFosterCount: 0,
    specializations: [],
    fosteringAvailability: {
      duration: 'medium',
      frequency: 'regular',
      maxAnimalsAtOnce: 1
    },
    agreesToCharter: false
  });

  // Redirect if user is not a family or already completed onboarding
  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    if (user.type !== 'family') {
      navigate('/dashboard');
      return;
    }

    if (user.profile?.onboardingCompleted) {
      navigate('/dashboard');
      return;
    }
  }, [user, navigate]);

  const handleUpdateData = (updates: Partial<FamilyProfile>) => {
    setOnboardingData(prev => ({ ...prev, ...updates }));
  };

  const nextStep = () => {
    if (currentStep < TOTAL_STEPS) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const skipStep = () => {
    nextStep();
  };

  const goToStep = (step: number) => {
    setCurrentStep(step);
  };

  const handleComplete = async () => {
    if (!user) return;

    try {
      // Update user profile with onboarding data
      updateUserProfile({
        familyProfile: {
          ...user.profile?.familyProfile,
          ...onboardingData,
          charterAcceptedAt: onboardingData.agreesToCharter ? new Date() : undefined
        },
        onboardingCompleted: true
      });

      // Navigate to dashboard with success message
      navigate('/dashboard', {
        state: {
          message: 'Félicitations ! Votre profil est maintenant configuré. Vous pouvez commencer à rechercher des animaux à accueillir.',
          type: 'success'
        }
      });
    } catch (error) {
      console.error('Error completing onboarding:', error);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return <OnboardingWelcome onNext={nextStep} />;
      case 2:
        return (
          <OnboardingAnimalPreferences
            data={onboardingData}
            onUpdate={handleUpdateData}
            onNext={nextStep}
            onPrev={prevStep}
            onSkip={skipStep}
          />
        );
      case 3:
        return (
          <OnboardingHousing
            data={onboardingData}
            onUpdate={handleUpdateData}
            onNext={nextStep}
            onPrev={prevStep}
            onSkip={skipStep}
          />
        );
      case 4:
        return (
          <OnboardingExperience
            data={onboardingData}
            onUpdate={handleUpdateData}
            onNext={nextStep}
            onPrev={prevStep}
            onSkip={skipStep}
          />
        );
      case 5:
        return (
          <OnboardingAvailabilityLocation
            data={onboardingData}
            onUpdate={handleUpdateData}
            onNext={nextStep}
            onPrev={prevStep}
            onSkip={skipStep}
            userLocation={user?.location}
          />
        );
      case 6:
        return (
          <OnboardingCharterConsent
            data={onboardingData}
            onUpdate={handleUpdateData}
            onNext={nextStep}
            onPrev={prevStep}
          />
        );
      case 7:
        return (
          <OnboardingTutorial
            onNext={nextStep}
            onPrev={prevStep}
          />
        );
      case 8:
        return (
          <OnboardingSummary
            data={onboardingData}
            onComplete={handleComplete}
            onPrev={prevStep}
            onGoToStep={goToStep}
          />
        );
      default:
        return null;
    }
  };

  if (!user || user.type !== 'family') {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-kiweetoTeal-50 to-kiweetoLightBlue-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                icon={ArrowLeft}
                onClick={() => navigate('/dashboard')}
                className="text-gray-600"
              >
                Quitter
              </Button>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Configuration de votre profil</h1>
                <p className="text-sm text-gray-600">
                  Étape {currentStep} sur {TOTAL_STEPS} : {stepTitles[currentStep - 1]}
                </p>
              </div>
            </div>
            <div className="text-sm text-gray-500">
              {Math.round((currentStep / TOTAL_STEPS) * 100)}% complété
            </div>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-4xl mx-auto px-4">
          <div className="w-full bg-gray-200 h-2">
            <div
              className="bg-kiweetoTeal-600 h-2 transition-all duration-500 ease-out"
              style={{ width: `${(currentStep / TOTAL_STEPS) * 100}%` }}
            />
          </div>
        </div>
      </div>

      {/* Step Navigation */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-4xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between text-xs">
            {stepTitles.map((title, index) => {
              const stepNumber = index + 1;
              const isCompleted = stepNumber < currentStep;
              const isCurrent = stepNumber === currentStep;
              
              return (
                <div
                  key={stepNumber}
                  className={`flex items-center space-x-1 ${
                    stepNumber <= currentStep ? 'text-kiweetoTeal-600' : 'text-gray-400'
                  }`}
                >
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium ${
                      isCompleted
                        ? 'bg-kiweetoTeal-600 text-white'
                        : isCurrent
                        ? 'bg-kiweetoTeal-100 text-kiweetoTeal-600 border-2 border-kiweetoTeal-600'
                        : 'bg-gray-200 text-gray-500'
                    }`}
                  >
                    {isCompleted ? (
                      <CheckCircle className="h-4 w-4" />
                    ) : (
                      stepNumber
                    )}
                  </div>
                  <span className="hidden sm:block font-medium">{title}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        {renderStep()}
      </div>
    </div>
  );
}