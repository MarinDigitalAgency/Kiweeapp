import React, { useState, useMemo } from 'react';
import { Grid, List, Map as MapIcon, Heart, MessageCircle } from 'lucide-react';
import { Animal, SearchFilters as SearchFiltersType, ViewMode } from '../types';
import { mockAnimals } from '../data/mockData';
import { SearchFilters } from '../components/search/SearchFilters';
import { AnimalCard } from '../components/animals/AnimalCard';
import { MapView } from '../components/map/MapView';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { calculateDistance, getCurrentPosition, geocodeAddress } from '../utils/geolocation';

export function Search() {
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [filters, setFilters] = useState<SearchFiltersType>({});
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [selectedAnimal, setSelectedAnimal] = useState<Animal | null>(null);
  const [favorites, setFavorites] = useState<string[]>(['1', '3']); // Mock favorites
  const [isGeolocating, setIsGeolocating] = useState(false);

  // Filtrer les animaux selon les critères
  const filteredAnimals = useMemo(() => {
    console.log('🔍 Starting animal filtering...');
    console.log('📊 Total animals available:', mockAnimals.length);
    console.log('🎛️ Current filters:', filters);
    
    const filtered = mockAnimals.filter(animal => {
      // Filtre par type
      if (filters.type && animal.type !== filters.type) {
        console.log(`❌ Animal ${animal.name} filtered out by type: ${animal.type} !== ${filters.type}`);
        return false;
      }
      
      // Filtre par race
      if (filters.breed && animal.breed) {
        const normalizedBreed = animal.breed.toLowerCase();
        const normalizedFilter = filters.breed.toLowerCase();
        if (!normalizedBreed.includes(normalizedFilter)) {
          console.log(`❌ Animal ${animal.name} filtered out by breed: ${animal.breed} doesn't match ${filters.breed}`);
          return false;
        }
      }
      
      // Filtre par sexe
      if (filters.sex && animal.sex !== filters.sex) {
        console.log(`❌ Animal ${animal.name} filtered out by sex: ${animal.sex} !== ${filters.sex}`);
        return false;
      }
      
      // Filtre par taille
      if (filters.size && animal.size !== filters.size) {
        console.log(`❌ Animal ${animal.name} filtered out by size: ${animal.size} !== ${filters.size}`);
        return false;
      }
      
      // Filtre par âge
      if (filters.age) {
        if (filters.age.min && animal.age < filters.age.min) {
          console.log(`❌ Animal ${animal.name} filtered out by min age: ${animal.age} < ${filters.age.min}`);
          return false;
        }
        if (filters.age.max && animal.age > filters.age.max) {
          console.log(`❌ Animal ${animal.name} filtered out by max age: ${animal.age} > ${filters.age.max}`);
          return false;
        }
      }
      
      // Filtre par notation des associations
      if (filters.minAssociationRating && animal.associationRating) {
        if (animal.associationRating < filters.minAssociationRating) {
          console.log(`❌ Animal ${animal.name} filtered out by association rating: ${animal.associationRating} < ${filters.minAssociationRating}`);
          return false;
        }
      }
      
      // Filtre par localisation (recherche simple dans le nom de la ville)
      if (filters.location && !animal.location.toLowerCase().includes(filters.location.toLowerCase())) {
        // Si on a des coordonnées de centre et un rayon, on ne filtre pas par nom de ville
        if (!(filters.centerLatitude && filters.centerLongitude && filters.radius)) {
          console.log(`❌ Animal ${animal.name} filtered out by location: ${animal.location} doesn't contain ${filters.location}`);
          return false;
        }
      }
      
      // Filtre par rayon géographique
      if (filters.centerLatitude && filters.centerLongitude && filters.radius) {
        const distance = calculateDistance(
          filters.centerLatitude,
          filters.centerLongitude,
          animal.latitude,
          animal.longitude
        );
        
        console.log(`📍 Distance for ${animal.name}: ${distance} km (limit: ${filters.radius} km)`);
        
        if (distance > filters.radius) {
          console.log(`❌ Animal ${animal.name} filtered out by distance: ${distance} > ${filters.radius}`);
          return false;
        }
        
        // Ajouter la distance calculée à l'animal pour l'affichage
        (animal as any).calculatedDistance = distance;
      }
      
      // Filtre par compatibilité
      if (filters.compatibility) {
        if (filters.compatibility.withDogs && !animal.compatibility.withDogs) {
          console.log(`❌ Animal ${animal.name} filtered out by dog compatibility`);
          return false;
        }
        if (filters.compatibility.withCats && !animal.compatibility.withCats) {
          console.log(`❌ Animal ${animal.name} filtered out by cat compatibility`);
          return false;
        }
        if (filters.compatibility.withChildren && !animal.compatibility.withChildren) {
          console.log(`❌ Animal ${animal.name} filtered out by children compatibility`);
          return false;
        }
      }
      
      console.log(`✅ Animal ${animal.name} passed all filters`);
      return true;
    }).sort((a, b) => {
      // Trier par distance si on a une recherche géographique
      if (filters.centerLatitude && filters.centerLongitude) {
        const distanceA = (a as any).calculatedDistance || 0;
        const distanceB = (b as any).calculatedDistance || 0;
        return distanceA - distanceB;
      }
      
      // Trier par notation d'association (les mieux notées en premier)
      if (a.associationRating && b.associationRating) {
        return b.associationRating - a.associationRating;
      }
      
      return 0;
    });

    console.log('🎯 Filtered animals count:', filtered.length);
    console.log('📋 Filtered animals:', filtered.map(a => ({ 
      name: a.name, 
      location: a.location, 
      coordinates: [a.latitude, a.longitude],
      associationRating: a.associationRating 
    })));
    
    return filtered;
  }, [filters]);

  const handleFavoriteToggle = (animalId: string) => {
    setFavorites(prev => 
      prev.includes(animalId) 
        ? prev.filter(id => id !== animalId)
        : [...prev, animalId]
    );
  };

  const handleMessage = (animalId: string) => {
    console.log('Message animal:', animalId);
    // Ici vous pourriez naviguer vers la page de messagerie
  };

  const handleSearchInArea = (bounds: { north: number; south: number; east: number; west: number }) => {
    console.log('Search in area:', bounds);
    // Ici vous pourriez filtrer les animaux selon les coordonnées géographiques
  };

  const handleGeolocation = async () => {
    setIsGeolocating(true);
    try {
      const position = await getCurrentPosition();
      const { latitude, longitude } = position.coords;
      
      console.log('📍 User position obtained:', { latitude, longitude });
      
      setFilters(prev => ({
        ...prev,
        centerLatitude: latitude,
        centerLongitude: longitude,
        location: 'Ma position actuelle',
        radius: prev.radius || 20 // Rayon par défaut de 20km
      }));
    } catch (error) {
      console.error('Erreur de géolocalisation:', error);
      alert('Impossible d\'obtenir votre position. Veuillez vérifier les autorisations de géolocalisation.');
    } finally {
      setIsGeolocating(false);
    }
  };

  const handleFiltersChange = async (newFilters: SearchFiltersType) => {
    console.log('🔄 Filters changing from:', filters, 'to:', newFilters);
    
    // Si la localisation a changé et qu'on n'a pas de coordonnées, essayer de géocoder
    if (newFilters.location !== filters.location && newFilters.location && !newFilters.centerLatitude) {
      try {
        console.log('🌍 Geocoding address:', newFilters.location);
        const geocoded = await geocodeAddress(newFilters.location);
        if (geocoded) {
          console.log('✅ Geocoding successful:', geocoded);
          newFilters.centerLatitude = geocoded.lat;
          newFilters.centerLongitude = geocoded.lon;
          newFilters.location = geocoded.displayName;
        }
      } catch (error) {
        console.error('Erreur de géocodage:', error);
      }
    }
    
    setFilters(newFilters);
  };

  const clearFilters = () => {
    console.log('🧹 Clearing all filters');
    setFilters({});
  };

  // Debug logs for map view
  console.log('🗺️ Map view props:', {
    animalsCount: filteredAnimals.length,
    centerLatitude: filters.centerLatitude,
    centerLongitude: filters.centerLongitude,
    searchRadius: filters.radius,
    viewMode
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Rechercher des animaux
          </h1>
          <p className="text-gray-600">
            Découvrez les animaux qui ont besoin d'une famille d'accueil
          </p>
        </div>

        {/* Filtres */}
        <div className="mb-6">
          <SearchFilters
            filters={filters}
            onFiltersChange={handleFiltersChange}
            onClearFilters={clearFilters}
            onGeolocation={handleGeolocation}
            showAdvanced={showAdvancedFilters}
            onToggleAdvanced={() => setShowAdvancedFilters(!showAdvancedFilters)}
            isGeolocating={isGeolocating}
          />
        </div>

        {/* Barre d'outils */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-600">
              {filteredAnimals.length} animal{filteredAnimals.length > 1 ? 'x' : ''} trouvé{filteredAnimals.length > 1 ? 's' : ''}
            </span>
            {filters.centerLatitude && filters.centerLongitude && filters.radius && (
              <span className="text-sm text-primary-600">
                dans un rayon de {filters.radius} km
              </span>
            )}
            {filters.minAssociationRating && (
              <span className="text-sm text-yellow-600">
                • associations {filters.minAssociationRating}⭐ et plus
              </span>
            )}
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="flex bg-white rounded-lg border border-gray-200 p-1">
              <Button
                variant={viewMode === 'grid' ? 'primary' : 'ghost'}
                size="sm"
                icon={Grid}
                onClick={() => setViewMode('grid')}
                className="rounded-md"
              >
                <span className="sr-only">Grille</span>
              </Button>
              <Button
                variant={viewMode === 'list' ? 'primary' : 'ghost'}
                size="sm"
                icon={List}
                onClick={() => setViewMode('list')}
                className="rounded-md"
              >
                <span className="sr-only">Liste</span>
              </Button>
              <Button
                variant={viewMode === 'map' ? 'primary' : 'ghost'}
                size="sm"
                icon={MapIcon}
                onClick={() => setViewMode('map')}
                className="rounded-md"
              >
                <span className="sr-only">Carte</span>
              </Button>
            </div>
          </div>
        </div>

        {/* Contenu principal */}
        {viewMode === 'map' ? (
          <div className="h-[600px] rounded-xl overflow-hidden shadow-lg">
            <MapView
              animals={filteredAnimals}
              onAnimalSelect={setSelectedAnimal}
              selectedAnimal={selectedAnimal}
              onSearchInArea={handleSearchInArea}
              centerLatitude={filters.centerLatitude}
              centerLongitude={filters.centerLongitude}
              searchRadius={filters.radius}
            />
          </div>
        ) : (
          <div className={
            viewMode === 'grid' 
              ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
              : 'space-y-4'
          }>
            {filteredAnimals.length > 0 ? (
              filteredAnimals.map((animal) => (
                <div key={animal.id} className={viewMode === 'list' ? 'max-w-4xl' : ''}>
                  <AnimalCard
                    animal={animal}
                    isFavorited={favorites.includes(animal.id)}
                    onFavorite={handleFavoriteToggle}
                    onMessage={handleMessage}
                  />
                  {/* Affichage de la distance si disponible */}
                  {(animal as any).calculatedDistance && (
                    <div className="mt-2 text-xs text-gray-500 text-center">
                      📍 À {(animal as any).calculatedDistance} km
                    </div>
                  )}
                </div>
              ))
            ) : (
              <div className="col-span-full">
                <Card className="text-center py-12">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Heart className="h-8 w-8 text-gray-400" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    Aucun animal trouvé
                  </h3>
                  <p className="text-gray-600 mb-4">
                    Essayez de modifier vos critères de recherche pour voir plus de résultats.
                  </p>
                  <Button onClick={clearFilters} variant="outline">
                    Effacer les filtres
                  </Button>
                </Card>
              </div>
            )}
          </div>
        )}

        {/* Panneau latéral pour l'animal sélectionné (mode carte) */}
        {viewMode === 'map' && selectedAnimal && (
          <div className="fixed right-4 top-24 w-80 max-h-[calc(100vh-8rem)] overflow-y-auto z-20">
            <AnimalCard
              animal={selectedAnimal}
              isFavorited={favorites.includes(selectedAnimal.id)}
              onFavorite={handleFavoriteToggle}
              onMessage={handleMessage}
            />
            {/* Affichage de la distance si disponible */}
            {(selectedAnimal as any).calculatedDistance && (
              <div className="mt-2 text-xs text-gray-500 text-center bg-white p-2 rounded-b-xl">
                📍 À {(selectedAnimal as any).calculatedDistance} km de votre recherche
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}