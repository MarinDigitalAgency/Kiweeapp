import React, { useState } from 'react';
import { Send, Paperclip, Smile, MessageSquareText, ChevronDown } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { PredefinedMessage, UserType } from '../../types';

interface MessageInputProps {
  onSendMessage: (content: string) => void;
  disabled?: boolean;
  predefinedMessages?: PredefinedMessage[];
  currentUserType?: UserType;
}

export function MessageInput({ 
  onSendMessage, 
  disabled = false, 
  predefinedMessages = [],
  currentUserType 
}: MessageInputProps) {
  const [message, setMessage] = useState('');
  const [showPredefinedMessages, setShowPredefinedMessages] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !disabled) {
      onSendMessage(message.trim());
      setMessage('');
    }
  };

  const handlePredefinedMessageSelect = (predefinedMessage: PredefinedMessage) => {
    setMessage(predefinedMessage.content);
    setShowPredefinedMessages(false);
  };

  // Filter predefined messages based on user type
  const filteredMessages = predefinedMessages.filter(msg => 
    !currentUserType || msg.forUserType === currentUserType || msg.forUserType === 'all'
  );

  return (
    <div className="bg-white border-t border-gray-200 p-4">
      {/* Predefined Messages Dropdown */}
      {showPredefinedMessages && filteredMessages.length > 0 && (
        <div className="mb-4 relative">
          <Card className="absolute bottom-0 left-0 right-0 max-h-64 overflow-y-auto z-10 shadow-lg">
            <div className="p-2">
              <div className="flex items-center justify-between mb-3 pb-2 border-b border-gray-100">
                <h3 className="text-sm font-medium text-gray-900">Messages prédéfinis</h3>
                <button
                  onClick={() => setShowPredefinedMessages(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <ChevronDown className="h-4 w-4" />
                </button>
              </div>
              <div className="space-y-1">
                {filteredMessages.map((predefinedMessage) => (
                  <button
                    key={predefinedMessage.id}
                    onClick={() => handlePredefinedMessageSelect(predefinedMessage)}
                    className="w-full text-left p-2 text-sm text-gray-700 hover:bg-gray-50 rounded-md transition-colors"
                    disabled={disabled}
                  >
                    {predefinedMessage.content}
                  </button>
                ))}
              </div>
            </div>
          </Card>
        </div>
      )}

      <form onSubmit={handleSubmit} className="flex items-end space-x-2">
        <div className="flex-1">
          <div className="relative">
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Tapez votre message..."
              disabled={disabled}
              rows={1}
              className="w-full resize-none rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 pr-28 disabled:bg-gray-50 disabled:text-gray-500"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSubmit(e);
                }
              }}
            />
            
            {/* Actions secondaires */}
            <div className="absolute right-2 bottom-2 flex items-center space-x-1">
              <button
                type="button"
                className="p-1 text-gray-400 hover:text-gray-600 transition-colors"
                disabled={disabled}
              >
                <Paperclip className="h-4 w-4" />
              </button>
              {filteredMessages.length > 0 && (
                <button
                  type="button"
                  onClick={() => setShowPredefinedMessages(!showPredefinedMessages)}
                  className="p-1 text-gray-400 hover:text-gray-600 transition-colors"
                  disabled={disabled}
                >
                  <MessageSquareText className="h-4 w-4" />
                </button>
              )}
              <button
                type="button"
                className="p-1 text-gray-400 hover:text-gray-600 transition-colors"
                disabled={disabled}
              >
                <Smile className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
        
        <Button
          type="submit"
          disabled={!message.trim() || disabled}
          icon={Send}
          className="px-4 py-2"
        >
          <span className="sr-only">Envoyer</span>
        </Button>
      </form>
    </div>
  );
}