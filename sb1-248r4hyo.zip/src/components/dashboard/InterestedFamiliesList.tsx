import React, { useMemo } from 'react';
import { Heart, MessageCircle, User, Calendar } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { mockAnimals, getStoredInteractions } from '../../data/mockData';

export function InterestedFamiliesList() {
  const { user } = useAuth();
  const navigate = useNavigate();

  // Get animals belonging to this association and their interested families
  const animalInterests = useMemo(() => {
    if (!user || user.type !== 'association') return [];

    const associationAnimals = mockAnimals.filter(animal => animal.associationId === user.id);
    const interactions = getStoredInteractions();

    return associationAnimals.map(animal => {
      const likes = interactions.filter(
        interaction => interaction.animalId === animal.id && interaction.type === 'like'
      );

      return {
        animal,
        interestedFamilies: likes.map(like => ({
          userId: like.userId,
          timestamp: like.timestamp,
          // In a real app, you'd fetch user details from the API
          userName: like.userId === '2' ? 'Sophie Martin' : 
                   like.userId === '3' ? 'Julie Dupont' : 
                   `Famille ${like.userId}`,
          userLocation: like.userId === '2' ? 'Lyon, France' : 
                       like.userId === '3' ? 'Paris, France' : 
                       'France'
        }))
      };
    }).filter(item => item.interestedFamilies.length > 0);
  }, [user]);

  const totalInterests = animalInterests.reduce(
    (total, item) => total + item.interestedFamilies.length, 
    0
  );

  const handleContactFamily = (familyId: string, animalId: string) => {
    // Navigate to messages page with family and animal info
    navigate(`/messages?animalId=${animalId}&familyId=${familyId}`);
  };

  if (!user || user.type !== 'association') {
    return null;
  }

  return (
    <Card>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-gray-900 flex items-center space-x-2">
            <Heart className="h-5 w-5 text-error-500" />
            <span>Familles intéressées</span>
          </h2>
          <p className="text-sm text-gray-600 mt-1">
            {totalInterests} famille{totalInterests > 1 ? 's' : ''} intéressée{totalInterests > 1 ? 's' : ''} par vos animaux
          </p>
        </div>
      </div>

      {animalInterests.length > 0 ? (
        <div className="space-y-6">
          {animalInterests.map(({ animal, interestedFamilies }) => (
            <div key={animal.id} className="border border-gray-100 rounded-lg p-4">
              {/* Animal header */}
              <div className="flex items-center space-x-4 mb-4">
                <img
                  src={animal.photos[0]}
                  alt={animal.name}
                  className="w-16 h-16 rounded-lg object-cover"
                />
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900">{animal.name}</h3>
                  <p className="text-sm text-gray-600">
                    {animal.breed} • {animal.age} {animal.age > 1 ? 'ans' : 'an'}
                  </p>
                  <Badge variant="success" size="sm" className="mt-1">
                    {interestedFamilies.length} famille{interestedFamilies.length > 1 ? 's' : ''} intéressée{interestedFamilies.length > 1 ? 's' : ''}
                  </Badge>
                </div>
              </div>

              {/* Interested families */}
              <div className="space-y-3">
                {interestedFamilies.map((family, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center">
                        <User className="h-5 w-5 text-primary-600" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{family.userName}</p>
                        <p className="text-sm text-gray-600">{family.userLocation}</p>
                        <div className="flex items-center space-x-1 text-xs text-gray-500 mt-1">
                          <Calendar className="h-3 w-3" />
                          <span>Intéressée le {family.timestamp.toLocaleDateString('fr-FR')}</span>
                        </div>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      icon={MessageCircle}
                      onClick={() => handleContactFamily(family.userId, animal.id)}
                    >
                      Contacter
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Heart className="h-8 w-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Aucune famille intéressée pour le moment
          </h3>
          <p className="text-gray-600 text-sm">
            Les familles qui aiment vos animaux apparaîtront ici. 
            Assurez-vous que vos fiches sont complètes et attractives !
          </p>
        </div>
      )}
    </Card>
  );
}