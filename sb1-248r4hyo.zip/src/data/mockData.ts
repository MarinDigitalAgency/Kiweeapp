import { Animal, Conversation, Message, UserInteraction, AdoptionRequest, User } from '../types';
import { Notification, NotificationType } from '../types';

// Mock users with detailed family profiles
export const mockUsers: User[] = [
  {
    id: '1',
    email: 'association@example.com',
    name: 'Association Refuge du Cœur',
    type: 'association',
    location: 'Paris, France',
    phone: '+33 1 23 45 67 89',
    verified: true,
    createdAt: new Date('2024-01-15'),
  },
  {
    id: '2',
    email: 'famille@example.com',
    name: 'Sophie Martin',
    type: 'family',
    location: 'Lyon, France',
    phone: '+33 4 56 78 90 12',
    verified: true,
    createdAt: new Date('2024-02-10'),
    profile: {
      badges: {
        isProfileVerified: true,
        isTopFosterFamily: true,
        isExperiencedFA: true,
        isCertifiedAssociation: false,
        isRnaVerified: false,
        isEmailVerified: true,
        isPhoneVerified: true,
        hasCompletedProfile: true
      },
      documents: {},
      completionPercentage: 95,
      isProfileComplete: true,
      familyProfile: {
        housingType: 'house_with_garden',
        hasGarden: true,
        hasDedicatedRoom: true,
        acceptedAnimalTypes: {
          dogs: true,
          cats: true,
          nac: false,
          reptiles: false,
          labAnimals: false,
          farmAnimals: false
        },
        acceptedAges: {
          baby: true,
          junior: true,
          adult: true,
          senior: false
        },
        acceptedSizes: {
          small: true,
          medium: true,
          large: false
        },
        acceptedSexes: {
          male: true,
          female: true
        },
        canProvideMedicalCare: true,
        compatibility: {
          withHumans: 2,
          withChildren: 1,
          withCats: 0,
          withDogs: 1,
          withOtherAnimals: 0
        },
        hasVehicle: true,
        experienceLevel: 'experienced',
        previousFosterCount: 8,
        specializations: ['chiens seniors', 'soins médicaux']
      }
    }
  },
  {
    id: '3',
    email: 'julie.dupont@example.com',
    name: 'Julie Dupont',
    type: 'family',
    location: 'Paris, France',
    phone: '+33 1 98 76 54 32',
    verified: true,
    createdAt: new Date('2024-01-20'),
    profile: {
      badges: {
        isProfileVerified: true,
        isTopFosterFamily: false,
        isExperiencedFA: false,
        isCertifiedAssociation: false,
        isRnaVerified: false,
        isEmailVerified: true,
        isPhoneVerified: false,
        hasCompletedProfile: true
      },
      documents: {},
      completionPercentage: 80,
      isProfileComplete: true,
      familyProfile: {
        housingType: 'apartment_with_outdoor',
        hasGarden: false,
        hasDedicatedRoom: false,
        acceptedAnimalTypes: {
          dogs: false,
          cats: true,
          nac: true,
          reptiles: false,
          labAnimals: false,
          farmAnimals: false
        },
        acceptedAges: {
          baby: false,
          junior: true,
          adult: true,
          senior: true
        },
        acceptedSizes: {
          small: true,
          medium: false,
          large: false
        },
        acceptedSexes: {
          male: true,
          female: true
        },
        canProvideMedicalCare: false,
        compatibility: {
          withHumans: 1,
          withChildren: 0,
          withCats: 2,
          withDogs: 0,
          withOtherAnimals: 0
        },
        hasVehicle: false,
        experienceLevel: 'beginner',
        previousFosterCount: 0,
        specializations: []
      }
    }
  },
  {
    id: '4',
    email: 'famille.bernard@example.com',
    name: 'Famille Bernard',
    type: 'family',
    location: 'Marseille, France',
    phone: '+33 4 91 23 45 67',
    verified: true,
    createdAt: new Date('2024-01-05'),
    profile: {
      badges: {
        isProfileVerified: true,
        isTopFosterFamily: false,
        isExperiencedFA: true,
        isCertifiedAssociation: false,
        isRnaVerified: false,
        isEmailVerified: true,
        isPhoneVerified: true,
        hasCompletedProfile: true
      },
      documents: {},
      completionPercentage: 90,
      isProfileComplete: true,
      familyProfile: {
        housingType: 'house_with_garden',
        hasGarden: true,
        hasDedicatedRoom: true,
        acceptedAnimalTypes: {
          dogs: true,
          cats: false,
          nac: false,
          reptiles: false,
          labAnimals: false,
          farmAnimals: true
        },
        acceptedAges: {
          baby: true,
          junior: true,
          adult: true,
          senior: true
        },
        acceptedSizes: {
          small: true,
          medium: true,
          large: true
        },
        acceptedSexes: {
          male: true,
          female: true
        },
        canProvideMedicalCare: false,
        compatibility: {
          withHumans: 2,
          withChildren: 3,
          withCats: 0,
          withDogs: 2,
          withOtherAnimals: 1
        },
        hasVehicle: true,
        experienceLevel: 'intermediate',
        previousFosterCount: 3,
        specializations: ['grands chiens', 'socialisation']
      }
    }
  },
  {
    id: '5',
    email: 'marie.rousseau@example.com',
    name: 'Marie Rousseau',
    type: 'family',
    location: 'Toulouse, France',
    phone: '+33 5 61 12 34 56',
    verified: false,
    createdAt: new Date('2024-02-15'),
    profile: {
      badges: {
        isProfileVerified: false,
        isTopFosterFamily: false,
        isExperiencedFA: false,
        isCertifiedAssociation: false,
        isRnaVerified: false,
        isEmailVerified: true,
        isPhoneVerified: false,
        hasCompletedProfile: false
      },
      documents: {},
      completionPercentage: 60,
      isProfileComplete: false,
      familyProfile: {
        housingType: 'apartment_without_outdoor',
        hasGarden: false,
        hasDedicatedRoom: false,
        acceptedAnimalTypes: {
          dogs: false,
          cats: true,
          nac: false,
          reptiles: false,
          labAnimals: false,
          farmAnimals: false
        },
        acceptedAges: {
          baby: false,
          junior: false,
          adult: true,
          senior: true
        },
        acceptedSizes: {
          small: true,
          medium: false,
          large: false
        },
        acceptedSexes: {
          male: true,
          female: true
        },
        canProvideMedicalCare: false,
        compatibility: {
          withHumans: 1,
          withChildren: 0,
          withCats: 0,
          withDogs: 0,
          withOtherAnimals: 0
        },
        hasVehicle: false,
        experienceLevel: 'beginner',
        previousFosterCount: 0,
        specializations: []
      }
    }
  }
];

// Mock notifications
export const mockNotifications: Notification[] = [
  {
    id: '1',
    userId: '2', // Sophie Martin (family)
    type: 'new_message',
    title: 'Nouveau message',
    message: 'Association Refuge du Cœur vous a envoyé un message concernant Luna',
    read: false,
    createdAt: new Date('2024-01-30T16:30:00'),
    priority: 'medium',
    category: 'info',
    data: {
      animalId: '1',
      animalName: 'Luna',
      conversationId: '1',
      associationId: '1',
      associationName: 'Association Refuge du Cœur',
      url: '/messages?conversationId=1'
    }
  },
  {
    id: '2',
    userId: '2', // Sophie Martin (family)
    type: 'adoption_request_status',
    title: 'Demande d\'accueil acceptée',
    message: 'Votre demande d\'accueil pour Rex a été acceptée ! L\'association va vous contacter.',
    read: false,
    createdAt: new Date('2024-01-30T14:15:00'),
    priority: 'high',
    category: 'success',
    data: {
      animalId: '3',
      animalName: 'Rex',
      adoptionRequestId: '1',
      associationId: '1',
      associationName: 'Association Refuge du Cœur',
      url: '/dashboard'
    }
  },
  {
    id: '3',
    userId: '1', // Association
    type: 'animal_liked',
    title: 'Nouvel intérêt pour Luna',
    message: 'Sophie Martin a ajouté Luna à ses favoris',
    read: true,
    createdAt: new Date('2024-01-28T14:30:00'),
    readAt: new Date('2024-01-28T15:00:00'),
    priority: 'medium',
    category: 'info',
    data: {
      animalId: '1',
      animalName: 'Luna',
      familyId: '2',
      familyName: 'Sophie Martin',
      url: '/dashboard'
    }
  },
  {
    id: '4',
    userId: '2', // Sophie Martin (family)
    type: 'new_animal_available',
    title: 'Nouvel animal disponible',
    message: 'Un nouveau chien correspondant à vos critères est disponible : Buddy',
    read: true,
    createdAt: new Date('2024-01-27T10:00:00'),
    readAt: new Date('2024-01-27T18:30:00'),
    priority: 'medium',
    category: 'info',
    data: {
      animalId: '9',
      animalName: 'Buddy',
      associationId: '1',
      associationName: 'Association Refuge du Cœur',
      url: '/animal/9'
    }
  },
  {
    id: '5',
    userId: '2', // Sophie Martin (family)
    type: 'profile_verification',
    title: 'Profil vérifié',
    message: 'Félicitations ! Votre profil a été vérifié avec succès.',
    read: true,
    createdAt: new Date('2024-01-25T09:00:00'),
    readAt: new Date('2024-01-25T09:15:00'),
    priority: 'low',
    category: 'success',
    data: {
      url: '/profile'
    }
  }
];

// Get families for search (excluding associations)
export const getFamiliesForSearch = () => {
  return mockUsers.filter(user => user.type === 'family');
};

export const mockAnimals: Animal[] = [
  {
    id: '1',
    name: 'Luna',
    type: 'chien',
    breed: 'Border Collie',
    age: 3,
    sex: 'female',
    size: 'moyen',
    photos: [
      'https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/825947/pexels-photo-825947.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    description: 'Luna est une chienne très affectueuse et énergique. Elle adore jouer et faire de longues promenades. Parfaite pour une famille active.',
    health: {
      vaccinated: true,
      sterilized: true,
      treatments: ['Vermifuge à jour']
    },
    characterTraits: {
      sociability: 4,
      obedience: 3,
      cuddliness: 5,
      independence: 2
    },
    compatibility: {
      withDogs: true,
      withCats: false,
      withChildren: true
    },
    associationId: '1',
    associationName: 'Association Refuge du Cœur',
    associationRating: 5,
    location: 'Paris, France',
    latitude: 48.8566,
    longitude: 2.3522,
    availableFrom: new Date('2024-01-20'),
    status: 'available',
    createdAt: new Date('2024-01-15')
  },
  {
    id: '2',
    name: 'Milo',
    type: 'chat',
    breed: 'Européen',
    age: 2,
    sex: 'male',
    size: 'moyen',
    photos: [
      'https://images.pexels.com/photos/45201/kitty-cat-kitten-pet-45201.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/416160/pexels-photo-416160.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    description: 'Milo est un chat calme et câlin. Il cherche une famille tranquille pour ses vieux jours. Très sociable avec les humains.',
    health: {
      vaccinated: true,
      sterilized: true,
    },
    compatibility: {
      withDogs: false,
      withCats: true,
      withChildren: true
    },
    associationId: '1',
    associationName: 'Association Refuge du Cœur',
    associationRating: 5,
    location: 'Lyon, France',
    latitude: 45.7640,
    longitude: 4.8357,
    availableFrom: new Date('2024-01-25'),
    status: 'in_care',
    createdAt: new Date('2024-01-20')
  },
  {
    id: '3',
    name: 'Rex',
    type: 'chien',
    breed: 'Golden Retriever',
    age: 5,
    sex: 'male',
    size: 'grand',
    photos: [
      'https://images.pexels.com/photos/160846/french-bulldog-summer-smile-joy-160846.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1254140/pexels-photo-1254140.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    description: 'Rex est un grand chien très doux et patient. Idéal pour les familles avec enfants. Il a besoin d\'espace pour se dépenser.',
    health: {
      vaccinated: true,
      sterilized: false,
      treatments: ['Traitement arthrose']
    },
    characterTraits: {
      sociability: 5,
      obedience: 4,
      cuddliness: 5,
      independence: 1
    },
    compatibility: {
      withDogs: true,
      withCats: true,
      withChildren: true
    },
    associationId: '1',
    associationName: 'Association Refuge du Cœur',
    associationRating: 4,
    location: 'Lyon, France',
    latitude: 45.7489,
    longitude: 4.8467,
    availableFrom: new Date('2024-02-01'),
    status: 'adopted',
    createdAt: new Date('2024-01-25')
  },
  {
    id: '4',
    name: 'Bella',
    type: 'chien',
    breed: 'Labrador',
    age: 4,
    sex: 'female',
    size: 'grand',
    photos: [
      'https://images.pexels.com/photos/1805164/pexels-photo-1805164.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    description: 'Bella est une chienne très sociable qui adore les enfants et les autres chiens.',
    health: {
      vaccinated: true,
      sterilized: true,
    },
    compatibility: {
      withDogs: true,
      withCats: false,
      withChildren: true
    },
    associationId: '1',
    associationName: 'Association Refuge du Cœur',
    associationRating: 3,
    location: 'Villeurbanne, France',
    latitude: 45.7667,
    longitude: 4.8833,
    availableFrom: new Date('2024-02-05'),
    status: 'available',
    createdAt: new Date('2024-01-30')
  },
  {
    id: '5',
    name: 'Oscar',
    type: 'chat',
    breed: 'Maine Coon',
    age: 1,
    sex: 'male',
    size: 'grand',
    photos: [
      'https://images.pexels.com/photos/1170986/pexels-photo-1170986.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    description: 'Oscar est un jeune chat très joueur qui s\'entend bien avec tout le monde.',
    health: {
      vaccinated: true,
      sterilized: false,
    },
    characterTraits: {
      sociability: 4,
      obedience: 2,
      cuddliness: 3,
      independence: 3
    },
    compatibility: {
      withDogs: true,
      withCats: true,
      withChildren: true
    },
    associationId: '1',
    associationName: 'Association Refuge du Cœur',
    associationRating: 4,
    location: 'Caluire-et-Cuire, France',
    latitude: 45.7975,
    longitude: 4.8508,
    availableFrom: new Date('2024-02-10'),
    status: 'in_care',
    createdAt: new Date('2024-02-01')
  },
  {
    id: '6',
    name: 'Maya',
    type: 'chien',
    breed: 'Berger Allemand',
    age: 6,
    sex: 'female',
    size: 'grand',
    photos: [
      'https://images.pexels.com/photos/333083/pexels-photo-333083.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    description: 'Maya est une chienne expérimentée, très obéissante et protectrice.',
    health: {
      vaccinated: true,
      sterilized: true,
    },
    characterTraits: {
      sociability: 3,
      obedience: 5,
      cuddliness: 2,
      independence: 4
    },
    compatibility: {
      withDogs: false,
      withCats: false,
      withChildren: true
    },
    associationId: '1',
    associationName: 'Association Refuge du Cœur',
    associationRating: 2,
    location: 'Vénissieux, France',
    latitude: 45.7000,
    longitude: 4.8833,
    availableFrom: new Date('2024-02-15'),
    status: 'available',
    createdAt: new Date('2024-02-05')
  },
  // Success stories - animals that found families
  {
    id: '7',
    name: 'Charlie',
    type: 'chien',
    breed: 'Beagle',
    age: 3,
    sex: 'male',
    size: 'moyen',
    photos: [
      'https://images.pexels.com/photos/1851164/pexels-photo-1851164.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    description: 'Charlie a trouvé une famille aimante qui lui offre tout l\'amour qu\'il mérite.',
    health: {
      vaccinated: true,
      sterilized: true,
    },
    compatibility: {
      withDogs: true,
      withCats: true,
      withChildren: true
    },
    associationId: '1',
    associationName: 'Association Refuge du Cœur',
    associationRating: 5,
    location: 'Lyon, France',
    latitude: 45.7640,
    longitude: 4.8357,
    availableFrom: new Date('2023-12-01'),
    status: 'adopted',
    createdAt: new Date('2023-11-15')
  },
  {
    id: '8',
    name: 'Nala',
    type: 'chat',
    breed: 'Siamois',
    age: 2,
    sex: 'female',
    size: 'petit',
    photos: [
      'https://images.pexels.com/photos/1643457/pexels-photo-1643457.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    description: 'Nala coule des jours heureux dans sa nouvelle famille qui l\'adore.',
    health: {
      vaccinated: true,
      sterilized: true,
    },
    compatibility: {
      withDogs: false,
      withCats: true,
      withChildren: true
    },
    associationId: '1',
    associationName: 'Association Refuge du Cœur',
    associationRating: 4,
    location: 'Paris, France',
    latitude: 48.8566,
    longitude: 2.3522,
    availableFrom: new Date('2023-11-20'),
    status: 'adopted',
    createdAt: new Date('2023-10-10')
  },
  {
    id: '9',
    name: 'Buddy',
    type: 'chien',
    breed: 'Labrador Mix',
    age: 4,
    sex: 'male',
    size: 'grand',
    photos: [
      'https://images.pexels.com/photos/1390361/pexels-photo-1390361.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    description: 'Buddy profite maintenant d\'un grand jardin et de longues balades quotidiennes.',
    health: {
      vaccinated: true,
      sterilized: true,
    },
    compatibility: {
      withDogs: true,
      withCats: false,
      withChildren: true
    },
    associationId: '1',
    associationName: 'Association Refuge du Cœur',
    associationRating: 5,
    location: 'Marseille, France',
    latitude: 43.2965,
    longitude: 5.3698,
    availableFrom: new Date('2023-10-15'),
    status: 'adopted',
    createdAt: new Date('2023-09-01')
  },
  {
    id: '10',
    name: 'Whiskers',
    type: 'chat',
    breed: 'Persan',
    age: 5,
    sex: 'male',
    size: 'moyen',
    photos: [
      'https://images.pexels.com/photos/1741205/pexels-photo-1741205.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    description: 'Whiskers a trouvé une retraite paisible chez une famille qui comprend ses besoins.',
    health: {
      vaccinated: true,
      sterilized: true,
    },
    compatibility: {
      withDogs: false,
      withCats: true,
      withChildren: false
    },
    associationId: '1',
    associationName: 'Association Refuge du Cœur',
    associationRating: 3,
    location: 'Nice, France',
    latitude: 43.7102,
    longitude: 7.2620,
    availableFrom: new Date('2023-12-10'),
    status: 'in_care',
    createdAt: new Date('2023-11-01')
  },
  {
    id: '11',
    name: 'Rosie',
    type: 'chien',
    breed: 'Cocker Spaniel',
    age: 2,
    sex: 'female',
    size: 'moyen',
    photos: [
      'https://images.pexels.com/photos/1458925/pexels-photo-1458925.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    description: 'Rosie s\'épanouit dans sa nouvelle famille avec des enfants qui l\'adorent.',
    health: {
      vaccinated: true,
      sterilized: true,
    },
    compatibility: {
      withDogs: true,
      withCats: true,
      withChildren: true
    },
    associationId: '1',
    associationName: 'Association Refuge du Cœur',
    associationRating: 4,
    location: 'Toulouse, France',
    latitude: 43.6047,
    longitude: 1.4442,
    availableFrom: new Date('2023-11-01'),
    status: 'adopted',
    createdAt: new Date('2023-09-15')
  }
];

// Mock user interactions for the matching system
export const mockUserInteractions: UserInteraction[] = [
  {
    id: '1',
    userId: '2', // Sophie Martin (family)
    animalId: '1', // Luna
    type: 'like',
    timestamp: new Date('2024-01-28T14:00:00')
  },
  {
    id: '2',
    userId: '2', // Sophie Martin (family)
    animalId: '2', // Milo
    type: 'pass',
    timestamp: new Date('2024-01-28T14:05:00')
  },
  {
    id: '3',
    userId: '2', // Sophie Martin (family)
    animalId: '3', // Rex
    type: 'like',
    timestamp: new Date('2024-01-29T10:00:00')
  },
  {
    id: '4',
    userId: '3', // Julie Dupont (family)
    animalId: '1', // Luna
    type: 'like',
    timestamp: new Date('2024-01-29T16:00:00')
  },
  {
    id: '5',
    userId: '3', // Julie Dupont (family)
    animalId: '2', // Milo
    type: 'like',
    timestamp: new Date('2024-01-30T14:00:00')
  },
  {
    id: '6',
    userId: '3', // Julie Dupont (family)
    animalId: '4', // Bella
    type: 'pass',
    timestamp: new Date('2024-01-30T14:10:00')
  }
];

// Mock adoption requests
export const mockAdoptionRequests: AdoptionRequest[] = [
  {
    id: '1',
    animalId: '1',
    animalName: 'Luna',
    familyId: '2',
    familyName: 'Sophie Martin',
    associationId: '1',
    associationName: 'Association Refuge du Cœur',
    status: 'pending',
    familyAdoptionProfile: {
      familyComposition: {
        adults: 2,
        children: 1,
        childrenAges: '8 ans'
      },
      housingType: 'house_with_garden',
      housingSize: '120m²',
      hasGarden: true,
      gardenSize: '300m²',
      isOwner: true,
      previousPets: true,
      previousPetsDetails: 'Un chien pendant 10 ans',
      experienceLevel: 'intermediate',
      workSchedule: '9h-17h, télétravail 2 jours/semaine',
      dailyPresence: '6-8h par jour',
      vacationPlans: '2 semaines en été, garde prévue',
      monthlyBudget: '150€',
      emergencyFund: true,
      adoptionMotivation: 'Nous cherchons un compagnon pour notre famille',
      expectations: 'Un chien actif pour accompagner nos balades',
      agreesToVisits: true,
      agreesToUpdates: true,
      understandsCommitment: true
    },
    submittedAt: new Date('2024-01-30T10:00:00')
  }
];

// Utility functions for managing interactions in localStorage
export const getStoredInteractions = (): UserInteraction[] => {
  const stored = localStorage.getItem('kiweeto_interactions');
  if (stored) {
    const parsed = JSON.parse(stored);
    return parsed.map((interaction: any) => ({
      ...interaction,
      timestamp: new Date(interaction.timestamp)
    }));
  }
  return [...mockUserInteractions];
};

export const saveInteraction = (interaction: UserInteraction): void => {
  const interactions = getStoredInteractions();
  interactions.push(interaction);
  localStorage.setItem('kiweeto_interactions', JSON.stringify(interactions));
};

export const getUserInteractions = (userId: string): UserInteraction[] => {
  return getStoredInteractions().filter(interaction => interaction.userId === userId);
};

export const getAnimalInteractions = (animalId: string): UserInteraction[] => {
  return getStoredInteractions().filter(interaction => interaction.animalId === animalId);
};

export const hasUserInteractedWithAnimal = (userId: string, animalId: string): boolean => {
  return getStoredInteractions().some(
    interaction => interaction.userId === userId && interaction.animalId === animalId
  );
};

// Clear all interactions for a specific user (for restart functionality)
export const clearUserInteractions = (userId: string): void => {
  const allInteractions = getStoredInteractions();
  const filteredInteractions = allInteractions.filter(interaction => interaction.userId !== userId);
  localStorage.setItem('kiweeto_interactions', JSON.stringify(filteredInteractions));
};

// Adoption request utilities
export const getStoredAdoptionRequests = (): AdoptionRequest[] => {
  const stored = localStorage.getItem('kiweeto_adoption_requests');
  if (stored) {
    const parsed = JSON.parse(stored);
    return parsed.map((request: any) => ({
      ...request,
      submittedAt: new Date(request.submittedAt),
      reviewedAt: request.reviewedAt ? new Date(request.reviewedAt) : undefined,
      contractSignedAt: request.contractSignedAt ? new Date(request.contractSignedAt) : undefined
    }));
  }
  return [...mockAdoptionRequests];
};

export const saveAdoptionRequest = async (request: AdoptionRequest): Promise<void> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const requests = getStoredAdoptionRequests();
  requests.push(request);
  localStorage.setItem('kiweeto_adoption_requests', JSON.stringify(requests));
};

// Notification utilities
export const getStoredNotifications = (): Notification[] => {
  const stored = localStorage.getItem('kiweeto_notifications');
  if (stored) {
    const parsed = JSON.parse(stored);
    return parsed.map((notification: any) => ({
      ...notification,
      createdAt: new Date(notification.createdAt),
      readAt: notification.readAt ? new Date(notification.readAt) : undefined
    }));
  }
  return [...mockNotifications];
};

export const saveNotification = (notification: Notification): void => {
  const notifications = getStoredNotifications();
  notifications.unshift(notification); // Add to beginning for chronological order
  localStorage.setItem('kiweeto_notifications', JSON.stringify(notifications));
};

export const getUserNotifications = (userId: string): Notification[] => {
  return getStoredNotifications()
    .filter(notification => notification.userId === userId)
    .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
};

export const getUnreadNotificationCount = (userId: string): number => {
  return getStoredNotifications()
    .filter(notification => notification.userId === userId && !notification.read)
    .length;
};

export const markNotificationAsRead = (notificationId: string): void => {
  const notifications = getStoredNotifications();
  const notificationIndex = notifications.findIndex(n => n.id === notificationId);
  
  if (notificationIndex >= 0) {
    notifications[notificationIndex].read = true;
    notifications[notificationIndex].readAt = new Date();
    localStorage.setItem('kiweeto_notifications', JSON.stringify(notifications));
  }
};

export const markAllNotificationsAsRead = (userId: string): void => {
  const notifications = getStoredNotifications();
  const now = new Date();
  
  notifications.forEach(notification => {
    if (notification.userId === userId && !notification.read) {
      notification.read = true;
      notification.readAt = now;
    }
  });
  
  localStorage.setItem('kiweeto_notifications', JSON.stringify(notifications));
};

// Create notification helper functions
export const createNotification = (
  userId: string,
  type: NotificationType,
  title: string,
  message: string,
  data?: Notification['data'],
  priority: Notification['priority'] = 'medium',
  category: Notification['category'] = 'info'
): void => {
  const notification: Notification = {
    id: Date.now().toString(),
    userId,
    type,
    title,
    message,
    read: false,
    createdAt: new Date(),
    data,
    priority,
    category
  };
  
  saveNotification(notification);
};

// Enhanced interaction handler with notifications
export const handleLikeInteractionWithNotification = (interaction: UserInteraction): void => {
  saveInteraction(interaction);
  
  if (interaction.type === 'like') {
    const animal = mockAnimals.find(a => a.id === interaction.animalId);
    if (animal) {
      // Create conversation automatically
      const conversation = createOrGetConversation(
        interaction.animalId,
        interaction.userId,
        animal.associationId
      );
      
      // Add an automatic welcome message from the association
      const welcomeMessage: Message = {
        id: `welcome-${Date.now()}`,
        conversationId: conversation.id,
        senderId: animal.associationId,
        senderName: animal.associationName,
        content: `Bonjour ! Merci pour votre intérêt pour ${animal.name}. N'hésitez pas à nous poser toutes vos questions concernant son accueil. 🐾`,
        timestamp: new Date(),
        read: false
      };
      
      saveMessage(welcomeMessage);
      
      // Create notification for the association about the like
      const familyName = interaction.userId === '2' ? 'Sophie Martin' : 
                        interaction.userId === '3' ? 'Julie Dupont' : 
                        `Famille ${interaction.userId}`;
      
      createNotification(
        animal.associationId,
        'animal_liked',
        'Nouvel intérêt pour un animal',
        `${familyName} a ajouté ${animal.name} à ses favoris`,
        {
          animalId: animal.id,
          animalName: animal.name,
          familyId: interaction.userId,
          familyName,
          url: '/dashboard'
        },
        'medium',
        'info'
      );
      
      // Create notification for the family about the automatic message
      createNotification(
        interaction.userId,
        'new_message',
        'Message automatique reçu',
        `${animal.associationName} vous a envoyé un message de bienvenue concernant ${animal.name}`,
        {
          animalId: animal.id,
          animalName: animal.name,
          conversationId: conversation.id,
          associationId: animal.associationId,
          associationName: animal.associationName,
          url: `/messages?conversationId=${conversation.id}`
        },
        'medium',
        'info'
      );
    }
  }
};

// Enhanced message saving with notifications
export const saveMessageWithNotification = (message: Message): void => {
  saveMessage(message);
  
  // Update conversation's last message
  const conversations = getStoredConversations();
  const conversationIndex = conversations.findIndex(c => c.id === message.conversationId);
  
  if (conversationIndex >= 0) {
    const conversation = conversations[conversationIndex];
    conversation.lastMessage = message;
    conversation.unreadCount = 0; // Reset for demo
    localStorage.setItem('kiweeto_conversations', JSON.stringify(conversations));
    
    // Create notification for the recipient
    const recipientId = message.senderId === conversation.participants.familyId 
      ? conversation.participants.associationId 
      : conversation.participants.familyId;
    
    const recipientName = message.senderId === conversation.participants.familyId 
      ? conversation.participants.associationName 
      : conversation.participants.familyName;
    
    createNotification(
      recipientId,
      'new_message',
      'Nouveau message',
      `${message.senderName} vous a envoyé un message concernant ${conversation.animalName}`,
      {
        animalId: conversation.animalId,
        animalName: conversation.animalName,
        conversationId: conversation.id,
        associationId: conversation.participants.associationId,
        associationName: conversation.participants.associationName,
        familyId: conversation.participants.familyId,
        familyName: conversation.participants.familyName,
        url: `/messages?conversationId=${conversation.id}`
      },
      'medium',
      'info'
    );
  }
};

// Enhanced adoption request saving with notifications
export const saveAdoptionRequestWithNotification = async (request: AdoptionRequest): Promise<void> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const requests = getStoredAdoptionRequests();
  requests.push(request);
  localStorage.setItem('kiweeto_adoption_requests', JSON.stringify(requests));
  
  // Create notification for the association
  createNotification(
    request.associationId,
    'adoption_request_status',
    'Nouvelle demande d\'accueil',
    `${request.familyName} souhaite accueillir ${request.animalName}`,
    {
      animalId: request.animalId,
      animalName: request.animalName,
      adoptionRequestId: request.id,
      familyId: request.familyId,
      familyName: request.familyName,
      url: '/dashboard'
    },
    'high',
    'info'
  );
};

export const getAdoptionRequests = (userId: string, userType: 'family' | 'association'): AdoptionRequest[] => {
  const requests = getStoredAdoptionRequests();
  
  if (userType === 'family') {
    return requests.filter(request => request.familyId === userId);
  } else {
    return requests.filter(request => request.associationId === userId);
  }
};

export const updateAdoptionRequestStatus = async (
  requestId: string, 
  status: AdoptionRequest['status'], 
  reviewNotes?: string
): Promise<void> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const requests = getStoredAdoptionRequests();
  const requestIndex = requests.findIndex(r => r.id === requestId);
  
  if (requestIndex >= 0) {
    requests[requestIndex].status = status;
    requests[requestIndex].reviewedAt = new Date();
    if (reviewNotes) {
      requests[requestIndex].reviewNotes = reviewNotes;
    }
    localStorage.setItem('kiweeto_adoption_requests', JSON.stringify(requests));
  }
};

// Function to update an animal's data
export const updateAnimal = async (animalId: string, animalData: Partial<Animal>): Promise<Animal> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Find the animal in the mock data
  const animalIndex = mockAnimals.findIndex(a => a.id === animalId);
  
  if (animalIndex === -1) {
    throw new Error('Animal not found');
  }
  
  // Update the animal data
  const updatedAnimal = {
    ...mockAnimals[animalIndex],
    ...animalData
  };
  
  // Replace the animal in the mock data
  mockAnimals[animalIndex] = updatedAnimal;
  
  return updatedAnimal;
};

// Messaging system utilities
export const getStoredConversations = (): Conversation[] => {
  const stored = localStorage.getItem('kiweeto_conversations');
  if (stored) {
    const parsed = JSON.parse(stored);
    return parsed.map((conv: any) => ({
      ...conv,
      createdAt: new Date(conv.createdAt),
      lastMessage: conv.lastMessage ? {
        ...conv.lastMessage,
        timestamp: new Date(conv.lastMessage.timestamp)
      } : undefined
    }));
  }
  return [...mockConversations];
};

export const getStoredMessages = (): Message[] => {
  const stored = localStorage.getItem('kiweeto_messages');
  if (stored) {
    const parsed = JSON.parse(stored);
    return parsed.map((msg: any) => ({
      ...msg,
      timestamp: new Date(msg.timestamp)
    }));
  }
  return [...mockMessages];
};

export const saveConversation = (conversation: Conversation): void => {
  const conversations = getStoredConversations();
  const existingIndex = conversations.findIndex(c => c.id === conversation.id);
  
  if (existingIndex >= 0) {
    conversations[existingIndex] = conversation;
  } else {
    conversations.push(conversation);
  }
  
  localStorage.setItem('kiweeto_conversations', JSON.stringify(conversations));
};

export const saveMessage = (message: Message): void => {
  const messages = getStoredMessages();
  messages.push(message);
  localStorage.setItem('kiweeto_messages', JSON.stringify(messages));
  
  // Update conversation's last message
  const conversations = getStoredConversations();
  const conversationIndex = conversations.findIndex(c => c.id === message.conversationId);
  
  if (conversationIndex >= 0) {
    conversations[conversationIndex].lastMessage = message;
    conversations[conversationIndex].unreadCount = 0; // Reset for demo
    localStorage.setItem('kiweeto_conversations', JSON.stringify(conversations));
  }
};

export const createOrGetConversation = (
  animalId: string,
  familyId: string,
  associationId: string
): Conversation => {
  const conversations = getStoredConversations();
  
  // Check if conversation already exists
  const existingConversation = conversations.find(conv => 
    conv.animalId === animalId && 
    conv.participants.familyId === familyId && 
    conv.participants.associationId === associationId
  );
  
  if (existingConversation) {
    return existingConversation;
  }
  
  // Get animal and user details
  const animal = mockAnimals.find(a => a.id === animalId);
  const familyName = familyId === '2' ? 'Sophie Martin' : 
                    familyId === '3' ? 'Julie Dupont' : 
                    `Famille ${familyId}`;
  const associationName = animal?.associationName || 'Association';
  
  // Create new conversation
  const newConversation: Conversation = {
    id: Date.now().toString(),
    animalId,
    animalName: animal?.name || 'Animal',
    participants: {
      familyId,
      familyName,
      associationId,
      associationName
    },
    unreadCount: 0,
    createdAt: new Date()
  };
  
  saveConversation(newConversation);
  return newConversation;
};

export const getConversationMessages = (conversationId: string): Message[] => {
  return getStoredMessages().filter(msg => msg.conversationId === conversationId);
};

export const getUserConversations = (userId: string, userType: 'family' | 'association'): Conversation[] => {
  const conversations = getStoredConversations();
  
  return conversations.filter(conv => {
    if (userType === 'family') {
      return conv.participants.familyId === userId;
    } else {
      return conv.participants.associationId === userId;
    }
  }).sort((a, b) => {
    // Sort by last message timestamp, most recent first
    const aTime = a.lastMessage?.timestamp.getTime() || a.createdAt.getTime();
    const bTime = b.lastMessage?.timestamp.getTime() || b.createdAt.getTime();
    return bTime - aTime;
  });
};

export const getUnreadMessageCount = (userId: string, userType: 'family' | 'association'): number => {
  const conversations = getUserConversations(userId, userType);
  return conversations.reduce((total, conv) => total + conv.unreadCount, 0);
};

// Auto-create conversation when a like happens (Tinder-style matching)
export const handleLikeInteraction = (interaction: UserInteraction): void => {
  // Use the enhanced version with notifications
  handleLikeInteractionWithNotification(interaction);
};

export const mockConversations: Conversation[] = [
  {
    id: '1',
    animalId: '1',
    animalName: 'Luna',
    participants: {
      familyId: '2',
      familyName: 'Sophie Martin',
      associationId: '1',
      associationName: 'Association Refuge du Cœur'
    },
    lastMessage: {
      id: '2',
      conversationId: '1',
      senderId: '1',
      senderName: 'Association Refuge du Cœur',
      content: 'Bonjour Sophie ! Luna est effectivement disponible. Elle est très sociable et adore les promenades. Avez-vous de l\'expérience avec les chiens ?',
      timestamp: new Date('2024-01-28T15:45:00'),
      read: true
    },
    unreadCount: 1,
    createdAt: new Date('2024-01-28T14:30:00')
  },
  {
    id: '2',
    animalId: '3',
    animalName: 'Rex',
    participants: {
      familyId: '2',
      familyName: 'Sophie Martin',
      associationId: '1',
      associationName: 'Association Refuge du Cœur'
    },
    lastMessage: {
      id: '3',
      conversationId: '2',
      senderId: '2',
      senderName: 'Sophie Martin',
      content: 'Bonjour, je suis intéressée par Rex. Pourriez-vous me dire s\'il s\'entend bien avec les enfants ?',
      timestamp: new Date('2024-01-29T10:20:00'),
      read: false
    },
    unreadCount: 0,
    createdAt: new Date('2024-01-29T10:20:00')
  },
  {
    id: '3',
    animalId: '2',
    animalName: 'Milo',
    participants: {
      familyId: '3',
      familyName: 'Julie Dupont',
      associationId: '1',
      associationName: 'Association Refuge du Cœur'
    },
    lastMessage: {
      id: '4',
      conversationId: '3',
      senderId: '3',
      senderName: 'Julie Dupont',
      content: 'Bonjour, j\'aimerais en savoir plus sur Milo. Est-il habitué à vivre en appartement ?',
      timestamp: new Date('2024-01-30T14:15:00'),
      read: false
    },
    unreadCount: 2,
    createdAt: new Date('2024-01-30T14:15:00')
  }
];

export const mockMessages: Message[] = [
  {
    id: '1',
    conversationId: '1',
    senderId: '2',
    senderName: 'Sophie Martin',
    content: 'Bonjour, je suis très intéressée par Luna. Pourriez-vous me donner plus d\'informations ?',
    timestamp: new Date('2024-01-28T14:30:00'),
    read: true
  },
  {
    id: '2',
    conversationId: '1',
    senderId: '1',
    senderName: 'Association Refuge du Cœur',
    content: 'Bonjour Sophie ! Luna est effectivement disponible. Elle est très sociable et adore les promenades. Avez-vous de l\'expérience avec les chiens ?',
    timestamp: new Date('2024-01-28T15:45:00'),
    read: true
  },
  {
    id: '3',
    conversationId: '2',
    senderId: '2',
    senderName: 'Sophie Martin',
    content: 'Bonjour, je suis intéressée par Rex. Pourriez-vous me dire s\'il s\'entend bien avec les enfants ?',
    timestamp: new Date('2024-01-29T10:20:00'),
    read: false
  },
  {
    id: '4',
    conversationId: '3',
    senderId: '3',
    senderName: 'Julie Dupont',
    content: 'Bonjour, j\'aimerais en savoir plus sur Milo. Est-il habitué à vivre en appartement ?',
    timestamp: new Date('2024-01-30T14:15:00'),
    read: false
  },
  {
    id: '5',
    conversationId: '3',
    senderId: '1',
    senderName: 'Association Refuge du Cœur',
    content: 'Bonjour Julie ! Oui, Milo vit très bien en appartement. Il est calme et n\'a pas besoin de beaucoup d\'espace.',
    timestamp: new Date('2024-01-30T16:30:00'),
    read: false
  }
];

// Predefined messages for quick responses
export const mockPredefinedMessages: PredefinedMessage[] = [
  // Messages for associations
  {
    id: '1',
    content: 'Bonjour, merci pour votre intérêt. Pouvez-vous préciser vos dates de disponibilité ?',
    forUserType: 'association',
    category: 'availability'
  },
  {
    id: '2',
    content: 'Avez-vous déjà une expérience avec ce type d\'animal ?',
    forUserType: 'association',
    category: 'experience'
  },
  {
    id: '3',
    content: 'L\'animal nécessite-t-il des soins particuliers selon vous ?',
    forUserType: 'association',
    category: 'care'
  },
  {
    id: '4',
    content: 'Nous envoyons un contrat à signer une fois la garde validée.',
    forUserType: 'association',
    category: 'process'
  },
  {
    id: '5',
    content: 'Merci de fournir un justificatif d\'identité pour valider votre profil.',
    forUserType: 'association',
    category: 'documentation'
  },
  {
    id: '6',
    content: 'Pouvez-vous confirmer que vous disposez d\'un espace adapté pour l\'animal ?',
    forUserType: 'association',
    category: 'housing'
  },
  {
    id: '7',
    content: 'La famille d\'accueil est responsable de la nourriture et des soins courants, l\'association prend en charge les frais vétérinaires.',
    forUserType: 'association',
    category: 'responsibilities'
  },
  {
    id: '8',
    content: 'Nous organisons une visite de pré-accueil pour faire connaissance avec l\'animal.',
    forUserType: 'association',
    category: 'process'
  },
  
  // Messages for families
  {
    id: '9',
    content: 'Bonjour, je suis très intéressé(e) par cet animal. Pouvez-vous me donner plus d\'informations ?',
    forUserType: 'family',
    category: 'interest'
  },
  {
    id: '10',
    content: 'Quels sont les soins spécifiques dont l\'animal a besoin ?',
    forUserType: 'family',
    category: 'care'
  },
  {
    id: '11',
    content: 'L\'animal s\'entend-il bien avec les enfants/autres animaux ?',
    forUserType: 'family',
    category: 'compatibility'
  },
  {
    id: '12',
    content: 'Je suis disponible pour accueillir l\'animal à partir de [date]. Cela vous convient-il ?',
    forUserType: 'family',
    category: 'availability'
  },
  {
    id: '13',
    content: 'Pouvons-nous organiser une rencontre avant l\'accueil ?',
    forUserType: 'family',
    category: 'meeting'
  },
  {
    id: '14',
    content: 'Quels documents dois-je fournir pour finaliser l\'accueil ?',
    forUserType: 'family',
    category: 'documentation'
  },
  
  // Common messages for both
  {
    id: '15',
    content: 'Merci pour votre réponse rapide !',
    forUserType: 'all',
    category: 'courtesy'
  },
  {
    id: '16',
    content: 'Je vous recontacte très bientôt avec plus d\'informations.',
    forUserType: 'all',
    category: 'follow-up'
  },
  {
    id: '17',
    content: 'N\'hésitez pas si vous avez d\'autres questions !',
    forUserType: 'all',
    category: 'courtesy'
  }
];

// Utility function to get predefined messages for a specific user type
export const getPredefinedMessagesForUser = (userType: 'family' | 'association'): PredefinedMessage[] => {
  return mockPredefinedMessages.filter(message => 
    message.forUserType === userType || message.forUserType === 'all'
  );
};