import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Heart, PawPrint } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { AdoptionRequestForm } from '../components/adoption/AdoptionRequestForm';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Animal, FamilyAdoptionProfile, AdoptionRequest as AdoptionRequestType } from '../types';
import { mockAnimals, saveAdoptionRequest } from '../data/mockData';

export function AdoptionRequest() {
  const { animalId } = useParams<{ animalId: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [animal, setAnimal] = useState<Animal | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const requestType = (searchParams.get('type') as 'foster' | 'adopt') || 'adopt';
  const isForFostering = requestType === 'foster';

  useEffect(() => {
    if (!animalId) {
      navigate('/search');
      return;
    }

    // Find the animal
    const foundAnimal = mockAnimals.find(a => a.id === animalId);
    if (foundAnimal && foundAnimal.status === 'available') {
      setAnimal(foundAnimal);
    } else {
      setError('Animal non trouvé ou non disponible pour adoption');
    }
  }, [animalId, navigate]);

  const handleSubmit = async (familyAdoptionProfile: FamilyAdoptionProfile) => {
    if (!user || !animal) return;

    setIsLoading(true);
    setError('');

    try {
      // Create adoption request
      const adoptionRequest: AdoptionRequestType = {
        id: Date.now().toString(),
        requestType,
        animalId: animal.id,
        animalName: animal.name,
        familyId: user.id,
        familyName: user.name,
        associationId: animal.associationId,
        associationName: animal.associationName,
        status: 'pending',
        familyAdoptionProfile,
        submittedAt: new Date()
      };

      // Save the adoption request
      await saveAdoptionRequest(adoptionRequest);

      // Navigate to success page or dashboard
      navigate('/dashboard', {
        state: {
          message: `Votre demande ${isForFostering ? 'd\'accueil' : 'd\'adoption'} pour ${animal.name} a été envoyée avec succès !`,
          type: 'success'
        }
      });
    } catch (err) {
      setError(`Une erreur est survenue lors de l'envoi de votre demande ${isForFostering ? 'd\'accueil' : 'd\'adoption'}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    if (animal) {
      navigate(`/animal/${animal.id}`);
    } else {
      navigate('/search');
    }
  };

  if (!user || user.type !== 'family') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="text-center max-w-md">
          <div className="py-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Accès restreint</h2>
            <p className="text-gray-600 mb-4">
              Seules les familles d'accueil peuvent faire des demandes {isForFostering ? 'd\'accueil' : 'd\'adoption'}.
            </p>
            <Button onClick={() => navigate('/search')}>
              Retour à la recherche
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="text-center max-w-md">
          <div className="py-8">
            <div className="w-16 h-16 bg-error-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <PawPrint className="h-8 w-8 text-error-600" />
            </div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Erreur</h2>
            <p className="text-gray-600 mb-4">{error}</p>
            <Button onClick={() => navigate('/search')}>
              Retour à la recherche
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  if (!animal) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            icon={ArrowLeft}
            onClick={handleCancel}
            className="mb-4"
          >
            Retour à la fiche
          </Button>
          
          <div className="flex items-center space-x-4">
            <img
              src={animal.photos[0]}
              alt={animal.name}
              className="w-16 h-16 rounded-lg object-cover border-2 border-gray-200"
            />
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center space-x-2">
                <Heart className="h-8 w-8 text-error-500" />
                <span>Demande {isForFostering ? 'd\'accueil' : 'd\'adoption'} pour {animal.name}</span>
              </h1>
              <p className="text-gray-600">
                Remplissez ce formulaire détaillé pour postuler {isForFostering ? 'à l\'accueil' : 'à l\'adoption'} de {animal.name}
              </p>
            </div>
          </div>
        </div>

        {/* Important notice */}
        <Card className="mb-8 bg-blue-50 border-blue-200">
          <div className="flex items-start space-x-3">
            <div className="bg-blue-100 p-2 rounded-full">
              <PawPrint className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <h3 className="font-semibold text-blue-900 mb-2">
                {isForFostering ? 'Demande d\'accueil - Engagement temporaire' : 'Demande d\'adoption - Engagement à vie'}
              </h3>
              <p className="text-blue-800 text-sm mb-2">
                {isForFostering 
                  ? `L'accueil temporaire consiste à prendre soin de ${animal.name} pendant une période déterminée, en attendant qu'il trouve une famille définitive.`
                  : `L'adoption est différente de l'accueil temporaire. Vous vous engagez à prendre soin de ${animal.name} pour toute sa vie (10-15 ans en moyenne).`
                }
              </p>
              <ul className="text-blue-700 text-sm space-y-1">
                {isForFostering ? (
                  <>
                    <li>• L'accueil peut durer de quelques semaines à plusieurs mois</li>
                    <li>• L'association reste propriétaire de l'animal</li>
                    <li>• Les frais vétérinaires sont généralement pris en charge par l'association</li>
                    <li>• Vous aidez l'animal à se socialiser et à retrouver confiance</li>
                  </>
                ) : (
                  <>
                    <li>• Ce formulaire est plus détaillé qu'une demande d'accueil</li>
                    <li>• Un contrat d'adoption officiel sera établi si votre candidature est retenue</li>
                  </>
                )}
                <li>• L'association étudiera votre candidature avec attention</li>
                <li>• Des visites de pré-adoption peuvent être organisées</li>
              </ul>
            </div>
          </div>
        </Card>

        {/* Form */}
        <AdoptionRequestForm
          onSubmit={handleSubmit}
          onCancel={handleCancel}
          isLoading={isLoading}
        />
      </div>
    </div>
  );
}