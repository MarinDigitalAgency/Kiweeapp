// Utilitaires pour la géolocalisation et le calcul de distances

/**
 * Calcule la distance entre deux points géographiques en utilisant la formule de Haversine
 * @param lat1 Latitude du premier point
 * @param lon1 Longitude du premier point
 * @param lat2 Latitude du deuxième point
 * @param lon2 Longitude du deuxième point
 * @returns Distance en kilomètres
 */
export function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Rayon de la Terre en kilomètres
  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);
  
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;
  
  return Math.round(distance * 100) / 100; // Arrondi à 2 décimales
}

/**
 * Convertit des degrés en radians
 */
function toRadians(degrees: number): number {
  return degrees * (Math.PI / 180);
}

/**
 * Obtient la position actuelle de l'utilisateur
 * @returns Promise avec les coordonnées ou une erreur
 */
export function getCurrentPosition(): Promise<GeolocationPosition> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('La géolocalisation n\'est pas supportée par ce navigateur'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => resolve(position),
      (error) => {
        switch (error.code) {
          case error.PERMISSION_DENIED:
            reject(new Error('L\'accès à la géolocalisation a été refusé'));
            break;
          case error.POSITION_UNAVAILABLE:
            reject(new Error('Les informations de localisation ne sont pas disponibles'));
            break;
          case error.TIMEOUT:
            reject(new Error('La demande de géolocalisation a expiré'));
            break;
          default:
            reject(new Error('Une erreur inconnue s\'est produite'));
            break;
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000 // 5 minutes
      }
    );
  });
}

/**
 * Génère les points d'un cercle pour l'affichage sur la carte
 * @param centerLat Latitude du centre
 * @param centerLon Longitude du centre
 * @param radiusKm Rayon en kilomètres
 * @param points Nombre de points pour dessiner le cercle (par défaut 64)
 * @returns Array de coordonnées [longitude, latitude]
 */
export function generateCircleCoordinates(
  centerLat: number,
  centerLon: number,
  radiusKm: number,
  points: number = 64
): number[][] {
  const coordinates: number[][] = [];
  const earthRadius = 6371; // Rayon de la Terre en km
  
  for (let i = 0; i <= points; i++) {
    const angle = (i * 360) / points;
    const angleRad = toRadians(angle);
    
    // Calcul des coordonnées du point sur le cercle
    const lat = Math.asin(
      Math.sin(toRadians(centerLat)) * Math.cos(radiusKm / earthRadius) +
      Math.cos(toRadians(centerLat)) * Math.sin(radiusKm / earthRadius) * Math.cos(angleRad)
    );
    
    const lon = toRadians(centerLon) + Math.atan2(
      Math.sin(angleRad) * Math.sin(radiusKm / earthRadius) * Math.cos(toRadians(centerLat)),
      Math.cos(radiusKm / earthRadius) - Math.sin(toRadians(centerLat)) * Math.sin(lat)
    );
    
    coordinates.push([lon * (180 / Math.PI), lat * (180 / Math.PI)]);
  }
  
  return coordinates;
}

/**
 * Géocode une adresse en coordonnées (simulation pour la démo)
 * En production, vous utiliseriez une API comme Mapbox Geocoding
 */
export async function geocodeAddress(address: string): Promise<{ lat: number; lon: number; displayName: string } | null> {
  // Simulation de géocodage pour quelques villes françaises
  const mockGeocode: Record<string, { lat: number; lon: number; displayName: string }> = {
    'lyon': { lat: 45.7640, lon: 4.8357, displayName: 'Lyon, France' },
    'paris': { lat: 48.8566, lon: 2.3522, displayName: 'Paris, France' },
    'marseille': { lat: 43.2965, lon: 5.3698, displayName: 'Marseille, France' },
    'toulouse': { lat: 43.6047, lon: 1.4442, displayName: 'Toulouse, France' },
    'nice': { lat: 43.7102, lon: 7.2620, displayName: 'Nice, France' },
    'nantes': { lat: 47.2184, lon: -1.5536, displayName: 'Nantes, France' },
    'montpellier': { lat: 43.6110, lon: 3.8767, displayName: 'Montpellier, France' },
    'strasbourg': { lat: 48.5734, lon: 7.7521, displayName: 'Strasbourg, France' },
    'bordeaux': { lat: 44.8378, lon: -0.5792, displayName: 'Bordeaux, France' },
    'lille': { lat: 50.6292, lon: 3.0573, displayName: 'Lille, France' }
  };

  const normalizedAddress = address.toLowerCase().trim();
  
  // Recherche exacte
  if (mockGeocode[normalizedAddress]) {
    return mockGeocode[normalizedAddress];
  }
  
  // Recherche partielle
  for (const [city, coords] of Object.entries(mockGeocode)) {
    if (city.includes(normalizedAddress) || normalizedAddress.includes(city)) {
      return coords;
    }
  }
  
  // Si aucune correspondance, retourner Lyon par défaut
  return mockGeocode['lyon'];
}