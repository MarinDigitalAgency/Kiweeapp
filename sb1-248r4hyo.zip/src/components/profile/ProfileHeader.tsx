import React from 'react';
import { Camera, Shield, Star, Award } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Card } from '../ui/Card';

export function ProfileHeader() {
  const { user } = useAuth();

  if (!user) return null;

  const getCompletionColor = (percentage: number) => {
    if (percentage >= 80) return 'text-success-600';
    if (percentage >= 50) return 'text-warning-600';
    return 'text-error-600';
  };

  const badges = user.profile?.badges || {
    isProfileVerified: false,
    isEmailVerified: true,
    isPhoneVerified: false,
    isTopFosterFamily: false,
    isCertifiedAssociation: false,
    hasCompletedProfile: false
  };

  const completionPercentage = user.profile?.completionPercentage || 25;

  return (
    <Card>
      <div className="flex items-start space-x-6">
        {/* Avatar */}
        <div className="relative">
          <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
            {user.avatar ? (
              <img
                src={user.avatar}
                alt={user.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <span className="text-2xl font-bold text-gray-600">
                {user.name.charAt(0).toUpperCase()}
              </span>
            )}
          </div>
          <button className="absolute bottom-0 right-0 bg-primary-600 text-white p-2 rounded-full hover:bg-primary-700 transition-colors">
            <Camera className="h-4 w-4" />
          </button>
        </div>

        {/* User Info */}
        <div className="flex-1">
          <div className="flex items-center space-x-3 mb-2">
            <h1 className="text-2xl font-bold text-gray-900">{user.name}</h1>
            {badges.isProfileVerified && (
              <Badge variant="success" className="flex items-center space-x-1">
                <Shield className="h-3 w-3" />
                <span>Vérifié</span>
              </Badge>
            )}
          </div>

          <p className="text-gray-600 mb-1">{user.email}</p>
          {user.location && (
            <p className="text-gray-500 text-sm mb-3">{user.location}</p>
          )}

          {/* Badges */}
          <div className="flex flex-wrap gap-2 mb-4">
            {badges.isEmailVerified && (
              <Badge variant="success" size="sm">Email vérifié</Badge>
            )}
            {badges.isPhoneVerified && (
              <Badge variant="success" size="sm">Téléphone vérifié</Badge>
            )}
            {badges.isTopFosterFamily && user.type === 'family' && (
              <Badge variant="secondary" size="sm" className="flex items-center space-x-1">
                <Star className="h-3 w-3" />
                <span>Top Famille d'accueil</span>
              </Badge>
            )}
            {badges.isCertifiedAssociation && user.type === 'association' && (
              <Badge variant="primary" size="sm" className="flex items-center space-x-1">
                <Award className="h-3 w-3" />
                <span>Association certifiée</span>
              </Badge>
            )}
          </div>

          {/* Profile Completion */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">
                Profil complété
              </span>
              <span className={`text-sm font-semibold ${getCompletionColor(completionPercentage)}`}>
                {completionPercentage}%
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className={`h-2 rounded-full transition-all duration-300 ${
                  completionPercentage >= 80
                    ? 'bg-success-500'
                    : completionPercentage >= 50
                    ? 'bg-warning-500'
                    : 'bg-error-500'
                }`}
                style={{ width: `${completionPercentage}%` }}
              />
            </div>
            {completionPercentage < 100 && (
              <p className="text-xs text-gray-500 mt-1">
                Complétez votre profil pour améliorer votre visibilité
              </p>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col space-y-2">
          <Button variant="outline" size="sm">
            Modifier le profil
          </Button>
          {user.type === 'family' && (
            <Button variant="outline" size="sm">
              Voir comme association
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
}