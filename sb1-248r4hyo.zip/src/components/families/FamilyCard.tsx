import React from 'react';
import { MapPin, Star, Shield, MessageCircle, Home, Users, Heart, Award } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { User } from '../../types';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface FamilyCardProps {
  family: User;
  onContact?: (familyId: string) => void;
  showActions?: boolean;
}

export function FamilyCard({ 
  family, 
  onContact, 
  showActions = true 
}: FamilyCardProps) {
  const navigate = useNavigate();

  const profile = family.profile?.familyProfile;
  const badges = family.profile?.badges;

  const getHousingTypeText = (type: string) => {
    const typeMap = {
      maison: 'Maison',
      appartement: 'Appartement',
      studio: 'Studio',
      chambre: 'Chambre',
      other: 'Autre'
    };
    return typeMap[type as keyof typeof typeMap] || type;
  };

  const getExperienceLevelText = (level: string) => {
    const levelMap = {
      beginner: 'Débutant',
      intermediate: 'Intermédiaire',
      experienced: 'Expérimenté'
    };
    return levelMap[level as keyof typeof levelMap] || level;
  };

  const getAcceptedAnimalTypes = () => {
    if (!profile?.acceptedAnimalTypes) return [];
    
    const types = [];
    if (profile.acceptedAnimalTypes.dogs) types.push('Chiens');
    if (profile.acceptedAnimalTypes.cats) types.push('Chats');
    if (profile.acceptedAnimalTypes.nac) types.push('NAC');
    if (profile.acceptedAnimalTypes.reptiles) types.push('Reptiles');
    if (profile.acceptedAnimalTypes.labAnimals) types.push('Animaux de labo');
    if (profile.acceptedAnimalTypes.farmAnimals) types.push('Animaux de ferme');
    
    return types;
  };

  const handleContactClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onContact?.(family.id);
  };

  const acceptedTypes = getAcceptedAnimalTypes();

  return (
    <Card padding="none" hover className="overflow-hidden">
      {/* Header avec photo de profil */}
      <div className="relative bg-gradient-to-r from-primary-500 to-secondary-500 p-6 text-white">
        <div className="flex items-start space-x-4">
          <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
            {family.avatar ? (
              <img
                src={family.avatar}
                alt={family.name}
                className="w-full h-full rounded-full object-cover"
              />
            ) : (
              <span className="text-2xl font-bold">
                {family.name.charAt(0).toUpperCase()}
              </span>
            )}
          </div>
          
          <div className="flex-1">
            <h3 className="text-xl font-bold">{family.name}</h3>
            <div className="flex items-center space-x-1 mt-1">
              <MapPin className="h-4 w-4" />
              <span className="text-sm">{family.location}</span>
            </div>
            
            {/* Badges de confiance */}
            <div className="flex items-center space-x-2 mt-2">
              {family.verified && (
                <Badge variant="success" size="sm" className="bg-white/20 text-white border-white/30">
                  <Shield className="h-3 w-3 mr-1" />
                  Vérifié
                </Badge>
              )}
              {badges?.isTopFosterFamily && (
                <Badge variant="warning" size="sm" className="bg-white/20 text-white border-white/30">
                  <Star className="h-3 w-3 mr-1" />
                  Top FA
                </Badge>
              )}
              {badges?.isExperiencedFA && (
                <Badge variant="secondary" size="sm" className="bg-white/20 text-white border-white/30">
                  <Award className="h-3 w-3 mr-1" />
                  Expérimenté
                </Badge>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Contenu principal */}
      <div className="p-6 space-y-4">
        {/* Informations de logement */}
        {profile && (
          <div>
            <h4 className="font-medium text-gray-900 mb-2 flex items-center space-x-2">
              <Home className="h-4 w-4 text-primary-600" />
              <span>Logement</span>
            </h4>
            <div className="space-y-1 text-sm text-gray-600">
              <p>{getHousingTypeText(profile.housingType)}</p>
              {profile.hasGarden && (
                <p className="text-success-600">✓ Jardin disponible</p>
              )}
              {profile.hasDedicatedRoom && (
                <p className="text-success-600">✓ Pièce dédiée</p>
              )}
            </div>
          </div>
        )}

        {/* Types d'animaux acceptés */}
        {acceptedTypes.length > 0 && (
          <div>
            <h4 className="font-medium text-gray-900 mb-2 flex items-center space-x-2">
              <Heart className="h-4 w-4 text-primary-600" />
              <span>Animaux acceptés</span>
            </h4>
            <div className="flex flex-wrap gap-1">
              {acceptedTypes.map((type, index) => (
                <Badge key={index} variant="primary" size="sm">
                  {type}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Expérience */}
        {profile && (
          <div>
            <h4 className="font-medium text-gray-900 mb-2 flex items-center space-x-2">
              <Users className="h-4 w-4 text-primary-600" />
              <span>Expérience & Foyer</span>
            </h4>
            <div className="space-y-1 text-sm text-gray-600">
              <p>Niveau : {getExperienceLevelText(profile.experienceLevel)}</p>
              <p>{profile.previousFosterCount} accueil{profile.previousFosterCount > 1 ? 's' : ''} précédent{profile.previousFosterCount > 1 ? 's' : ''}</p>
              
              {/* Affichage des membres du foyer */}
              <div className="mt-2 space-y-1">
                {profile.compatibility?.withHumans > 0 && (
                  <p>{profile.compatibility.withHumans} adulte{profile.compatibility.withHumans > 1 ? 's' : ''}</p>
                )}
                {profile.compatibility?.withChildren > 0 && (
                  <p>{profile.compatibility.withChildren} enfant{profile.compatibility.withChildren > 1 ? 's' : ''}</p>
                )}
                {profile.compatibility?.withCats > 0 && (
                  <p>{profile.compatibility.withCats} chat{profile.compatibility.withCats > 1 ? 's' : ''}</p>
                )}
                {profile.compatibility?.withDogs > 0 && (
                  <p>{profile.compatibility.withDogs} chien{profile.compatibility.withDogs > 1 ? 's' : ''}</p>
                )}
                {profile.compatibility?.withOtherAnimals > 0 && (
                  <p>{profile.compatibility.withOtherAnimals} autre{profile.compatibility.withOtherAnimals > 1 ? 's' : ''} animal/aux</p>
                )}
              </div>
              
              {profile.specializations.length > 0 && (
                <div>
                  <span className="font-medium">Spécialisations :</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {profile.specializations.map((spec, index) => (
                      <Badge key={index} variant="secondary" size="sm">
                        {spec}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Capacités spéciales */}
        {profile && (
          <div className="flex flex-wrap gap-2 text-xs">
            {profile.canProvideMedicalCare && (
              <Badge variant="success" size="sm">Soins médicaux</Badge>
            )}
            {profile.hasVehicle && (
              <Badge variant="success" size="sm">Véhiculé</Badge>
            )}
            {profile.compatibility.withChildren && (
              <Badge variant="success" size="sm">OK enfants</Badge>
            )}
          </div>
        )}

        {/* Informations de contact */}
        <div className="flex items-center justify-between text-sm text-gray-500 pt-2 border-t border-gray-100">
          <div>
            <span>Membre depuis {family.createdAt.getFullYear()}</span>
          </div>
          <div className="flex items-center space-x-1">
            <span className="text-success-600">●</span>
            <span>Disponible</span>
          </div>
        </div>

        {/* Actions */}
        {showActions && (
          <div className="pt-2 border-t border-gray-100">
            <Button
              size="sm"
              icon={MessageCircle}
              onClick={handleContactClick}
              className="w-full"
            >
              Contacter cette famille
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
}