import React from 'react';
import { Award, ArrowRight, ArrowLeft, SkipForward, Plus, X } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Input } from '../ui/Input';
import { FamilyProfile } from '../../types';

interface OnboardingExperienceProps {
  data: Partial<FamilyProfile>;
  onUpdate: (updates: Partial<FamilyProfile>) => void;
  onNext: () => void;
  onPrev: () => void;
  onSkip: () => void;
}

export function OnboardingExperience({
  data,
  onUpdate,
  onNext,
  onPrev,
  onSkip
}: OnboardingExperienceProps) {
  const addSpecialization = (specialization: string) => {
    if (specialization.trim() && !data.specializations?.includes(specialization.trim())) {
      onUpdate({
        specializations: [...(data.specializations || []), specialization.trim()]
      });
    }
  };

  const removeSpecialization = (index: number) => {
    const newSpecializations = [...(data.specializations || [])];
    newSpecializations.splice(index, 1);
    onUpdate({ specializations: newSpecializations });
  };

  const experienceLevels = [
    {
      value: 'beginner',
      label: 'Débutant',
      description: 'Première expérience d\'accueil',
      emoji: '🌱'
    },
    {
      value: 'intermediate',
      label: 'Intermédiaire',
      description: 'Quelques expériences d\'accueil',
      emoji: '🌿'
    },
    {
      value: 'experienced',
      label: 'Expérimenté',
      description: 'Nombreuses expériences d\'accueil',
      emoji: '🌳'
    }
  ];

  const animalExperienceOptions = [
    {
      value: 'beginner',
      label: 'Débutant',
      description: 'Je n\'ai jamais eu d\'animaux',
      emoji: '🌱'
    },
    {
      value: 'intermediate',
      label: 'Intermédiaire',
      description: 'J\'ai eu des animaux étant petit et j\'ai déjà gardé des animaux',
      emoji: '🌿'
    },
    {
      value: 'expert',
      label: 'Expert',
      description: 'J\'ai déjà été famille d\'accueil, les animaux sont ma passion',
      emoji: '🌳'
    },
    {
      value: 'professional',
      label: 'Pro',
      description: 'Je travaille pour les animaux et ma vie y est consacrée',
      emoji: '🏆'
    }
  ];

  const commonSpecializations = [
    'Animaux seniors',
    'Soins médicaux',
    'Problèmes comportementaux',
    'Socialisation',
    'Animaux craintifs',
    'Rééducation',
    'Animaux handicapés',
    'Urgences'
  ];

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-kiweetoTeal-100 rounded-full flex items-center justify-center mx-auto">
          <Award className="h-8 w-8 text-kiweetoTeal-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            Votre expérience avec les animaux
          </h1>
          <p className="text-gray-600">
            Partagez votre expérience pour que nous puissions vous proposer des missions adaptées.
          </p>
        </div>
      </div>

      {/* Experience Level */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Niveau d'expérience</h3>
        <div className="space-y-3">
          {experienceLevels.map((level) => (
            <label
              key={level.value}
              className={`flex items-center p-4 border-2 rounded-lg cursor-pointer transition-all ${
                data.experienceLevel === level.value
                  ? 'border-kiweetoTeal-500 bg-kiweetoTeal-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <input
                type="radio"
                name="experienceLevel"
                value={level.value}
                checked={data.experienceLevel === level.value}
                onChange={(e) => onUpdate({ experienceLevel: e.target.value as FamilyProfile['experienceLevel'] })}
                className="sr-only"
              />
              <div className="flex items-center space-x-4 flex-1">
                <span className="text-2xl">{level.emoji}</span>
                <div>
                  <div className="font-medium text-gray-900">{level.label}</div>
                  <div className="text-sm text-gray-500">{level.description}</div>
                </div>
              </div>
            </label>
          ))}
        </div>
      </Card>

      {/* Animal Experience History */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Passif avec les animaux</h3>
        <div className="space-y-3">
          {animalExperienceOptions.map((option) => (
            <label
              key={option.value}
              className={`flex items-center p-4 border-2 rounded-lg cursor-pointer transition-all ${
                data.animalExperienceHistory === option.value
                  ? 'border-kiweetoTeal-500 bg-kiweetoTeal-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <input
                type="radio"
                name="animalExperienceHistory"
                value={option.value}
                checked={data.animalExperienceHistory === option.value}
                onChange={(e) => onUpdate({ animalExperienceHistory: e.target.value as FamilyProfile['animalExperienceHistory'] })}
                className="sr-only"
              />
              <div className="flex items-center space-x-4 flex-1">
                <span className="text-2xl">{option.emoji}</span>
                <div>
                  <div className="font-medium text-gray-900">{option.label}</div>
                  <div className="text-sm text-gray-500">{option.description}</div>
                </div>
              </div>
            </label>
          ))}
        </div>
      </Card>

      {/* Previous Foster Count */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Expérience d'accueil</h3>
        <div className="space-y-4">
          <Input
            label="Nombre d'accueils précédents"
            type="number"
            value={data.previousFosterCount || 0}
            onChange={(e) => onUpdate({ previousFosterCount: parseInt(e.target.value) || 0 })}
            min="0"
            placeholder="0"
          />
          <p className="text-sm text-gray-500">
            Incluez tous vos accueils d'animaux, même informels (famille, amis, etc.)
          </p>
        </div>
      </Card>

      {/* Capabilities */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Vos capacités</h3>
        <div className="space-y-4">
          <label className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
            <div className="flex items-center space-x-3">
              <span className="text-xl">💊</span>
              <div>
                <div className="font-medium text-gray-900">Soins médicaux</div>
                <div className="text-sm text-gray-500">Donner des médicaments, soins post-opératoires</div>
              </div>
            </div>
            <input
              type="checkbox"
              checked={data.canProvideMedicalCare || false}
              onChange={(e) => onUpdate({ canProvideMedicalCare: e.target.checked })}
              className="rounded border-gray-300 text-kiweetoTeal-600 focus:ring-kiweetoTeal-500"
            />
          </label>

          <label className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
            <div className="flex items-center space-x-3">
              <span className="text-xl">🚗</span>
              <div>
                <div className="font-medium text-gray-900">Véhiculé(e)</div>
                <div className="text-sm text-gray-500">Pour les rendez-vous vétérinaires, adoptions</div>
              </div>
            </div>
            <input
              type="checkbox"
              checked={data.hasVehicle || false}
              onChange={(e) => onUpdate({ hasVehicle: e.target.checked })}
              className="rounded border-gray-300 text-kiweetoTeal-600 focus:ring-kiweetoTeal-500"
            />
          </label>
        </div>
      </Card>

      {/* Specializations */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Spécialisations (optionnel)</h3>
        <p className="text-sm text-gray-600 mb-4">
          Sélectionnez ou ajoutez vos domaines de spécialisation
        </p>
        
        {/* Common specializations */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mb-4">
          {commonSpecializations.map((spec) => (
            <button
              key={spec}
              onClick={() => addSpecialization(spec)}
              disabled={data.specializations?.includes(spec)}
              className={`p-2 text-sm border rounded-lg transition-all ${
                data.specializations?.includes(spec)
                  ? 'border-kiweetoTeal-500 bg-kiweetoTeal-50 text-kiweetoTeal-700'
                  : 'border-gray-200 hover:border-gray-300 text-gray-700'
              }`}
            >
              <Plus className="h-3 w-3 inline mr-1" />
              {spec}
            </button>
          ))}
        </div>

        {/* Selected specializations */}
        {data.specializations && data.specializations.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-medium text-gray-900">Vos spécialisations :</h4>
            <div className="flex flex-wrap gap-2">
              {data.specializations.map((spec, index) => (
                <div
                  key={index}
                  className="flex items-center space-x-1 bg-kiweetoTeal-100 text-kiweetoTeal-800 px-3 py-1 rounded-full text-sm"
                >
                  <span>{spec}</span>
                  <button
                    onClick={() => removeSpecialization(index)}
                    className="text-kiweetoTeal-600 hover:text-kiweetoTeal-800"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </Card>

      {/* Encouragement */}
      {data.experienceLevel && (
        <Card className="bg-kiweetoTeal-50 border-kiweetoTeal-200">
          <div className="text-center">
            {data.animalExperienceHistory === 'beginner' && (
              <p className="text-kiweetoTeal-800 font-medium">
                🌱 Tout le monde a commencé quelque part ! Votre motivation est votre plus grand atout.
              </p>
            )}
            {data.animalExperienceHistory === 'intermediate' && (
              <p className="text-kiweetoTeal-800 font-medium">
                🌿 Votre expérience personnelle avec les animaux sera précieuse !
              </p>
            )}
            {data.animalExperienceHistory === 'expert' && (
              <p className="text-kiweetoTeal-800 font-medium">
                🌳 Votre passion et votre expérience seront un atout formidable pour les animaux !
              </p>
            )}
            {data.animalExperienceHistory === 'professional' && (
              <p className="text-kiweetoTeal-800 font-medium">
                🏆 Votre expertise professionnelle sera inestimable pour les animaux les plus difficiles !
              </p>
            )}
          </div>
        </Card>
      )}

      {/* Navigation */}
      <div className="flex justify-between items-center pt-6">
        <Button
          variant="outline"
          icon={ArrowLeft}
          onClick={onPrev}
        >
          Précédent
        </Button>

        <Button
          variant="ghost"
          icon={SkipForward}
          onClick={onSkip}
          className="text-gray-500"
        >
          Passer cette étape
        </Button>

        <Button
          variant="kiweetoTeal"
          icon={ArrowRight}
          iconPosition="right"
          onClick={onNext}
        >
          Suivant
        </Button>
      </div>
    </div>
  );
}