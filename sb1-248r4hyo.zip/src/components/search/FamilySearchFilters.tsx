import React from 'react';
import { Search, Filter, X, MapPin, Navigation, Home, Users, Heart } from 'lucide-react';
import { FamilySearchFilters as FamilySearchFiltersType } from '../../types';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';

interface FamilySearchFiltersProps {
  filters: FamilySearchFiltersType;
  onFiltersChange: (filters: FamilySearchFiltersType) => void;
  onClearFilters: () => void;
  onGeolocation: () => void;
  showAdvanced?: boolean;
  onToggleAdvanced?: () => void;
  isGeolocating?: boolean;
}

export function FamilySearchFilters({
  filters,
  onFiltersChange,
  onClearFilters,
  onGeolocation,
  showAdvanced = false,
  onToggleAdvanced,
  isGeolocating = false
}: FamilySearchFiltersProps) {
  const handleFilterChange = (key: keyof FamilySearchFiltersType, value: any) => {
    onFiltersChange({
      ...filters,
      [key]: value
    });
  };

  const hasActiveFilters = Object.values(filters).some(value => 
    value !== undefined && value !== null && value !== ''
  );

  const radiusOptions = [
    { value: 5, label: '5 km' },
    { value: 10, label: '10 km' },
    { value: 20, label: '20 km' },
    { value: 50, label: '50 km' },
    { value: 100, label: '100 km' }
  ];

  return (
    <Card className="space-y-4">
      {/* Recherche principale */}
      <div className="flex space-x-2">
        <div className="flex-1">
          <Input
            placeholder="Rechercher par nom, ville..."
            icon={Search}
            value={filters.location || ''}
            onChange={(e) => handleFilterChange('location', e.target.value)}
          />
        </div>
        <Button
          variant="outline"
          icon={Filter}
          onClick={onToggleAdvanced}
          className={showAdvanced ? 'bg-primary-50 border-primary-200' : ''}
        >
          Filtres
        </Button>
        {hasActiveFilters && (
          <Button
            variant="ghost"
            icon={X}
            onClick={onClearFilters}
            className="text-gray-500"
          >
            Effacer
          </Button>
        )}
      </div>

      {/* Recherche géographique */}
      <div className="space-y-3">
        <div className="flex space-x-2">
          <div className="flex-1">
            <Input
              placeholder="Adresse ou ville..."
              icon={MapPin}
              value={filters.location || ''}
              onChange={(e) => handleFilterChange('location', e.target.value)}
            />
          </div>
          <Button
            variant="outline"
            icon={Navigation}
            onClick={onGeolocation}
            loading={isGeolocating}
            className="px-4"
          >
            Autour de moi
          </Button>
        </div>

        <div className="flex items-center space-x-3">
          <label className="text-sm font-medium text-gray-700 whitespace-nowrap">
            Rayon :
          </label>
          <select
            value={filters.radius || ''}
            onChange={(e) => handleFilterChange('radius', e.target.value ? parseInt(e.target.value) : undefined)}
            className="flex-1 rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 text-sm"
          >
            <option value="">Sélectionner</option>
            {radiusOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>

        {filters.centerLatitude && filters.centerLongitude && filters.radius && (
          <div className="text-sm text-gray-600 bg-primary-50 p-2 rounded-lg">
            📍 Recherche dans un rayon de {filters.radius} km
            {filters.location && ` autour de ${filters.location}`}
          </div>
        )}
      </div>

      {/* Filtres avancés */}
      {showAdvanced && (
        <div className="space-y-4 pt-4 border-t border-gray-100">
          {/* Type de logement */}
          <div>
            <h4 className="font-medium text-gray-900 mb-3 flex items-center space-x-2">
              <Home className="h-4 w-4 text-primary-600" />
              <span>Logement</span>
            </h4>
            
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Type de logement
                </label>
                <select
                  value={filters.housingType || ''}
                  onChange={(e) => handleFilterChange('housingType', e.target.value || undefined)}
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                >
                  <option value="">Tous</option>
                  <option value="maison">Maison</option>
                  <option value="appartement">Appartement</option>
                  <option value="studio">Studio</option>
                  <option value="chambre">Chambre</option>
                  <option value="other">Autre</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.hasGarden || false}
                    onChange={(e) => handleFilterChange('hasGarden', e.target.checked ? true : undefined)}
                    className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Avec jardin</span>
                </label>

                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.hasDedicatedRoom || false}
                    onChange={(e) => handleFilterChange('hasDedicatedRoom', e.target.checked ? true : undefined)}
                    className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Pièce dédiée</span>
                </label>
              </div>
            </div>
          </div>

          {/* Types d'animaux acceptés */}
          <div>
            <h4 className="font-medium text-gray-900 mb-3 flex items-center space-x-2">
              <Heart className="h-4 w-4 text-primary-600" />
              <span>Types d'animaux acceptés</span>
            </h4>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={filters.acceptedAnimalTypes?.dogs || false}
                  onChange={(e) => handleFilterChange('acceptedAnimalTypes', {
                    ...filters.acceptedAnimalTypes,
                    dogs: e.target.checked ? true : undefined
                  })}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">Chiens</span>
              </label>

              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={filters.acceptedAnimalTypes?.cats || false}
                  onChange={(e) => handleFilterChange('acceptedAnimalTypes', {
                    ...filters.acceptedAnimalTypes,
                    cats: e.target.checked ? true : undefined
                  })}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">Chats</span>
              </label>

              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={filters.acceptedAnimalTypes?.nac || false}
                  onChange={(e) => handleFilterChange('acceptedAnimalTypes', {
                    ...filters.acceptedAnimalTypes,
                    nac: e.target.checked ? true : undefined
                  })}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">NAC</span>
              </label>

              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={filters.acceptedAnimalTypes?.reptiles || false}
                  onChange={(e) => handleFilterChange('acceptedAnimalTypes', {
                    ...filters.acceptedAnimalTypes,
                    reptiles: e.target.checked ? true : undefined
                  })}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">Reptiles</span>
              </label>

              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={filters.acceptedAnimalTypes?.labAnimals || false}
                  onChange={(e) => handleFilterChange('acceptedAnimalTypes', {
                    ...filters.acceptedAnimalTypes,
                    labAnimals: e.target.checked ? true : undefined
                  })}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">Animaux de labo</span>
              </label>

              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={filters.acceptedAnimalTypes?.farmAnimals || false}
                  onChange={(e) => handleFilterChange('acceptedAnimalTypes', {
                    ...filters.acceptedAnimalTypes,
                    farmAnimals: e.target.checked ? true : undefined
                  })}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">Animaux de ferme</span>
              </label>
            </div>
          </div>

          {/* Expérience */}
          <div>
            <h4 className="font-medium text-gray-900 mb-3 flex items-center space-x-2">
              <Users className="h-4 w-4 text-primary-600" />
              <span>Expérience</span>
            </h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Niveau d'expérience
                </label>
                <select
                  value={filters.experienceLevel || ''}
                  onChange={(e) => handleFilterChange('experienceLevel', e.target.value || undefined)}
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                >
                  <option value="">Tous niveaux</option>
                  <option value="beginner">Débutant</option>
                  <option value="intermediate">Intermédiaire</option>
                  <option value="experienced">Expérimenté</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Accueils précédents (minimum)
                </label>
                <Input
                  type="number"
                  placeholder="0"
                  value={filters.minPreviousFosterCount || ''}
                  onChange={(e) => handleFilterChange('minPreviousFosterCount', e.target.value ? parseInt(e.target.value) : undefined)}
                  min="0"
                />
              </div>
            </div>
          </div>

          {/* Capacités */}
          <div>
            <h4 className="font-medium text-gray-900 mb-3">Capacités</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={filters.canProvideMedicalCare || false}
                  onChange={(e) => handleFilterChange('canProvideMedicalCare', e.target.checked ? true : undefined)}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">Peut prodiguer des soins médicaux</span>
              </label>

              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={filters.hasVehicle || false}
                  onChange={(e) => handleFilterChange('hasVehicle', e.target.checked ? true : undefined)}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">Véhiculé</span>
              </label>
            </div>
          </div>

          {/* Statut de vérification */}
          <div>
            <h4 className="font-medium text-gray-900 mb-3">Statut</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={filters.isVerified || false}
                  onChange={(e) => handleFilterChange('isVerified', e.target.checked ? true : undefined)}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">Profil vérifié uniquement</span>
              </label>

              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={filters.isTopFosterFamily || false}
                  onChange={(e) => handleFilterChange('isTopFosterFamily', e.target.checked ? true : undefined)}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">Top familles d'accueil</span>
              </label>
            </div>
          </div>

          {/* Compatibilité */}
          <div>
            <h4 className="font-medium text-gray-900 mb-3">Compatibilité</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={!!filters.compatibility?.withChildren}
                  onChange={(e) => handleFilterChange('compatibility', {
                    ...filters.compatibility,
                    withChildren: e.target.checked ? 1 : undefined
                  })}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">Présence d'enfants</span>
              </label>

              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={!!filters.compatibility?.withCats}
                  onChange={(e) => handleFilterChange('compatibility', {
                    ...filters.compatibility,
                    withCats: e.target.checked ? 1 : undefined
                  })}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">Présence de chats</span>
              </label>

              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={!!filters.compatibility?.withDogs}
                  onChange={(e) => handleFilterChange('compatibility', {
                    ...filters.compatibility,
                    withDogs: e.target.checked ? 1 : undefined
                  })}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">Présence de chiens</span>
              </label>

              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={!!filters.compatibility?.withOtherAnimals}
                  onChange={(e) => handleFilterChange('compatibility', {
                    ...filters.compatibility,
                    withOtherAnimals: e.target.checked ? 1 : undefined
                  })}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">Présence d'autres animaux</span>
              </label>
            </div>
          </div>
        </div>
      )}
    </Card>
  );
}