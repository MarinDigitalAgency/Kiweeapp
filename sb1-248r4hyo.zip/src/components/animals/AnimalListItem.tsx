import React from 'react';
import { Eye, Calendar, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Animal } from '../../types';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface AnimalListItemProps {
  animal: Animal;
  onChangeStatus: (animalId: string, newStatus: Animal['status']) => void;
}

export function AnimalListItem({ animal, onChangeStatus }: AnimalListItemProps) {
  const getAgeText = (age: number) => {
    return age > 1 ? `${age} ans` : `${age} an`;
  };
  
  const getSexText = (sex: string) => {
    const sexMap = {
      male: 'Mâle',
      female: 'Femelle'
    };
    return sexMap[sex as keyof typeof sexMap] || sex;
  };

  const getTypeText = (type: string) => {
    const typeMap = {
      chien: 'Chien',
      chat: 'Chat',
      autre: 'Autre'
    };
    return typeMap[type as keyof typeof typeMap] || type;
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'available':
        return (
          <Badge variant="warning" size="sm">
            🟡 Recherche famille
          </Badge>
        );
      case 'in_care':
        return (
          <Badge variant="secondary" size="sm">
            🟠 Démarche d'adoption
          </Badge>
        );
      case 'adopted':
        return (
          <Badge variant="success" size="sm">
            🟢 A trouvé famille
          </Badge>
        );
      default:
        return null;
    }
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const handleStatusChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newStatus = e.target.value as Animal['status'];
    onChangeStatus(animal.id, newStatus);
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4 hover:shadow-md transition-shadow duration-200">
      <div className="flex items-center space-x-4">
        {/* Photo miniature */}
        <div className="flex-shrink-0">
          <img
            src={animal.photos[0]}
            alt={animal.name}
            className="w-16 h-16 rounded-lg object-cover border border-gray-100"
          />
        </div>

        {/* Informations principales */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h3 className="font-semibold text-lg text-gray-900 truncate">{animal.name}</h3>
              <p className="text-sm text-gray-600 mt-1">
                {getTypeText(animal.type)} • {animal.breed} • {getSexText(animal.sex)} • {getAgeText(animal.age)}
              </p>
              
              <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                <div className="flex items-center space-x-1">
                  <Calendar className="h-3 w-3" />
                  <span>Ajouté le {formatDate(animal.createdAt)}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <MapPin className="h-3 w-3" />
                  <span>{animal.location}</span>
                </div>
              </div>
            </div>

            {/* Statut actuel */}
            <div className="flex-shrink-0 ml-4">
              {getStatusBadge(animal.status)}
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center space-x-3 flex-shrink-0">
          {/* Sélecteur de statut */}
          <div className="min-w-0">
            <label htmlFor={`status-${animal.id}`} className="sr-only">
              Changer le statut de {animal.name}
            </label>
            <select
              id={`status-${animal.id}`}
              value={animal.status}
              onChange={handleStatusChange}
              className="text-sm rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 bg-white"
            >
              <option value="available">🟡 Recherche famille</option>
              <option value="in_care">🟠 Démarche d'adoption</option>
              <option value="adopted">🟢 A trouvé famille</option>
            </select>
          </div>

          {/* Bouton voir fiche */}
          <Link to={`/animal/${animal.id}`}>
            <Button size="sm" variant="outline" icon={Eye}>
              Voir fiche
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}