import React, { useState, useEffect } from 'react';
import { Save, Plus, X, Camera, MapPin, Calendar, Heart, Shield, Stethoscope } from 'lucide-react';
import { Animal } from '../../types';
import { getBreedsByType } from '../../data/breedData';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Card } from '../ui/Card';
import { AnimalStatusSelector } from './AnimalStatusSelector';

interface AnimalFormProps {
  animal?: Animal;
  onSubmit: (animalData: Partial<Animal>) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function AnimalForm({ animal, onSubmit, onCancel, isLoading = false }: AnimalFormProps) {
  const [formData, setFormData] = useState<Partial<Animal>>({
    name: '',
    type: 'chien',
    breed: '',
    age: 1,
    sex: 'male',
    size: 'moyen',
    photos: [''],
    description: '',
    health: {
      vaccinated: false,
      sterilized: false,
      treatments: [],
    },
    characterTraits: {
      sociability: 3,
      obedience: 3,
      cuddliness: 3,
      independence: 3
    },
    compatibility: {
      withDogs: false,
      withCats: false,
      withChildren: false
    },
    location: '',
    latitude: 45.7640, // Lyon par défaut
    longitude: 4.8357,
    availableFrom: new Date(),
    status: 'available',
    sensitiveInfo: {
      icad: '',
      veterinaryClinic: '',
      veterinaryContact: '',
      medicalHistory: '',
      behavioralNotes: ''
    }
  });

  const [treatments, setTreatments] = useState<string>('');

  useEffect(() => {
    if (animal) {
      setFormData({
        ...animal,
        sensitiveInfo: animal.sensitiveInfo || {
          icad: '',
          veterinaryClinic: '',
          veterinaryContact: '',
          medicalHistory: '',
          behavioralNotes: ''
        }
      });
      setTreatments(animal.health.treatments?.join('\n') || '');
    }
  }, [animal]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const treatmentsList = treatments
      .split('\n')
      .map(t => t.trim())
      .filter(t => t.length > 0);

    const animalData = {
      ...formData,
      health: {
        ...formData.health!,
        treatments: treatmentsList
      }
    };

    onSubmit(animalData);
  };

  const updateField = (field: keyof Animal, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const updateNestedField = (field: keyof Animal, subField: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: {
        ...prev[field],
        [subField]: value
      }
    }));
  };

  const updateSensitiveField = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      sensitiveInfo: {
        ...prev.sensitiveInfo,
        [field]: value
      }
    }));
  };

  const addPhotoField = () => {
    setFormData(prev => ({
      ...prev,
      photos: [...(prev.photos || []), '']
    }));
  };

  const updatePhoto = (index: number, url: string) => {
    setFormData(prev => ({
      ...prev,
      photos: prev.photos?.map((photo, i) => i === index ? url : photo) || []
    }));
  };

  const removePhoto = (index: number) => {
    setFormData(prev => ({
      ...prev,
      photos: prev.photos?.filter((_, i) => i !== index) || []
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {/* Informations générales */}
      <Card>
        <div className="flex items-center space-x-2 mb-6">
          <Heart className="h-5 w-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Informations générales</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Input
            label="Nom de l'animal *"
            value={formData.name}
            onChange={(e) => updateField('name', e.target.value)}
            required
            placeholder="Ex: Luna, Max, Bella..."
          />

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Type d'animal *
            </label>
            <select
              value={formData.type}
              onChange={(e) => updateField('type', e.target.value)}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
              required
            >
              <option value="chien">Chien</option>
              <option value="chat">Chat</option>
              <option value="autre">Autre</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Race
            </label>
            <select
              value={formData.breed || ''}
              onChange={(e) => updateField('breed', e.target.value)}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
            >
              <option value="">Sélectionner une race</option>
              {getBreedsByType(formData.type).map((breed) => (
                <option key={breed} value={breed}>
                  {breed}
                </option>
              ))}
            </select>
          </div>

          <Input
            label="Âge (années) *"
            type="number"
            value={formData.age}
            onChange={(e) => updateField('age', parseInt(e.target.value) || 1)}
            min="0"
            max="30"
            required
          />

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Sexe *
            </label>
            <select
              value={formData.sex}
              onChange={(e) => updateField('sex', e.target.value)}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
              required
            >
              <option value="male">Mâle</option>
              <option value="female">Femelle</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Taille *
            </label>
            <select
              value={formData.size}
              onChange={(e) => updateField('size', e.target.value)}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
              required
            >
              <option value="petit">Petit</option>
              <option value="moyen">Moyen</option>
              <option value="grand">Grand</option>
            </select>
          </div>
        </div>

        <div className="mt-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Description *
          </label>
          <textarea
            value={formData.description}
            onChange={(e) => updateField('description', e.target.value)}
            rows={4}
            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
            placeholder="Décrivez le caractère, les habitudes et les besoins de l'animal..."
            required
          />
        </div>
      </Card>

      {/* Statut de l'animal */}
      <Card>
        <AnimalStatusSelector
          value={formData.status as 'available' | 'in_care' | 'adopted'}
          onChange={(status) => updateField('status', status)}
        />
      </Card>

      {/* Photos */}
      <Card>
        <div className="flex items-center space-x-2 mb-6">
          <Camera className="h-5 w-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Photos</h3>
        </div>

        <div className="space-y-4">
          {formData.photos?.map((photo, index) => (
            <div key={index} className="flex space-x-2">
              <div className="flex-1">
                <Input
                  placeholder="URL de la photo"
                  value={photo}
                  onChange={(e) => updatePhoto(index, e.target.value)}
                />
              </div>
              {formData.photos!.length > 1 && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  icon={X}
                  onClick={() => removePhoto(index)}
                  className="text-error-600 hover:text-error-700"
                >
                  <span className="sr-only">Supprimer</span>
                </Button>
              )}
            </div>
          ))}
          
          <Button
            type="button"
            variant="outline"
            size="sm"
            icon={Plus}
            onClick={addPhotoField}
          >
            Ajouter une photo
          </Button>
          
          <p className="text-xs text-gray-500">
            Ajoutez des URLs d'images. La première photo sera utilisée comme photo principale.
          </p>
        </div>
      </Card>

      {/* Santé */}
      <Card>
        <div className="flex items-center space-x-2 mb-6">
          <Stethoscope className="h-5 w-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Santé</h3>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={formData.health?.vaccinated}
                onChange={(e) => updateNestedField('health', 'vaccinated', e.target.checked)}
                className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
              />
              <span className="ml-2 text-sm text-gray-700">Vacciné</span>
            </label>

            <label className="flex items-center">
              <input
                type="checkbox"
                checked={formData.health?.sterilized}
                onChange={(e) => updateNestedField('health', 'sterilized', e.target.checked)}
                className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
              />
              <span className="ml-2 text-sm text-gray-700">Stérilisé</span>
            </label>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Traitements en cours
            </label>
            <textarea
              value={treatments}
              onChange={(e) => setTreatments(e.target.value)}
              rows={3}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
              placeholder="Un traitement par ligne (ex: Vermifuge, Antibiotiques...)"
            />
            <p className="text-xs text-gray-500 mt-1">
              Un traitement par ligne
            </p>
          </div>
        </div>
      </Card>

      {/* Traits de caractère */}
      <Card>
        <div className="flex items-center space-x-2 mb-6">
          <Heart className="h-5 w-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Traits de caractère</h3>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Sociabilité (1-5)
              </label>
              <input
                type="range"
                min="1"
                max="5"
                value={formData.characterTraits?.sociability || 3}
                onChange={(e) => updateNestedField('characterTraits', 'sociability', parseInt(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Réservé</span>
                <span>Très sociable</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Obéissance (1-5)
              </label>
              <input
                type="range"
                min="1"
                max="5"
                value={formData.characterTraits?.obedience || 3}
                onChange={(e) => updateNestedField('characterTraits', 'obedience', parseInt(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Indépendant</span>
                <span>Très obéissant</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Câlins (1-5)
              </label>
              <input
                type="range"
                min="1"
                max="5"
                value={formData.characterTraits?.cuddliness || 3}
                onChange={(e) => updateNestedField('characterTraits', 'cuddliness', parseInt(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Peu câlin</span>
                <span>Très câlin</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Indépendance (1-5)
              </label>
              <input
                type="range"
                min="1"
                max="5"
                value={formData.characterTraits?.independence || 3}
                onChange={(e) => updateNestedField('characterTraits', 'independence', parseInt(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Dépendant</span>
                <span>Très indépendant</span>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Compatibilité */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-6">Compatibilité</h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <label className="flex items-center">
            <input
              type="checkbox"
              checked={formData.compatibility?.withDogs}
              onChange={(e) => updateNestedField('compatibility', 'withDogs', e.target.checked)}
              className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
            />
            <span className="ml-2 text-sm text-gray-700">Compatible avec les chiens</span>
          </label>

          <label className="flex items-center">
            <input
              type="checkbox"
              checked={formData.compatibility?.withCats}
              onChange={(e) => updateNestedField('compatibility', 'withCats', e.target.checked)}
              className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
            />
            <span className="ml-2 text-sm text-gray-700">Compatible avec les chats</span>
          </label>

          <label className="flex items-center">
            <input
              type="checkbox"
              checked={formData.compatibility?.withChildren}
              onChange={(e) => updateNestedField('compatibility', 'withChildren', e.target.checked)}
              className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
            />
            <span className="ml-2 text-sm text-gray-700">Compatible avec les enfants</span>
          </label>
        </div>
      </Card>

      {/* Localisation et disponibilité */}
      <Card>
        <div className="flex items-center space-x-2 mb-6">
          <MapPin className="h-5 w-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Localisation et disponibilité</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Input
            label="Localisation *"
            value={formData.location}
            onChange={(e) => updateField('location', e.target.value)}
            placeholder="Ville, région..."
            required
          />

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Disponible à partir du *
            </label>
            <input
              type="date"
              value={formData.availableFrom ? formData.availableFrom.toISOString().split('T')[0] : ''}
              onChange={(e) => updateField('availableFrom', new Date(e.target.value))}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
              required
            />
          </div>
        </div>
      </Card>

      {/* Informations sensibles */}
      <Card>
        <div className="flex items-center space-x-2 mb-6">
          <Shield className="h-5 w-5 text-warning-600" />
          <h3 className="text-lg font-semibold text-gray-900">Informations sensibles</h3>
          <div className="bg-warning-50 border border-warning-200 rounded-lg px-3 py-1">
            <span className="text-xs text-warning-700 font-medium">Confidentielles</span>
          </div>
        </div>

        <div className="bg-warning-50 border border-warning-200 rounded-lg p-4 mb-6">
          <p className="text-sm text-warning-800">
            <strong>⚠️ Informations confidentielles :</strong> Ces informations ne seront visibles que par vous et les familles d'accueil confirmées. Elles n'apparaîtront pas sur le profil public de l'animal.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Input
            label="Numéro ICAD"
            value={formData.sensitiveInfo?.icad}
            onChange={(e) => updateSensitiveField('icad', e.target.value)}
            placeholder="Ex: 250268500123456"
          />

          <Input
            label="Clinique vétérinaire"
            value={formData.sensitiveInfo?.veterinaryClinic}
            onChange={(e) => updateSensitiveField('veterinaryClinic', e.target.value)}
            placeholder="Nom de la clinique"
          />

          <Input
            label="Contact vétérinaire"
            value={formData.sensitiveInfo?.veterinaryContact}
            onChange={(e) => updateSensitiveField('veterinaryContact', e.target.value)}
            placeholder="Téléphone ou email"
          />
        </div>

        <div className="mt-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Historique médical
            </label>
            <textarea
              value={formData.sensitiveInfo?.medicalHistory}
              onChange={(e) => updateSensitiveField('medicalHistory', e.target.value)}
              rows={3}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
              placeholder="Opérations, maladies passées, allergies..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Notes comportementales
            </label>
            <textarea
              value={formData.sensitiveInfo?.behavioralNotes}
              onChange={(e) => updateSensitiveField('behavioralNotes', e.target.value)}
              rows={3}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
              placeholder="Comportements particuliers, peurs, habitudes..."
            />
          </div>
        </div>
      </Card>

      {/* Actions */}
      <div className="flex justify-end space-x-4">
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          disabled={isLoading}
        >
          Annuler
        </Button>
        <Button
          type="submit"
          loading={isLoading}
          icon={Save}
        >
          {animal ? 'Mettre à jour' : 'Créer la fiche'}
        </Button>
      </div>
    </form>
  );
}