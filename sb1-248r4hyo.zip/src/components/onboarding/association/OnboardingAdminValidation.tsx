import React, { useState } from 'react';
import { Shield, ArrowRight, ArrowLeft, SkipForward, Upload, FileText, CheckCircle } from 'lucide-react';
import { Button } from '../../ui/Button';
import { Card } from '../../ui/Card';
import { Input } from '../../ui/Input';
import { AssociationProfile } from '../../../types';

interface OnboardingAdminValidationProps {
  data: Partial<AssociationProfile>;
  onUpdate: (updates: Partial<AssociationProfile>) => void;
  onNext: () => void;
  onPrev: () => void;
  onSkip: () => void;
}

export function OnboardingAdminValidation({
  data,
  onUpdate,
  onNext,
  onPrev,
  onSkip
}: OnboardingAdminValidationProps) {
  const [rnaValidation, setRnaValidation] = useState<'idle' | 'validating' | 'valid' | 'invalid'>('idle');
  const [uploadedDocs, setUploadedDocs] = useState<{
    insurance: boolean;
    acaced: boolean;
  }>({
    insurance: false,
    acaced: false
  });

  const validateRNA = async (rna: string) => {
    if (!rna || rna.length < 10) {
      setRnaValidation('idle');
      return;
    }

    setRnaValidation('validating');
    
    // Simulate RNA validation
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Mock validation - accept if starts with 'W' and has 10+ characters
    if (rna.startsWith('W') && rna.length >= 10) {
      setRnaValidation('valid');
    } else {
      setRnaValidation('invalid');
    }
  };

  const handleRNAChange = (value: string) => {
    onUpdate({ rna: value });
    validateRNA(value);
  };

  const handleDocumentUpload = (docType: 'insurance' | 'acaced') => {
    // Simulate document upload
    setUploadedDocs(prev => ({
      ...prev,
      [docType]: true
    }));
  };

  const isFormValid = data.rna && data.presidentName && data.foundedYear && rnaValidation === 'valid';

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-kiweetoTeal-100 rounded-full flex items-center justify-center mx-auto">
          <Shield className="h-8 w-8 text-kiweetoTeal-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            Validation administrative
          </h1>
          <p className="text-gray-600">
            Vérifiez l'existence légale de votre association et uploadez les documents requis.
          </p>
        </div>
      </div>

      {/* Legal Information */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Informations légales</h3>
        <div className="space-y-4">
          <div>
            <div className="flex items-center space-x-2 mb-2">
              <label className="block text-sm font-medium text-gray-700">
                Numéro RNA *
              </label>
              {rnaValidation === 'validating' && (
                <div className="animate-spin rounded-full h-4 w-4 border-2 border-kiweetoTeal-600 border-t-transparent"></div>
              )}
              {rnaValidation === 'valid' && (
                <CheckCircle className="h-4 w-4 text-success-600" />
              )}
            </div>
            <Input
              value={data.rna || ''}
              onChange={(e) => handleRNAChange(e.target.value)}
              placeholder="W123456789"
              className={
                rnaValidation === 'valid' ? 'border-success-500 bg-success-50' :
                rnaValidation === 'invalid' ? 'border-error-500 bg-error-50' : ''
              }
              required
            />
            {rnaValidation === 'valid' && (
              <p className="text-sm text-success-600 mt-1">✓ RNA validé automatiquement</p>
            )}
            {rnaValidation === 'invalid' && (
              <p className="text-sm text-error-600 mt-1">✗ RNA non trouvé dans la base officielle</p>
            )}
            <p className="text-xs text-gray-500 mt-1">
              Numéro d'enregistrement au Répertoire National des Associations
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Nom du président *"
              value={data.presidentName || ''}
              onChange={(e) => onUpdate({ presidentName: e.target.value })}
              placeholder="Prénom Nom"
              required
            />

            <Input
              label="Année de création *"
              type="number"
              value={data.foundedYear || new Date().getFullYear()}
              onChange={(e) => onUpdate({ foundedYear: parseInt(e.target.value) || new Date().getFullYear() })}
              min="1900"
              max={new Date().getFullYear()}
              required
            />
          </div>

          <Input
            label="SIRET (optionnel)"
            value={data.siret || ''}
            onChange={(e) => onUpdate({ siret: e.target.value })}
            placeholder="12345678901234"
          />
        </div>
      </Card>

      {/* Document Upload */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Documents obligatoires</h3>
        <div className="space-y-4">
          {/* Insurance Document */}
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h4 className="font-medium text-gray-900">Assurance Responsabilité Civile</h4>
                <p className="text-sm text-gray-600">Attestation d'assurance RC de l'association</p>
              </div>
              {uploadedDocs.insurance && (
                <CheckCircle className="h-6 w-6 text-success-600" />
              )}
            </div>
            
            {!uploadedDocs.insurance ? (
              <Button
                variant="outline"
                icon={Upload}
                onClick={() => handleDocumentUpload('insurance')}
                className="w-full"
              >
                Uploader l'attestation d'assurance
              </Button>
            ) : (
              <div className="flex items-center space-x-2 text-success-600">
                <FileText className="h-4 w-4" />
                <span className="text-sm font-medium">Attestation_RC_Association.pdf</span>
              </div>
            )}
          </div>

          {/* ACACED Certificates */}
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h4 className="font-medium text-gray-900">Certificats ACACED</h4>
                <p className="text-sm text-gray-600">Certificats de capacité pour animaux domestiques</p>
              </div>
              {uploadedDocs.acaced && (
                <CheckCircle className="h-6 w-6 text-success-600" />
              )}
            </div>
            
            {!uploadedDocs.acaced ? (
              <Button
                variant="outline"
                icon={Upload}
                onClick={() => handleDocumentUpload('acaced')}
                className="w-full"
              >
                Uploader les certificats ACACED
              </Button>
            ) : (
              <div className="flex items-center space-x-2 text-success-600">
                <FileText className="h-4 w-4" />
                <span className="text-sm font-medium">Certificats_ACACED.pdf</span>
              </div>
            )}
          </div>
        </div>
        
        <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm text-blue-800">
            <strong>Note :</strong> Ces documents sont vérifiés manuellement par notre équipe. 
            La validation prend généralement 24-48h ouvrées.
          </p>
        </div>
      </Card>

      {/* Validation Status */}
      {isFormValid && (
        <Card className="bg-success-50 border-success-200">
          <div className="flex items-center space-x-3">
            <CheckCircle className="h-6 w-6 text-success-600" />
            <div>
              <h3 className="font-semibold text-success-800">Validation réussie</h3>
              <p className="text-sm text-success-700">
                Votre association a été validée automatiquement. Vous pouvez continuer.
              </p>
            </div>
          </div>
        </Card>
      )}

      {/* Navigation */}
      <div className="flex justify-between items-center pt-6">
        <Button
          variant="outline"
          icon={ArrowLeft}
          onClick={onPrev}
        >
          Précédent
        </Button>

        <Button
          variant="ghost"
          icon={SkipForward}
          onClick={onSkip}
          className="text-gray-500"
        >
          Passer cette étape
        </Button>

        <Button
          variant="kiweetoTeal"
          icon={ArrowRight}
          iconPosition="right"
          onClick={onNext}
          disabled={!isFormValid}
        >
          Suivant
        </Button>
      </div>
    </div>
  );
}