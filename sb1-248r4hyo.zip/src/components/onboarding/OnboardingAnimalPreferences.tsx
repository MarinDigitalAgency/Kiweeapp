import React from 'react';
import { Heart, ArrowRight, ArrowLeft, SkipForward } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { FamilyProfile } from '../../types';

interface OnboardingAnimalPreferencesProps {
  data: Partial<FamilyProfile>;
  onUpdate: (updates: Partial<FamilyProfile>) => void;
  onNext: () => void;
  onPrev: () => void;
  onSkip: () => void;
}

export function OnboardingAnimalPreferences({
  data,
  onUpdate,
  onNext,
  onPrev,
  onSkip
}: OnboardingAnimalPreferencesProps) {
  const updateAnimalTypes = (type: keyof FamilyProfile['acceptedAnimalTypes'], value: boolean) => {
    onUpdate({
      acceptedAnimalTypes: {
        ...data.acceptedAnimalTypes,
        [type]: value
      }
    });
  };

  const updateAges = (age: keyof FamilyProfile['acceptedAges'], value: boolean) => {
    onUpdate({
      acceptedAges: {
        ...data.acceptedAges,
        [age]: value
      }
    });
  };

  const updateSizes = (size: keyof FamilyProfile['acceptedSizes'], value: boolean) => {
    onUpdate({
      acceptedSizes: {
        ...data.acceptedSizes,
        [size]: value
      }
    });
  };

  const updateSexes = (sex: keyof FamilyProfile['acceptedSexes'], value: boolean) => {
    onUpdate({
      acceptedSexes: {
        ...data.acceptedSexes,
        [sex]: value
      }
    });
  };

  const hasSelectedAnimalType = Object.values(data.acceptedAnimalTypes || {}).some(Boolean);
  const hasSelectedAge = Object.values(data.acceptedAges || {}).some(Boolean);
  const hasSelectedSize = Object.values(data.acceptedSizes || {}).some(Boolean);

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-kiweetoTeal-100 rounded-full flex items-center justify-center mx-auto">
          <Heart className="h-8 w-8 text-kiweetoTeal-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            Quels animaux souhaitez-vous accueillir ?
          </h1>
          <p className="text-gray-600">
            Sélectionnez vos préférences. Vous pourrez toujours les modifier plus tard.
          </p>
        </div>
      </div>

      {/* Animal Types */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Types d'animaux</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {[
            { key: 'dogs', label: 'Chiens', emoji: '🐕' },
            { key: 'cats', label: 'Chats', emoji: '🐱' },
            { key: 'nac', label: 'NAC (lapins, furets...)', emoji: '🐰' },
            { key: 'reptiles', label: 'Reptiles', emoji: '🦎' },
            { key: 'labAnimals', label: 'Animaux de laboratoire', emoji: '🐭' },
            { key: 'farmAnimals', label: 'Animaux de ferme', emoji: '🐷' }
          ].map(({ key, label, emoji }) => (
            <label
              key={key}
              className={`flex items-center p-4 border-2 rounded-lg cursor-pointer transition-all ${
                data.acceptedAnimalTypes?.[key as keyof typeof data.acceptedAnimalTypes]
                  ? 'border-kiweetoTeal-500 bg-kiweetoTeal-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <input
                type="checkbox"
                checked={data.acceptedAnimalTypes?.[key as keyof typeof data.acceptedAnimalTypes] || false}
                onChange={(e) => updateAnimalTypes(key as keyof FamilyProfile['acceptedAnimalTypes'], e.target.checked)}
                className="sr-only"
              />
              <div className="flex items-center space-x-3">
                <span className="text-2xl">{emoji}</span>
                <span className="font-medium text-gray-900">{label}</span>
              </div>
            </label>
          ))}
        </div>
      </Card>

      {/* Ages */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Âges acceptés</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { key: 'baby', label: 'Bébés', description: '< 1 an', emoji: '🍼' },
            { key: 'junior', label: 'Jeunes', description: '1-2 ans', emoji: '🎾' },
            { key: 'adult', label: 'Adultes', description: '3-7 ans', emoji: '🦴' },
            { key: 'senior', label: 'Seniors', description: '8+ ans', emoji: '👴' }
          ].map(({ key, label, description, emoji }) => (
            <label
              key={key}
              className={`flex flex-col items-center p-4 border-2 rounded-lg cursor-pointer transition-all ${
                data.acceptedAges?.[key as keyof typeof data.acceptedAges]
                  ? 'border-kiweetoTeal-500 bg-kiweetoTeal-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <input
                type="checkbox"
                checked={data.acceptedAges?.[key as keyof typeof data.acceptedAges] || false}
                onChange={(e) => updateAges(key as keyof FamilyProfile['acceptedAges'], e.target.checked)}
                className="sr-only"
              />
              <span className="text-2xl mb-2">{emoji}</span>
              <span className="font-medium text-gray-900 text-center">{label}</span>
              <span className="text-xs text-gray-500 text-center">{description}</span>
            </label>
          ))}
        </div>
      </Card>

      {/* Sizes */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Tailles acceptées</h3>
        <div className="grid grid-cols-3 gap-4">
          {[
            { key: 'small', label: 'Petit', description: '< 10kg', emoji: '🐕‍🦺' },
            { key: 'medium', label: 'Moyen', description: '10-25kg', emoji: '🐕' },
            { key: 'large', label: 'Grand', description: '> 25kg', emoji: '🐕‍🦮' }
          ].map(({ key, label, description, emoji }) => (
            <label
              key={key}
              className={`flex flex-col items-center p-4 border-2 rounded-lg cursor-pointer transition-all ${
                data.acceptedSizes?.[key as keyof typeof data.acceptedSizes]
                  ? 'border-kiweetoTeal-500 bg-kiweetoTeal-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <input
                type="checkbox"
                checked={data.acceptedSizes?.[key as keyof typeof data.acceptedSizes] || false}
                onChange={(e) => updateSizes(key as keyof FamilyProfile['acceptedSizes'], e.target.checked)}
                className="sr-only"
              />
              <span className="text-2xl mb-2">{emoji}</span>
              <span className="font-medium text-gray-900 text-center">{label}</span>
              <span className="text-xs text-gray-500 text-center">{description}</span>
            </label>
          ))}
        </div>
      </Card>

      {/* Sexes */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Sexes acceptés</h3>
        <div className="grid grid-cols-2 gap-4">
          {[
            { key: 'male', label: 'Mâles', emoji: '♂️' },
            { key: 'female', label: 'Femelles', emoji: '♀️' }
          ].map(({ key, label, emoji }) => (
            <label
              key={key}
              className={`flex items-center justify-center p-4 border-2 rounded-lg cursor-pointer transition-all ${
                data.acceptedSexes?.[key as keyof typeof data.acceptedSexes]
                  ? 'border-kiweetoTeal-500 bg-kiweetoTeal-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <input
                type="checkbox"
                checked={data.acceptedSexes?.[key as keyof typeof data.acceptedSexes] || false}
                onChange={(e) => updateSexes(key as keyof FamilyProfile['acceptedSexes'], e.target.checked)}
                className="sr-only"
              />
              <div className="flex items-center space-x-3">
                <span className="text-2xl">{emoji}</span>
                <span className="font-medium text-gray-900">{label}</span>
              </div>
            </label>
          ))}
        </div>
      </Card>

      {/* Encouragement Message */}
      {hasSelectedAnimalType && (
        <Card className="bg-kiweetoTeal-50 border-kiweetoTeal-200">
          <div className="text-center">
            <p className="text-kiweetoTeal-800 font-medium">
              🎉 Parfait ! Vous êtes prêt(e) à accueillir de merveilleux compagnons !
            </p>
          </div>
        </Card>
      )}

      {/* Navigation */}
      <div className="flex justify-between items-center pt-6">
        <Button
          variant="outline"
          icon={ArrowLeft}
          onClick={onPrev}
        >
          Précédent
        </Button>

        <Button
          variant="ghost"
          icon={SkipForward}
          onClick={onSkip}
          className="text-gray-500"
        >
          Passer cette étape
        </Button>

        <Button
          variant="kiweetoTeal"
          icon={ArrowRight}
          iconPosition="right"
          onClick={onNext}
          disabled={!hasSelectedAnimalType}
        >
          Suivant
        </Button>
      </div>
    </div>
  );
}